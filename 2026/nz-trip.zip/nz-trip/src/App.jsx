import { useState } from 'react'
import BottomNav from './components/BottomNav'
import Today     from './pages/Today'
import Itinerary from './pages/Itinerary'
import Route     from './pages/Route'
import Expenses  from './pages/Expenses'
import UpdateBanner from './components/UpdateBanner'

export default function App() {
  const [page, setPage] = useState('today')

  return (
    <div className="flex flex-col h-full w-full relative" style={{ background: '#FAF9F5' }}>
      <div className="flex-1 overflow-y-auto overflow-x-hidden" style={{ paddingBottom: '4.5rem' }}>
        {page === 'today'     && <Today />}
        {page === 'itinerary' && <Itinerary />}
        {page === 'route'     && <Route />}
        {page === 'expenses'  && <Expenses isActive={true} />}
      </div>
      <BottomNav active={page} onChange={setPage} />
      <UpdateBanner />
    </div>
  )
}
