import { TRIP } from '../data/config'
import { itinerary } from '../data/itinerary'

const TZ = 'Pacific/Auckland'

// Returns today's date string in NZ local time: "2026-10-14"
export function getNZDateString() {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: TZ,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date())
}

// Returns NZ local Date object components
export function getNZDateParts() {
  const fmt = (unit) =>
    new Intl.DateTimeFormat('en-US', { timeZone: TZ, [unit]: 'numeric' }).format(new Date())
  return {
    year:  parseInt(fmt('year')),
    month: parseInt(fmt('month')),
    day:   parseInt(fmt('day')),
  }
}

// NZ 現在時間 'HH:MM'（24 小時制），給穿搭卡判斷白天 / 晚上
export function getNZTimeHHMM() {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: TZ, hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).format(new Date())
}

// Returns trip status: 'before' | 'during' | 'after'
export function getTripStatus() {
  const today = getNZDateString()
  if (today < TRIP.startDate) return 'before'
  if (today > TRIP.endDate)   return 'after'
  return 'during'
}

// Returns current trip day (1-based) or null if not during trip
export function getCurrentDay() {
  const status = getTripStatus()
  if (status !== 'during') return null
  const today = getNZDateString()
  const entry = itinerary.find(d => d.date === today)
  return entry ? entry.day : null
}

// Returns days until trip starts (positive) or days since ended (negative)
export function getDaysUntilTrip() {
  const today = getNZDateString()
  const start = TRIP.startDate
  const msPerDay = 86400000
  const diff = new Date(start).getTime() - new Date(today).getTime()
  return Math.round(diff / msPerDay)
}

// Returns itinerary entry for a given day number
export function getDayData(dayNumber) {
  return itinerary.find(d => d.day === dayNumber) || null
}

// Returns formatted date label: "14 October 2026"
export function formatDateLabel(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number)
  const months = ['January','February','March','April','May','June',
                  'July','August','September','October','November','December']
  return `${d} ${months[m - 1]} ${y}`
}

// Returns short date: "Oct 14"
export function formatDateShort(dateStr) {
  const [, m, d] = dateStr.split('-').map(Number)
  const months = ['Jan','Feb','Mar','Apr','May','Jun',
                  'Jul','Aug','Sep','Oct','Nov','Dec']
  return `${months[m - 1]} ${d}`
}

// Get status of a specific day relative to today
export function getDayStatus(day) {
  const status = getTripStatus()
  const currentDay = getCurrentDay()
  if (status === 'before') return 'upcoming'
  if (status === 'after')  return 'completed'
  if (day < currentDay)    return 'completed'
  if (day === currentDay)  return 'today'
  return 'upcoming'
}

// ── 精確位置判斷（依實際航班 UTC 時間）────────────────────────────────────────
// 所有時間換算為 UTC：
//   台灣 UTC+8  / 墨爾本 AEDT UTC+11 / 布里斯本 AEST UTC+10 / 紐西蘭 NZDT UTC+13
const FLIGHT_UTC = {
  CI057_DEP: Date.parse('2026-10-08T15:30:00Z'), // TPE 23:30 TWN
  CI057_ARR: Date.parse('2026-10-09T00:40:00Z'), // MEL 11:40 AEDT
  QF169_DEP: Date.parse('2026-10-09T07:40:00Z'), // MEL 18:40 AEDT
  QF169_ARR: Date.parse('2026-10-09T11:10:00Z'), // CHC 00:10 NZDT Oct 10
  QF186_DEP: Date.parse('2026-10-17T06:45:00Z'), // ZQN 19:45 NZDT
  QF186_ARR: Date.parse('2026-10-17T10:35:00Z'), // BNE 20:35 AEST
  CI054_DEP: Date.parse('2026-10-17T12:50:00Z'), // BNE 22:50 AEST
  CI054_ARR: Date.parse('2026-10-17T21:40:00Z'), // TPE 05:40 TWN Oct 18
}

// 回傳目前正在飛的航班（不在飛行中回傳 null）
export function getCurrentFlight() {
  const now = Date.now()
  const { CI057_DEP, CI057_ARR, QF169_DEP, QF169_ARR,
          QF186_DEP, QF186_ARR, CI054_DEP, CI054_ARR } = FLIGHT_UTC

  if (now >= CI057_DEP && now < CI057_ARR) return { code: 'CI057', from: '台北桃園', to: '墨爾本',   dep: '23:30', arr: '11:40+1', emoji: '✈️' }
  if (now >= QF169_DEP && now < QF169_ARR) return { code: 'QF169', from: '墨爾本',   to: '基督城',   dep: '18:40', arr: '00:10+1', emoji: '✈️' }
  if (now >= QF186_DEP && now < QF186_ARR) return { code: 'QF186', from: '皇后鎮',   to: '布里斯本', dep: '19:45', arr: '20:35',   emoji: '✈️' }
  if (now >= CI054_DEP && now < CI054_ARR) return { code: 'CI054', from: '布里斯本', to: '台北桃園', dep: '22:50', arr: '05:40+1', emoji: '✈️' }
  return null
}

// 回傳目前精確所在位置 zone
export function getLocationZone() {
  const now = Date.now()
  const { CI057_DEP, CI057_ARR, QF169_DEP, QF169_ARR,
          QF186_DEP, QF186_ARR, CI054_DEP, CI054_ARR } = FLIGHT_UTC

  if (now < CI057_DEP)  return 'hsinchu'    // 還在新竹
  if (now < CI057_ARR)  return 'flight'     // ✈ TPE → MEL
  if (now < QF169_DEP)  return 'melbourne'  // 墨爾本候機
  if (now < QF169_ARR)  return 'flight'     // ✈ MEL → CHC
  if (now < QF186_DEP)  return 'nz'         // 紐西蘭（按天計算城市）
  if (now < QF186_ARR)  return 'flight'     // ✈ ZQN → BNE
  if (now < CI054_DEP)  return 'brisbane'   // 布里斯本候機
  if (now < CI054_ARR)  return 'flight'     // ✈ BNE → TPE
  return 'hsinchu'                           // 回到新竹
}
