import { useState, useEffect } from 'react'
import { itinerary } from '../data/itinerary'
import { getActivitiesForDate } from '../data/trip'
import { getFoodQuestsForDate } from '../data/foodQuests'
import FoodQuestModal from '../components/FoodQuestModal'
import OutfitOverview from '../components/OutfitOverview'
import { getOutfitForDate, outfitSummary } from '../data/outfits'
import { getDayStatus, formatDateShort, getCurrentDay, getTripStatus } from '../utils/nzTime'
import PhoneText from '../components/PhoneText'
import PlanB from '../components/PlanB'
import RouteStops from '../components/RouteStops'
import { getStopsForDate } from '../data/routes'

// ── Drive connectors between days ─────────────────────────────────────────────
// Labels only — add confirmed km data when available
const AFTER_DRIVES = {
  2: { label: 'CHR → TEKAPO' },
  3: { label: 'TEKAPO → MT COOK' },
  4: { label: 'MT COOK → WANAKA' },
  5: { label: 'WANAKA → QTN' },
  // Days 6-8 all based in Queenstown
  9: { label: 'ZQN ✈ BNE → TPE', isFlight: true },
}

// ── Expandable schedule ───────────────────────────────────────────────────────
function ExpandableSchedule({ day, isOpen }) {
  const [showFood, setShowFood] = useState(false)
  const [showOutfit, setShowOutfit] = useState(false)
  const outfit = getOutfitForDate(day.date)
  const foodData = getFoodQuestsForDate(day.date)

  return (
    <div style={{
      maxHeight: isOpen ? '1200px' : '0',
      overflow: 'hidden',
      transition: 'max-height 320ms ease',
    }}>
      <div>
        {/* Schedule — open list, no card */}
        <div style={{ paddingTop: 12, paddingLeft: 2 }}>
          {day.schedule.map((item, i) => (
            <div key={i} className="flex gap-4 py-2.5"
              style={{ borderBottom: i < day.schedule.length - 1 ? '1px solid #F3F0EA' : 'none' }}>
              <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 12,
                color: '#3D6E8A', fontWeight: 500, width: 44, flexShrink: 0 }}>
                {item.time}
              </span>
              <div>
                <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 13, color: '#2A2A2A', lineHeight: 1.4 }}>
                  {item.activity}
                </div>
                {item.note && (
                  <div style={{ fontSize: 11, color: '#A8A8A8', marginTop: 2, fontFamily: 'Inter, sans-serif' }}>
                    <PhoneText text={item.note} />
                  </div>
                )}
              </div>
            </div>
          ))}

          {/* Accommodation + cost */}
          <div className="flex gap-6 mt-4 pt-3"
            style={{ borderTop: '1px solid #F3F0EA' }}>
            {day.accommodation && (
              <div>
                <div style={{ fontSize: 9, letterSpacing: '0.2em', color: '#A8A8A8',
                  fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 3 }}>
                  STAY
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
                  <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 12, color: '#2A2A2A', fontWeight: 600 }}>
                    {day.accommodation.name}
                  </div>
                  {day.accommodation.address && (
                    <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(day.accommodation.address)}`}
                      target="_blank" rel="noopener noreferrer"
                      style={{ fontFamily: 'Inter, sans-serif', fontSize: 9, color: '#3D6E8A', textDecoration: 'none',
                        flexShrink: 0, border: '1px solid #C5DDE8', borderRadius: 4, padding: '2px 7px' }}>
                      MAP ↗
                    </a>
                  )}
                </div>
                <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 10, color: '#8A8A8A', marginTop: 2 }}>
                  {day.accommodation.city}
                  {(day.accommodation.checkInWindow || day.accommodation.checkInTime) && (
                    <span> · Check-in {day.accommodation.checkInWindow || day.accommodation.checkInTime}</span>
                  )}
                  {day.accommodation.checkOutTime && (
                    <span> · 退房 {day.accommodation.checkOutTime} 前</span>
                  )}
                </div>
                {day.accommodation.phone ? (
                  <a href={`tel:${day.accommodation.phone}`}
                    style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
                      color: '#3D6E8A', marginTop: 3, display: 'inline-block' }}>
                    📞 {day.accommodation.phone}
                  </a>
                ) : (
                  <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 10, color: '#C0B8AC', marginTop: 3 }}>
                    自助入住 · access code 在 email
                  </div>
                )}
              </div>
            )}
            {day.estimatedCost?.NZD && (
              <div>
                <div style={{ fontSize: 9, letterSpacing: '0.2em', color: '#A8A8A8',
                  fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 3 }}>
                  EST. COST
                </div>
                <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 12, color: '#4A4A4A' }}>
                  NZ$ {day.estimatedCost.NZD.toLocaleString()}
                </div>
              </div>
            )}
          </div>

          {day.note && (
            <div className="mt-3" style={{ borderLeft: '2px solid #C4952A', paddingLeft: 10 }}>
              <p style={{ fontFamily: 'Lora, Georgia, serif', fontSize: 12,
                color: '#6B6B6B', fontStyle: 'italic', lineHeight: 1.6 }}>
                {day.note}
              </p>
            </div>
          )}

          {/* 當天確認活動 + MAP */}
          {getActivitiesForDate(day.date).map(a => (
            <div key={a.id} style={{ background: '#F3F0EA', borderRadius: 8, padding: '8px 10px', marginTop: 8,
              display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
              <div>
                <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 9, letterSpacing: '0.15em', color: '#C4952A',
                  textTransform: 'uppercase', fontWeight: 700, marginBottom: 2 }}>
                  ⭐ 確認活動
                </div>
                <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 12, color: '#173D2A', fontWeight: 600 }}>
                  {a.startTime && `${a.startTime} `}{a.nameZh}
                </div>
                <PlanB text={a.planB} />
              </div>
              {a.mapsQuery && (
                <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(a.mapsQuery)}`}
                  target="_blank" rel="noopener noreferrer"
                  style={{ fontFamily: 'Inter, sans-serif', fontSize: 9, color: '#3D6E8A', textDecoration: 'none',
                    flexShrink: 0, border: '1px solid #C5DDE8', borderRadius: 4, padding: '2px 7px' }}>
                  MAP ↗
                </a>
              )}
            </div>
          ))}

          <RouteStops stops={getStopsForDate(day.date)} />

          {/* 今日穿搭一行摘要 → 點開穿搭總覽（定位到這天） */}
          {outfit && (
            <button onClick={() => setShowOutfit(true)}
              style={{ width: '100%', textAlign: 'left', marginTop: 10, background: 'none', border: 'none',
                borderTop: '1px solid #F3F0EA', padding: '8px 0 0', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
              <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 12, color: '#4A4A4A', lineHeight: 1.4 }}>
                <span style={{ fontSize: 9, letterSpacing: '0.18em', color: '#A8A8A8', marginRight: 6 }}>WEAR</span>
                {outfitSummary(outfit)}
              </span>
              <span style={{ color: '#C4952A', fontSize: 13, flexShrink: 0 }}>›</span>
            </button>
          )}

          {/* FOOD QUEST */}
          {foodData && (
            <button onClick={() => setShowFood(true)}
              style={{ width:'100%', textAlign:'left', marginTop:14,
                background:'#F3F0EA', borderRadius:10, padding:'10px 14px',
                display:'flex', alignItems:'center', justifyContent:'space-between',
                border:'none', cursor:'pointer' }}>
              <div>
                <div style={{ fontFamily:'Inter,sans-serif', fontSize:9,
                  letterSpacing:'0.18em', color:'#C4952A',
                  textTransform:'uppercase', fontWeight:600, marginBottom:2 }}>
                  FOOD QUEST · {foodData.quests.length}
                </div>
                <div style={{ fontFamily:'Inter,sans-serif', fontSize:11, color:'#4A4A4A' }}>
                  {foodData.quests.map(q => q.emoji + ' ' + q.food).join(' · ')}
                </div>
              </div>
              <div style={{ color:'#C4952A', fontSize:13, flexShrink:0 }}>→</div>
            </button>
          )}
        </div>
      </div>
      {showOutfit && <OutfitOverview initialDate={day.date} onClose={() => setShowOutfit(false)} />}
      {showFood && foodData && (
        <FoodQuestModal date={day.date} data={foodData} onClose={() => setShowFood(false)} />
      )}
    </div>
  )
}

// ── Single day entry ──────────────────────────────────────────────────────────
function DayEntry({ day, status, isExpanded, onToggle }) {
  const isToday     = status === 'today'
  const isCompleted = status === 'completed'
  const isUpcoming  = status === 'upcoming'

  // Dot colors
  const dotFill   = isToday ? '#C4952A' : isCompleted ? '#173D2A' : '#FAF9F5'
  const dotStroke = isToday ? '#F4EBC8' : isCompleted ? '#4A9B6F' : '#CEC7B8'

  return (
    <div className="relative flex gap-5">
      {/* ── Left: route line + dot ── */}
      <div className="flex flex-col items-center flex-shrink-0" style={{ width: 20 }}>
        <div
          className={isToday ? 'dot-pulse' : ''}
          style={{
          width: 12, height: 12, borderRadius: '50%',
          background: dotFill, border: `2px solid ${dotStroke}`,
          flexShrink: 0, zIndex: 1, marginTop: 4,
        }} />
      </div>

      {/* ── Right: day info ── */}
      <div className="flex-1 pb-8">
        {/* Day number + date */}
        <div className="flex justify-between items-start mb-1.5">
          <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 10,
            letterSpacing: '0.18em', color: isUpcoming ? '#A8A8A8' : '#8A8A8A',
            textTransform: 'uppercase', fontWeight: 600 }}>
            {String(day.day).padStart(2,'0')} / {10}
          </span>
          <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 10,
            letterSpacing: '0.12em', color: '#A8A8A8', textTransform: 'uppercase' }}>
            {formatDateShort(day.date).toUpperCase()}
          </span>
        </div>

        {/* Thin divider line */}
        <div style={{ height: 1, background: '#E6E1D6', marginBottom: 10 }} />

        {/* City name — editorial large type */}
        <button
          className="text-left w-full group"
          onClick={onToggle}
        >
          <div style={{
            fontFamily: 'Lora, Georgia, serif',
            fontSize: isToday ? '1.35rem' : '1.15rem',
            color: isToday ? '#173D2A' : isCompleted ? '#173D2A' : '#6B6B6B',
            fontWeight: isToday ? 700 : 600,
            lineHeight: 1.1,
            letterSpacing: '-0.01em',
            marginBottom: 2,
          }}>
            {day.location.en}
          </div>

          {/* Gold accent under today */}
          {isToday && (
            <div style={{ width: 24, height: 2, background: '#C4952A', borderRadius: 2, marginBottom: 4 }} />
          )}

          <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
            color: isToday ? '#3D6E8A' : '#A8A8A8',
            letterSpacing: '0.04em', marginBottom: 6 }}>
            {day.location.zh}
            {isToday && <span style={{ marginLeft: 6, color: '#C4952A', fontWeight: 700 }}>· TODAY</span>}
            {isCompleted && <span style={{ marginLeft: 6, color: '#4A9B6F' }}>· COMPLETED</span>}
          </div>

          {/* Title */}
          <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 12,
            color: isUpcoming ? '#C0B8AC' : '#8A8A8A', marginBottom: day.companions?.length ? 6 : 10 }}>
            {day.titleZh}
          </div>

          {/* Companions badge */}
          {day.companions && day.companions.length > 0 && (
            <div className="flex items-center gap-1.5" style={{ marginBottom: 10 }}>
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: 4,
                fontFamily: 'Inter, sans-serif', fontSize: 10, fontWeight: 600,
                color: '#3D6E8A', letterSpacing: '0.04em',
                background: '#EEF5FA', border: '1px solid #C5DDE8',
                borderRadius: 999, padding: '2px 8px',
              }}>
                👤 {day.companions.join('、')} 同遊
              </div>
            </div>
          )}

          {/* Expand toggle */}
          <div className="flex items-center gap-2">
            <div style={{ fontSize: 9, letterSpacing: '0.2em', color: '#9BBFD5',
              fontFamily: 'Inter, sans-serif', textTransform: 'uppercase',
              fontWeight: 600 }}>
              {isExpanded ? 'CLOSE' : 'VIEW SCHEDULE'}
            </div>
            <div style={{
              color: '#9BBFD5',
              transform: isExpanded ? 'rotate(180deg)' : 'none',
              transition: 'transform 220ms ease',
              lineHeight: 1,
            }}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M6 9l6 6 6-6"/>
              </svg>
            </div>
          </div>
        </button>

        {/* Expandable schedule */}
        <ExpandableSchedule day={day} isOpen={isExpanded} />
      </div>
    </div>
  )
}

// ── Drive connector between days ──────────────────────────────────────────────
function DriveConnector({ drive }) {
  return (
    <div className="relative flex gap-5 -mt-5 mb-0">
      {/* Line continuation */}
      <div className="flex flex-col items-center flex-shrink-0" style={{ width: 20 }}>
        {/* thin vertical line pass-through */}
      </div>
      {/* Drive info */}
      <div className="flex-1 py-2 px-3 mb-6 rounded-lg flex items-center gap-3"
        style={{ background: '#F3F0EA', border: '1px solid #E6E1D6' }}>
        {drive.isFlight ? (
          <span style={{ fontSize: 14 }}>✈️</span>
        ) : (
          <span style={{ fontSize: 14 }}>🚗</span>
        )}
        <div className="flex-1">
          <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 10,
            letterSpacing: '0.18em', color: '#8A8A8A', textTransform: 'uppercase',
            fontWeight: 600 }}>
            {drive.label}
          </div>
          {drive.km != null && drive.km > 0 && (
            <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, color: '#A8A8A8', marginTop: 1 }}>
              {drive.km} km{drive.time ? ` · ${drive.time}` : ''}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function Itinerary() {
  const tripStatus = getTripStatus()
  const currentDay = getCurrentDay()
  const [expanded, setExpanded] = useState(currentDay || 1)
  const toggle = d => setExpanded(p => p === d ? null : d)

  return (
    <div className="min-h-full" style={{ background: '#FAF9F5' }}>

      {/* ── Page header (no green bg) ── */}
      <div className="px-6 pt-14 pb-6">
        <div style={{ fontSize: 10, letterSpacing: '0.22em', color: '#8A8A8A',
          fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 8 }}>
          ITINERARY · EXPEDITION 2026
        </div>
        <div style={{
          fontFamily: 'Lora, Georgia, serif',
          fontSize: '2.2rem',
          color: '#173D2A',
          fontWeight: 700,
          lineHeight: 0.95,
          letterSpacing: '-0.02em',
          marginBottom: 6,
        }}>
          10 Days
        </div>
        <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '0.95rem',
          color: '#6B6B6B', fontStyle: 'italic', marginBottom: 4 }}>
          South Island Road Trip
        </div>
        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
          color: '#A8A8A8', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
          09 OCT – 18 OCT, 2026
        </div>
      </div>

      {/* ── Thin separator ── */}
      <div style={{ height: 1, background: '#E6E1D6', marginLeft: 24, marginRight: 24, marginBottom: 8 }} />

      {/* ── Day entries with route line ── */}
      <div className="relative px-6 pt-4">
        {/* The vertical "road" running through all entries */}
        <div className="absolute top-0 bottom-0"
          style={{ left: 30, width: 1, background: '#E6E1D6', zIndex: 0 }} />

        {itinerary.map((day, idx) => {
          const status = getDayStatus(day.day, currentDay, tripStatus)
          const drive = AFTER_DRIVES[day.day]
          return (
            <div key={day.day}>
              <DayEntry
                day={day}
                status={status}
                isExpanded={expanded === day.day}
                onToggle={() => toggle(day.day)}
              />
              {drive && idx < itinerary.length - 1 && (
                <DriveConnector drive={drive} />
              )}
            </div>
          )
        })}

        {/* Final destination */}
        <div className="flex gap-5 pb-4">
          <div className="flex flex-col items-center flex-shrink-0" style={{ width: 20 }}>
            <div style={{ width: 12, height: 12, borderRadius: '50%',
              background: '#FAF9F5', border: '2px dashed #CEC7B8', zIndex: 1 }} />
          </div>
          <div>
            <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 10,
              letterSpacing: '0.18em', color: '#A8A8A8', textTransform: 'uppercase', marginBottom: 4 }}>
              DESTINATION
            </div>
            <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1rem', color: '#A8A8A8' }}>
              Taiwan · Home
            </div>
          </div>
        </div>
      </div>

      <div style={{ height: '5rem' }} />
    </div>
  )
}
