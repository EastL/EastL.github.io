import { useState, useEffect } from 'react'
import { useExpenses } from '../hooks/useExpenses'
import { PinGate, ExpenseForm } from '../components/ExpenseForm'
import { EXPENSE_CATEGORIES } from '../data/config'

const fmtTWD = (n, decimals = 0) => {
  const num = Number(n) || 0
  return `NT$ ${num.toFixed(decimals).replace(/\B(?=(\d{3})+(?!\d))/g, ',')}`
}

const Label = ({ children }) => (
  <div style={{ fontSize: 9, letterSpacing: '0.22em', color: '#8A8A8A',
    fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', fontWeight: 600, marginBottom: 4 }}>
    {children}
  </div>
)
const Hr = () => <div style={{ height: 1, background: '#E6E1D6', margin: '16px 0' }} />

function CategoryBar({ label, amountTWD, total, color }) {
  if (!amountTWD) return null
  const pct = total > 0 ? (amountTWD / total) * 100 : 0
  return (
    <div className="mb-4">
      <div className="flex justify-between mb-1.5">
        <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 12, color: '#4A4A4A' }}>{label}</span>
        <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 12, color: '#2A2A2A', fontWeight: 600 }}>
          {fmtTWD(amountTWD)}
        </span>
      </div>
      <div style={{ height: 3, background: '#E6E1D6', borderRadius: 99, overflow: 'hidden' }}>
        <div style={{ height: '100%', borderRadius: 99, background: color,
          width: `${pct}%`, transition: 'width 0.7s ease' }} />
      </div>
    </div>
  )
}

export default function Expenses({ isActive }) {
  const {
    syncStatus,
    confirmedSharedTWD, perPersonSharedTWD,
    accommTotalTWD, rentalTotalTWD, activityTotalTWD,
    flightsTotalTWD, flightDongyueTWD, flightBrotherTWD,
    grandConfirmedTWD,
    personalCostDongyue, personalCostBrother,
    esimDongyueTWD,
    sharedLineItems, confirmedPersonal, upcomingExpenses,
    userExpenses, addExpense, deleteExpense,
    getUserTotal, isAuthenticated, authenticate, logout, exportJSON, toTWD, refresh,
  } = useExpenses()

  // B: auto-refresh when tab becomes active
  useEffect(() => { if (isActive && refresh) refresh() }, [isActive])

  const [showPinGate, setShowPinGate] = useState(false)
  const [showForm,    setShowForm]    = useState(false)
  const [tab, setTab] = useState('summary')

  const handleAddClick = () => isAuthenticated ? setShowForm(true) : setShowPinGate(true)
  const handleAuth = (pin) => {
    const ok = authenticate(pin)
    if (ok) { setShowPinGate(false); setShowForm(true) }
    return ok
  }

  const userTotal = getUserTotal()

  return (
    <div className="min-h-full" style={{ background: '#FAF9F5' }}>
      {/* Header */}
      <div className="px-6 pt-14 pb-5">
        <div style={{ fontSize: 10, letterSpacing: '0.22em', color: '#8A8A8A',
          fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 8 }}>
          EXPENSE DASHBOARD
        </div>
        <div className="flex items-end justify-between">
          <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '2.2rem',
            color: '#173D2A', fontWeight: 700, lineHeight: 0.95, letterSpacing: '-0.02em' }}>
            燒了多少
          </div>
          {/* Refresh button (C) + sync badge */}
          <div className="flex items-center gap-2 mb-1">
          <button onClick={refresh} title="重新整理"
            style={{
              fontFamily: 'Inter, sans-serif', fontSize: 11,
              color: syncStatus === 'loading' ? '#A8A8A8' : '#3D6E8A',
              padding: '3px 6px', lineHeight: 1,
            }}>
            {syncStatus === 'loading' ? '…' : '↻'}
          </button>
          {/* Sync status badge */}
          <div style={{
            fontFamily: 'Inter, sans-serif', fontSize: 9,
            letterSpacing: '0.15em', textTransform: 'uppercase',
            padding: '3px 8px', borderRadius: 999, marginBottom: 4,
            background: syncStatus === 'synced' ? '#EEF7F1'
              : syncStatus === 'loading' ? '#F3F0EA'
              : syncStatus === 'error'   ? '#FEF3F2'
              : '#F3F0EA',
            color: syncStatus === 'synced' ? '#173D2A'
              : syncStatus === 'error'   ? '#C0392B'
              : '#8A8A8A',
          }}>
            {syncStatus === 'synced'  ? '☁ 已同步'
           : syncStatus === 'loading' ? '同步中…'
           : syncStatus === 'error'   ? '⚠ 離線'
           : syncStatus === 'local'   ? '本地'
           : ''}
          </div>
          </div>
        </div>
      </div>

      <div style={{ height: 1, background: '#E6E1D6', margin: '0 24px' }} />

      {/* Tabs */}
      <div className="flex" style={{ borderBottom: '1px solid #E6E1D6', background: 'white' }}>
        {[['summary','總覽'],['items','明細'],['extra','追加']].map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)}
            className="flex-1 py-3 font-sans text-sm font-medium transition-colors border-b-2"
            style={{
              color: tab === id ? '#173D2A' : '#8A8A8A',
              borderBottomColor: tab === id ? '#173D2A' : 'transparent',
            }}>
            {label}
          </button>
        ))}
      </div>

      <div className="px-4 py-5 space-y-4">

        {/* ════ SUMMARY ════ */}
        {tab === 'summary' && (<>

          {/* Grand total */}
          <div className="rounded-2xl p-5" style={{ background: '#FFFFFF', border: '1px solid #E6E1D6' }}>
            <Label>旅行總花費 TRIP TOTAL</Label>
            <div style={{ fontFamily: 'Lora, Georgia, serif',
              fontSize: 'clamp(1.8rem, 8vw, 2.4rem)',
              color: '#173D2A', fontWeight: 700, lineHeight: 1, marginBottom: 4 }}>
              {fmtTWD(grandConfirmedTWD + userTotal)}
            </div>
            {userTotal > 0 && (
              <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, color: '#8A8A8A', marginBottom: 4 }}>
                預訂確認 {fmtTWD(grandConfirmedTWD)} + 旅途追加 {fmtTWD(userTotal)}
                <span style={{ color: '#C4952A', marginLeft: 4 }}>（NZD 以 {19.5} 換算）</span>
              </div>
            )}
            {userTotal === 0 && (
              <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, color: '#8A8A8A' }}>
                所有已確認預訂支出合計
              </div>
            )}

            <Hr />

            {/* Breakdown */}
            <Label>BREAKDOWN</Label>
            <CategoryBar label="機票 Flights"      amountTWD={flightsTotalTWD}  total={grandConfirmedTWD + userTotal} color="#2B7A8E" />
            <CategoryBar label="住宿 Accommodation" amountTWD={accommTotalTWD}   total={grandConfirmedTWD + userTotal} color="#173D2A" />
            <CategoryBar label="租車 Rental Car"    amountTWD={rentalTotalTWD}   total={grandConfirmedTWD + userTotal} color="#2E7D50" />
            <CategoryBar label="活動 Activities"    amountTWD={activityTotalTWD} total={grandConfirmedTWD + userTotal} color="#C4952A" />
            {userTotal > 0 && (
              <CategoryBar label="旅途追加 On-trip"  amountTWD={userTotal}        total={grandConfirmedTWD + userTotal} color="#9A7A2A" />
            )}
          </div>

          {/* Shared split */}
          <div className="rounded-2xl p-5" style={{ background: '#FFFFFF', border: '1px solid #E6E1D6' }}>
            <Label>SHARED EXPENSES · 2 人均攤</Label>
            <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1.6rem',
              color: '#173D2A', fontWeight: 700, marginBottom: 4 }}>
              {fmtTWD(confirmedSharedTWD)}
            </div>
            <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, color: '#8A8A8A', marginBottom: 12 }}>
              住宿 + 租車 + 活動（不含機票）
            </div>
            <div style={{ background: '#F3F0EA', borderRadius: 12, padding: '10px 14px',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 12, color: '#6B6B6B' }}>
                每人分攤
              </span>
              <span style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1.1rem',
                color: '#C4952A', fontWeight: 700 }}>
                {fmtTWD(perPersonSharedTWD, 0)}
              </span>
            </div>
          </div>

          {/* Personal cost per person */}
          <div className="rounded-2xl p-5" style={{ background: '#FFFFFF', border: '1px solid #E6E1D6' }}>
            <Label>PERSONAL TOTAL · 個人合計</Label>
            <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 10,
              color: '#A8A8A8', marginBottom: 12, letterSpacing: '0.03em' }}>
              個人費用（機票、eSIM 等）+ 均攤共同費用
            </div>
            <div className="space-y-3">
              {['東岳', '東振'].map(name => {
                const myConfirmed = confirmedPersonal.filter(e => e.traveler === name)
                const myConfirmedTotal = myConfirmed.reduce((s, e) => s + (e.TWD || 0), 0)
                const myUserExtra = userExpenses.filter(e => e.paidBy === name).reduce((s, e) => s + toTWD(e), 0)
                const total = myConfirmedTotal + perPersonSharedTWD + myUserExtra
                return (
                  <div key={name} style={{ background: '#F3F0EA', borderRadius: 12, padding: '10px 14px' }}>
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 12,
                          color: '#2A2A2A', fontWeight: 600, marginBottom: 3 }}>{name}</div>
                        {myConfirmed.map(item => (
                          <div key={item.id} style={{ fontFamily: 'Inter, sans-serif',
                            fontSize: 10, color: '#8A8A8A', lineHeight: 1.8 }}>
                            · {item.item.replace(name, '').trim()} {fmtTWD(item.TWD)}
                          </div>
                        ))}
                        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 10, color: '#8A8A8A', lineHeight: 1.8 }}>
                          · 均攤 {fmtTWD(perPersonSharedTWD, 0)}
                          {myUserExtra > 0 && ` · 追加 ${fmtTWD(myUserExtra, 0)}`}
                        </div>
                      </div>
                      <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1.05rem',
                        color: '#173D2A', fontWeight: 700, flexShrink: 0, marginLeft: 8 }}>
                        {fmtTWD(total, 0)}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Not included yet */}
          <div className="rounded-2xl p-5" style={{ background: '#FFFFFF', border: '1px solid #E6E1D6' }}>
            <Label>NOT INCLUDED YET · 尚未計入</Label>
            {upcomingExpenses.map(exp => (
              <div key={exp.id} className="flex justify-between py-2.5"
                style={{ borderBottom: '1px solid #F3F0EA' }}>
                <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 12, color: '#4A4A4A' }}>
                  {exp.item}
                </span>
                <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
                  color: exp.status === 'todo' ? '#C4952A' : '#A8A8A8', fontWeight: 500 }}>
                  {exp.status === 'todo' ? '待購買' : 'TBD'}
                </span>
              </div>
            ))}
            {userTotal > 0 && (
              <div className="flex justify-between pt-3"
                style={{ borderTop: '1px solid #E6E1D6', marginTop: 4 }}>
                <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 12, color: '#4A4A4A' }}>
                  追加記錄
                </span>
                <span style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1rem',
                  color: '#173D2A', fontWeight: 700 }}>
                  {fmtTWD(userTotal)}
                </span>
              </div>
            )}
          </div>
        </>)}

        {/* ════ ITEMS ════ */}
        {tab === 'items' && (
          <div className="space-y-2">
            <div style={{ fontSize: 9, letterSpacing: '0.18em', color: '#8A8A8A',
              fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', paddingLeft: 4, marginBottom: 8 }}>
              個人費用
            </div>
            {confirmedPersonal.map(exp => (
              <div key={exp.id} className="rounded-xl px-4 py-3"
                style={{ background: '#FFFFFF', border: '1px solid #E6E1D6' }}>
                <div className="flex justify-between items-start gap-3">
                  <div>
                    <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 13, color: '#2A2A2A', marginBottom: 2 }}>
                      {exp.item}
                    </div>
                    <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, color: '#A8A8A8' }}>
                      {exp.traveler} · 個人 · {exp.note}
                    </div>
                  </div>
                  <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1rem',
                    color: '#173D2A', fontWeight: 700, flexShrink: 0 }}>
                    {fmtTWD(exp.TWD)}
                  </div>
                </div>
              </div>
            ))}

            <div style={{ fontSize: 9, letterSpacing: '0.18em', color: '#8A8A8A',
              fontFamily: 'Inter, sans-serif', textTransform: 'uppercase',
              paddingLeft: 4, marginBottom: 8, marginTop: 16 }}>
              CONFIRMED SHARED · 2 PERSONS
            </div>
            {sharedLineItems.map(exp => {
              const cat = EXPENSE_CATEGORIES.find(c => c.id === exp.category)
              return (
                <div key={exp.id} className="rounded-xl px-4 py-3"
                  style={{ background: '#FFFFFF', border: '1px solid #E6E1D6' }}>
                  <div className="flex justify-between items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 13, color: '#2A2A2A' }}>
                          {exp.item}
                        </span>
                        <span className="category-pill text-white" style={{ background: cat?.color || '#8A8A8A' }}>
                          {cat?.label}
                        </span>
                      </div>
                      {exp.note && (
                        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, color: '#A8A8A8' }}>
                          {exp.note}
                        </div>
                      )}
                    </div>
                    <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1rem',
                      color: '#173D2A', fontWeight: 700, flexShrink: 0 }}>
                      {fmtTWD(exp.TWD)}
                    </div>
                  </div>
                </div>
              )
            })}

            <div className="rounded-xl px-4 py-3 mt-2"
              style={{ background: '#F3F0EA', border: '1px solid #E6E1D6' }}>
              <div className="flex justify-between">
                <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 12, color: '#6B6B6B', fontWeight: 600 }}>
                  Confirmed Grand Total
                </span>
                <span style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1.1rem',
                  color: '#173D2A', fontWeight: 700 }}>
                  {fmtTWD(grandConfirmedTWD)}
                </span>
              </div>
            </div>

            {/* User-added expenses in 明細 */}
            {userExpenses.length > 0 && (<>
              <div style={{ fontSize: 9, letterSpacing: '0.18em', color: '#8A8A8A',
                fontFamily: 'Inter, sans-serif', textTransform: 'uppercase',
                paddingLeft: 4, marginBottom: 8, marginTop: 20 }}>
                旅途追加支出
              </div>
              {userExpenses.map(exp => {
                const cat = EXPENSE_CATEGORIES.find(c => c.id === exp.category)
                return (
                  <div key={exp.id} className="rounded-xl px-4 py-3"
                    style={{ background: '#FFFFFF', border: '1px solid #E6E1D6' }}>
                    <div className="flex justify-between items-start gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 13, color: '#2A2A2A' }}>
                            {exp.item}
                          </span>
                          <span className="category-pill text-white" style={{ background: cat?.color || '#8A8A8A' }}>
                            {cat?.label}
                          </span>
                        </div>
                        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, color: '#A8A8A8' }}>
                          {exp.date}{exp.paidBy ? ` · ${exp.paidBy}` : ''}
                        </div>
                      </div>
                      <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1rem',
                        color: '#173D2A', fontWeight: 700, flexShrink: 0 }}>
                        {exp.currency === 'NZD' ? `NZ$ ${Number(exp.NZD).toLocaleString()}` : fmtTWD(toTWD(exp))}
                      </div>
                    </div>
                  </div>
                )
              })}
              <div className="rounded-xl px-4 py-3 mt-2"
                style={{ background: '#F3F0EA', border: '1px solid #E6E1D6' }}>
                <div className="flex justify-between">
                  <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 12, color: '#6B6B6B', fontWeight: 600 }}>
                    追加小計
                  </span>
                  <span style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1.1rem',
                    color: '#173D2A', fontWeight: 700 }}>
                    {fmtTWD(userTotal)}
                  </span>
                </div>
              </div>
            </>)}
          </div>
        )}

        {/* ════ EXTRA ════ */}
        {tab === 'extra' && (
          <div className="space-y-2">
            <div style={{ fontSize: 9, letterSpacing: '0.18em', color: '#8A8A8A',
              fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', paddingLeft: 4, marginBottom: 8 }}>
              旅途追加支出 (餐飲、購物、油費…)
            </div>
            {userExpenses.length === 0 ? (
              <div style={{
                background: '#FFFFFF', border: '1px dashed #D0CCC4',
                borderRadius: 12, padding: '32px 16px', textAlign: 'center',
                width: '100%', boxSizing: 'border-box',
              }}>
                <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '0.9rem',
                  color: '#C0B8AC', fontStyle: 'italic' }}>
                  尚無追加記錄
                </div>
                <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, color: '#A8A8A8', marginTop: 6 }}>
                  旅行期間可用 + 新增花費
                </div>
              </div>
            ) : (
              userExpenses.map(exp => {
                const cat = EXPENSE_CATEGORIES.find(c => c.id === exp.category)
                return (
                  <div key={exp.id} className="rounded-xl px-4 py-3"
                    style={{ background: '#FFFFFF', border: '1px solid #E6E1D6' }}>
                    <div className="flex justify-between items-start gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 13, color: '#2A2A2A' }}>
                            {exp.item}
                          </span>
                          <span className="category-pill text-white" style={{ background: cat?.color || '#8A8A8A' }}>
                            {cat?.label}
                          </span>
                        </div>
                        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, color: '#A8A8A8' }}>
                          {exp.date}{exp.paidBy ? ` · ${exp.paidBy}` : ''}
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 13,
                          color: '#2A2A2A', fontWeight: 600 }}>
                          {exp.currency === 'NZD' ? `NZ$ ${exp.NZD?.toLocaleString()}` : fmtTWD(toTWD(exp))}
                        </div>
                        {isAuthenticated && (
                          <button onClick={() => {
                            if (window.confirm(`刪除「${exp.item}」？`)) deleteExpense(exp.id)
                          }} style={{ color: '#CEC7B8', marginTop: 2 }}>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                              stroke="currentColor" strokeWidth="2">
                              <path d="M18 6L6 18M6 6l12 12"/>
                            </svg>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })
            )}
          </div>
        )}
      </div>

      {/* FAB */}
      <div className="fixed bottom-20 right-4 z-40 flex flex-col gap-2 items-end">
        {isAuthenticated && (
          <>
            <button onClick={exportJSON}
              className="rounded-full px-4 py-2 font-sans text-xs font-medium shadow-sm"
              style={{ background: '#FFFFFF', border: '1px solid #E6E1D6', color: '#4A4A4A' }}>
              匯出 JSON
            </button>
            <button onClick={logout}
              className="rounded-full px-4 py-2 font-sans text-xs font-medium shadow-sm"
              style={{ background: '#FFFFFF', border: '1px solid #E6E1D6', color: '#A8A8A8' }}>
              登出
            </button>
          </>
        )}
        <button onClick={handleAddClick}
          className="w-14 h-14 rounded-full shadow-lg flex items-center justify-center"
          style={{ background: '#173D2A', color: 'white' }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" strokeWidth="2.5">
            <path d="M12 5v14M5 12h14"/>
          </svg>
        </button>
      </div>

      {showPinGate && <PinGate onSuccess={handleAuth} onCancel={() => setShowPinGate(false)} />}
      {showForm && (
        <ExpenseForm
          onSave={exp => { addExpense(exp); setShowForm(false) }}
          onCancel={() => setShowForm(false)}
        />
      )}

      <div style={{ height: '5rem' }} />
    </div>
  )
}
