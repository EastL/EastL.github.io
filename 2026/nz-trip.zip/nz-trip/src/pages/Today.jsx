import { useMemo, useState } from 'react'
import {
  getTripStatus, getCurrentDay, getDaysUntilTrip,
  getDayData, formatDateLabel, getLocationZone, getCurrentFlight,
} from '../utils/nzTime'
import { TRIP } from '../data/config'
import { EMERGENCY_CONTACTS, ACTIVITIES } from '../data/trip'
import { getFoodQuestsForDate } from '../data/foodQuests'
import FoodQuestModal from '../components/FoodQuestModal'
import { useChecklist } from '../hooks/useChecklist'
import ChecklistOverlay from '../components/Checklist'
import DualClock from '../components/DualClock'
import OutfitCard from '../components/OutfitCard'
import OutfitOverview from '../components/OutfitOverview'
import { getOutfitForDate } from '../data/outfits'
import PhoneText from '../components/PhoneText'
import PlanB from '../components/PlanB'
import RouteStops from '../components/RouteStops'
import AuroraCard from '../components/AuroraCard'
import { getStopsForDate } from '../data/routes'

// ── Mountain silhouette ─────────────────────────────────────────────────────
function MountainSilhouette() {
  return (
    <svg viewBox="0 0 400 72" preserveAspectRatio="none"
      className="w-full block" style={{ marginBottom: -2 }} aria-hidden="true">
      <path
        d="M0,72 L0,52 C12,50 22,45 32,36 C42,27 48,18 56,11
           C62,6 66,12 72,7 C78,2 84,16 90,22 C96,28 102,19 108,14
           C114,9 120,26 128,34 C136,42 143,36 150,30
           C157,24 162,38 168,44 C174,50 180,42 186,36
           C192,30 198,46 206,52 C214,58 220,48 228,43
           C236,38 240,52 248,57 C256,62 262,54 270,49
           C278,44 283,58 292,63 C300,68 307,60 315,55
           C322,50 328,62 336,66 L400,68 L400,72 Z"
        fill="#0D2419"
      />
    </svg>
  )
}

function GoldLine({ width = 32 }) {
  return <div style={{ width, height: 2, background: '#C4952A', borderRadius: 2, marginBottom: 10 }} />
}

// ── Route strip ─────────────────────────────────────────────────────────────
const STOPS = [
  { zh: '新竹',   en: 'Hsinchu',      home: true    },
  { zh: '墨爾本', en: 'Melbourne',     transit: true },
  { zh: '基督城', en: 'Christchurch'               },
  { zh: '蒂卡波', en: 'Tekapo'                      },
  { zh: '庫克山', en: 'Mt Cook'                     },
  { zh: '瓦納卡', en: 'Wanaka'                      },
  { zh: '皇后鎮', en: 'Queenstown'                  },
  { zh: '布里斯本',en: 'Brisbane',    transit: true },
]

function RouteStrip({ currentStopEn = null }) {
  return (
    <div>
      <div style={{ fontSize: 9, letterSpacing: '0.25em', color: '#8A8A8A',
        fontFamily: 'Inter, sans-serif', textTransform: 'uppercase',
        marginBottom: 12, fontWeight: 600 }}>
        ROUTE 01 · SOUTH ISLAND
      </div>
      <div className="relative">
        <div style={{
          position: 'absolute', left: 6, right: 6, top: 6, height: 1,
          background: 'linear-gradient(90deg, #173D2A, #3D6E8A 70%, #9BBFD5)',
          opacity: 0.35,
        }} />
        <div className="flex justify-between items-start">
          {STOPS.map((stop) => {
            const isActive = stop.en === currentStopEn
            const isPast = currentStopEn &&
              STOPS.findIndex(s => s.en === currentStopEn) >
              STOPS.findIndex(s => s.en === stop.en)
            return (
              <div key={stop.en} className="flex flex-col items-center"
                style={{ maxWidth: 48, zIndex: 1 }}>
                <div
                  className={isActive ? 'dot-pulse' : ''}
                  style={{
                  width: isActive ? 12 : 8, height: isActive ? 12 : 8,
                  borderRadius: '50%', marginBottom: 7, flexShrink: 0,
                  background: isActive ? '#C4952A' : isPast ? '#173D2A' : '#FAF9F5',
                  border: `1.5px solid ${isActive ? '#F4EBC8' : isPast ? '#4A9B6F' : '#CEC7B8'}`,
                }} />
                <div style={{
                  fontFamily: 'Lora, Georgia, serif',
                  fontSize: 10, lineHeight: 1.2, textAlign: 'center',
                  color: isActive ? '#C4952A' : isPast ? '#173D2A' : '#4A4A4A',
                  fontWeight: isActive ? 700 : 400,
                }}>
                  {stop.zh}
                </div>
                {stop.last && (
                  <div style={{ fontSize: 9, color: '#C4952A', marginTop: 1 }}>✈ ZQN</div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

// ── Checklist Summary (Before Trip) ─────────────────────────────────────────
function ChecklistSummary({ onViewAll }) {
  const { doneCount, totalCount, todoItems } = useChecklist()
  const progress = totalCount > 0 ? (doneCount / totalCount) * 100 : 0

  return (
    <div style={{ borderTop: '1px solid #E6E1D6', paddingTop: 16, marginBottom: 16 }}>
      <div className="flex items-center justify-between mb-3">
        <div>
          <div style={{ fontSize: 9, letterSpacing: '0.22em', color: '#8A8A8A',
            fontFamily: 'Inter, sans-serif', textTransform: 'uppercase',
            fontWeight: 600, marginBottom: 3 }}>
            BEFORE TAKEOFF · 出發前準備
          </div>
          <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, color: '#4A4A4A' }}>
            <span style={{ fontWeight: 700, color: '#173D2A' }}>{doneCount}</span>
            <span style={{ color: '#A8A8A8' }}> / {totalCount} READY</span>
          </div>
        </div>
        <button onClick={onViewAll}
          style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
            color: '#3D6E8A', fontWeight: 600, letterSpacing: '0.05em',
            display: 'flex', alignItems: 'center', gap: 4 }}>
          查看全部
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" strokeWidth="2.5">
            <path d="M9 18l6-6-6-6"/>
          </svg>
        </button>
      </div>

      {/* Mini progress bar */}
      <div style={{ height: 3, background: '#E6E1D6', borderRadius: 99,
        overflow: 'hidden', marginBottom: 10 }}>
        <div style={{ height: '100%', background: '#C4952A', borderRadius: 99,
          width: `${progress}%`, transition: 'width 0.6s ease' }} />
      </div>

      {/* Up to 3 todo items */}
      {todoItems.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {todoItems.map(item => (
            <div key={item.id} style={{
              fontFamily: 'Inter, sans-serif', fontSize: 10,
              color: item.status === 'recheck' ? '#C4952A' : '#6B6B6B',
              background: item.status === 'recheck' ? '#FDF5E4' : '#F3F0EA',
              borderRadius: 999, padding: '3px 10px',
              border: `1px solid ${item.status === 'recheck' ? '#E8CE82' : '#E6E1D6'}`,
            }}>
              {item.status === 'recheck' ? '! ' : '○ '}{item.titleZh}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}


// ── Emergency Contact Block (collapsible) ─────────────────────────────────────
function EmergencyContacts() {
  const [open, setOpen] = useState(false)
  const typeColor = { emergency: '#C0392B', embassy: '#173D2A', service: '#3D6E8A' }
  const typeIcon  = { emergency: '🚨', embassy: '🇹🇼', service: '🚗' }

  return (
    <div style={{ borderTop: '1px solid #E6E1D6', marginTop: 16 }}>
      <button
        className="w-full flex items-center justify-between py-4"
        onClick={() => setOpen(o => !o)}
      >
        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 9,
          letterSpacing: '0.22em', color: '#8A8A8A',
          textTransform: 'uppercase', fontWeight: 600 }}>
          緊急聯絡資訊
        </div>
        <div style={{ color: '#A8A8A8', transform: open ? 'rotate(180deg)' : 'none',
          transition: 'transform 220ms ease', lineHeight: 1 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" strokeWidth="2"><path d="M6 9l6 6 6-6"/></svg>
        </div>
      </button>

      {open && (
        <div style={{ paddingBottom: 16 }} className="space-y-2">
          {EMERGENCY_CONTACTS.map(c => (
            <a key={c.id} href={`tel:${c.number.replace(/\s/g, '')}`}
              className="flex items-start justify-between gap-3 py-2.5"
              style={{ borderBottom: '1px solid #F3F0EA', display: 'flex', textDecoration: 'none' }}>
              <div>
                <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 12,
                  color: '#2A2A2A', marginBottom: 1 }}>
                  {typeIcon[c.type]} {c.label}
                </div>
                {c.note && (
                  <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 10, color: '#A8A8A8' }}>
                    <PhoneText text={c.note} />
                  </div>
                )}
              </div>
              <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 13,
                fontWeight: 700, color: typeColor[c.type] || '#2A2A2A',
                flexShrink: 0, textAlign: 'right' }}>
                {c.number}
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// BEFORE TRIP
// ─────────────────────────────────────────────────────────────────────────────
// ── 飛行中（依 getCurrentFlight 即時判斷） ──
function OnFlight() {
  const flight = getCurrentFlight()
  return flight ? (
    <div
      className="min-h-full"
      style={{
        background: '#FAF9F5',
      }}
    >
      <div
        className="relative overflow-hidden"
        style={{
          background: '#0D2030',
          paddingTop: '3.5rem',
          paddingBottom: 0,
        }}
      >
        <div
          style={{
            position: 'absolute',
            inset: 0,
            opacity: 0.3,
            background: 'radial-gradient(ellipse at 50% 0%, #1a3a5c 0%, transparent 70%)',
          }}
        />
        <div
          style={{
            padding: '48px 24px 32px',
            position: 'relative',
          }}
        >
          <div
            style={{
              fontSize: 10,
              letterSpacing: '0.22em',
              color: '#4A7A9B',
              fontFamily: 'Inter, sans-serif',
              textTransform: 'uppercase',
              fontWeight: 600,
              marginBottom: 16,
            }}
          >
            {flight.code}
            {' · 飛行中'}
          </div>
          <div
            style={{
              fontSize: '3rem',
              marginBottom: 12,
            }}
          >
            ✈️
          </div>
          <div
            style={{
              fontFamily: 'Lora, Georgia, serif',
              fontSize: 'clamp(1.4rem, 6vw, 2rem)',
              color: 'white',
              fontWeight: 700,
              lineHeight: 1.2,
              marginBottom: 6,
            }}
          >
            {flight.from}
            <span
              style={{
                color: '#4A7A9B',
                margin: '0 10px',
                fontWeight: 400,
              }}
            >
              →
            </span>
            {flight.to}
          </div>
          <div
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: 12,
              color: '#4A7A9B',
              marginBottom: 6,
            }}
          >
            {flight.dep}
            {' 出發 · '}
            {flight.arr}
            {' 抵達'}
          </div>
          <DualClock dark={true} layout="horizontal" size={56} />
        </div>
        <div className="relative">
          <MountainSilhouette />
        </div>
      </div>
      <div
        style={{
          background: '#0D2419',
        }}
      >
        <div
          style={{
            background: '#FAF9F5',
            padding: '24px 24px',
          }}
        >
          <EmergencyContacts />
        </div>
      </div>
      <div
        style={{
          height: '5rem',
        }}
      />
    </div>
  ) : null
}

function BeforeTrip({ daysUntil }) {
  const [showOutfitOverview, setShowOutfitOverview] = useState(false)
  const [showChecklist, setShowChecklist] = useState(false)

  return (
    <div className="min-h-full" style={{ background: '#FAF9F5' }}>
      {showChecklist && <ChecklistOverlay onClose={() => setShowChecklist(false)} />}

      {/* ── Green hero ── */}
      <div className="relative overflow-hidden"
        style={{ background: '#173D2A', paddingTop: '3.5rem', paddingBottom: 0 }}>
        <div className="absolute inset-0 pointer-events-none topo-pattern" style={{ opacity: 0.18 }} />

        <div className="relative flex justify-between items-start px-6 mb-8">
          <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 10,
            letterSpacing: '0.22em', color: '#6AAF87', textTransform: 'uppercase', fontWeight: 600 }}>
            NZ · 2026
          </span>
          <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 10,
            letterSpacing: '0.12em', color: '#4A9B6F', textTransform: 'uppercase' }}>
            TPE → CHC
          </span>
        </div>

        <div style={{ display:"flex", alignItems:"flex-end", padding:"0 16px 0 24px", gap:8 }}>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{
            fontFamily: 'Lora, Georgia, serif',
            fontSize: 'clamp(6rem, 24vw, 8.5rem)',
            lineHeight: 0.85, color: 'white', fontWeight: 700,
            letterSpacing: '-0.03em', marginBottom: 12,
          }}>
            {String(daysUntil).padStart(2, '0')}
          </div>
          <GoldLine width={40} />
          <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
            letterSpacing: '0.22em', color: '#6AAF87',
            textTransform: 'uppercase', lineHeight: 1.7, marginBottom: 20 }}>
            DAYS UNTIL<br />TAKEOFF
          </div>
          <div style={{ fontFamily: 'Lora, Georgia, serif',
            fontSize: 'clamp(1.4rem, 6vw, 2rem)',
            color: 'white', fontWeight: 600, lineHeight: 1.1, marginBottom: 5 }}>
            東東兄弟出走中
          </div>
          <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '0.85rem',
            color: '#4A9B6F', fontStyle: 'italic', marginBottom: 4 }}>
            South Island Road Trip
          </div>
          <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
            color: '#4A9B6F', letterSpacing: '0.06em',
            textTransform: 'uppercase', marginBottom: 0 }}>
            09 OCT – 18 OCT, 2026 · 10 DAYS
          </div>
        </div>{/* end text */}
        <div style={{ flexShrink:0, paddingBottom:16 }}>
          <DualClock dark={true} layout="horizontal" size={60} />
        </div>
        </div>{/* end flex */}

        <div className="relative"><MountainSilhouette /></div>
      </div>

      {/* ── Ivory section ── */}
      <div style={{ background: '#0D2419' }}>
        <div style={{ background: '#FAF9F5', padding: '24px 24px 8px' }}>

          {/* Checklist summary */}
          <ChecklistSummary onViewAll={() => setShowChecklist(true)} />

          {/* 出發前：穿搭總覽入口（打包時用）；出發前一天起改顯示出發日穿搭卡 */}
          {daysUntil > 1 && (
            <button onClick={() => setShowOutfitOverview(true)}
              className="w-full flex items-center justify-between"
              style={{ textAlign: 'left', borderTop: '1px solid #E6E1D6', paddingTop: 12, marginBottom: 16,
                background: 'none', borderLeft: 'none', borderRight: 'none', borderBottom: 'none', cursor: 'pointer' }}>
              <div>
                <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 9, letterSpacing: '0.18em', color: '#A8A8A8',
                  textTransform: 'uppercase', marginBottom: 2 }}>
                  WHAT TO WEAR · 10 DAYS
                </div>
                <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 12, color: '#4A4A4A' }}>
                  👕 穿搭總覽 · 洋蔥式穿法 · Christchurch 採購
                </div>
              </div>
              <div style={{ color: '#C4952A', fontSize: 13 }}>→</div>
            </button>
          )}
          {daysUntil > 1 && showOutfitOverview && <OutfitOverview onClose={() => setShowOutfitOverview(false)} />}
          {/* 出發前一天起：預告出發日穿搭 */}
          {daysUntil <= 1 && getOutfitForDate(TRIP.startDate) && (
            <div style={{ borderTop: '1px solid #E6E1D6', paddingTop: 16, marginBottom: 16 }}>
              <OutfitCard outfit={getOutfitForDate(TRIP.startDate)} label="出發日穿搭"
                onOpenOverview={() => setShowOutfitOverview(true)} />
              {showOutfitOverview && <OutfitOverview onClose={() => setShowOutfitOverview(false)} />}
            </div>
          )}

          {/* Route strip — before trip: current = 新竹 */}
          <div style={{ borderTop: '1px solid #E6E1D6', paddingTop: 16, marginBottom: 16 }}>
            <RouteStrip currentStopEn="Hsinchu" />
          </div>

          {/* Departure info */}
          <div style={{ paddingTop: 12, borderTop: '1px solid #E6E1D6', marginBottom: 4 }}>
            <div className="flex items-center justify-between">
              <div>
                <div style={{ fontSize: 9, letterSpacing: '0.2em', color: '#A8A8A8',
                  fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 3 }}>
                  DEPARTURE
                </div>
                <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '0.95rem',
                  color: '#173D2A', fontWeight: 600 }}>
                  08 October 2026
                </div>
                <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 10,
                  color: '#A8A8A8', marginTop: 2 }}>
                  23:30 · CI057 · TPE → MEL
                </div>
              </div>
              <div className="text-right">
                <div style={{ fontSize: 9, letterSpacing: '0.2em', color: '#A8A8A8',
                  fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 3 }}>
                  TRAVELLERS
                </div>
                <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '0.95rem',
                  color: '#173D2A', fontWeight: 600 }}>
                  02
                </div>
              </div>
              <div className="text-right">
                <div style={{ fontSize: 9, letterSpacing: '0.2em', color: '#A8A8A8',
                  fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 3 }}>
                  NIGHTS
                </div>
                <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '0.95rem',
                  color: '#173D2A', fontWeight: 600 }}>
                  09
                </div>
              </div>
            </div>
          </div>

          <EmergencyContacts />
        </div>
      </div>

      <div style={{ height: '5rem' }} />
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// DURING TRIP
// ─────────────────────────────────────────────────────────────────────────────
function DuringTrip({ currentDay }) {
  const dayData = getDayData(currentDay)
  const prevDay = currentDay > 1 ? getDayData(currentDay - 1) : null
  const nextDay = currentDay < TRIP.totalDays ? getDayData(currentDay + 1) : null
  if (!dayData) return null
  const [showFoodModal, setShowFoodModal] = useState(false)
  const [showChecklist, setShowChecklist] = useState(false)
  const foodData = getFoodQuestsForDate(dayData.date)
  const progress = currentDay / TRIP.totalDays
  const outfit = getOutfitForDate(dayData.date)
  const [showOutfitOverview, setShowOutfitOverview] = useState(false)
  const nextOutfit = nextDay ? getOutfitForDate(nextDay.date) : null

  // 精確位置：依 UTC 航班時間判斷，不是只看「第幾天」
  const zone = getLocationZone()
  const locationToStop = {
    'Melbourne (Transit)': 'Christchurch', // Day 1 itinerary city, but zone handles MEL
    'Christchurch':        'Christchurch',
    'Lake Tekapo':         'Tekapo',
    'Aoraki / Mt Cook':    'Mt Cook',
    'Wanaka':              'Wanaka',
    'Queenstown':          'Queenstown',
    'Milford Sound':       'Queenstown',
    'Taipei':              null,
  }
  // zone 優先：在飛機上或特定城市時覆蓋 itinerary 的位置
  const currentStopEn = zone === 'melbourne' ? 'Melbourne'
    : zone === 'brisbane' ? 'Brisbane'
    : zone === 'flight'   ? null  // 飛行中不高亮任何城市
    : locationToStop[dayData.location.en] || null

  return (
    <div className="min-h-full" style={{ background: '#FAF9F5' }}>
      {showFoodModal && foodData && (
        <FoodQuestModal date={dayData.date} data={foodData} onClose={() => setShowFoodModal(false)} />
      )}
      {showChecklist && <ChecklistOverlay onClose={() => setShowChecklist(false)} />}
      {/* Hero */}
      <div className="relative overflow-hidden"
        style={{ background: '#173D2A', paddingTop: '3.5rem', paddingBottom: 0 }}>
        <div className="absolute inset-0 pointer-events-none topo-pattern" style={{ opacity: 0.15 }} />

        <div className="relative flex justify-between items-start px-6 mb-5">
          <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 10,
            letterSpacing: '0.22em', color: '#6AAF87', textTransform: 'uppercase', fontWeight: 600 }}>
            DAY
          </span>
          <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 10,
            letterSpacing: '0.12em', color: '#4A9B6F', textTransform: 'uppercase' }}>
            NZ · SOUTH ISLAND
          </span>
        </div>

        <div style={{ display:'flex', alignItems:'flex-end', gap:8, padding:'0 16px 0 24px' }}>
        <div style={{ flex:1, minWidth:0 }}>
          <div className="flex items-end gap-2 mb-2">
            <span style={{
              fontFamily: 'Lora, Georgia, serif',
              fontSize: 'clamp(5rem, 20vw, 7rem)',
              lineHeight: 0.85, color: 'white', fontWeight: 700, letterSpacing: '-0.03em',
            }}>{String(currentDay).padStart(2, '0')}</span>
            <span style={{ fontFamily: 'Lora, Georgia, serif',
              fontSize: '1.1rem', color: 'rgba(255,255,255,0.4)',
              paddingBottom: 14, letterSpacing: '-0.01em' }}>
              / {TRIP.totalDays}
            </span>
          </div>
          <GoldLine width={40} />
          <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
            color: '#4A9B6F', letterSpacing: '0.06em', marginBottom: 14 }}>
            {formatDateLabel(dayData.date).toUpperCase()}
          </div>
          <div style={{ fontFamily: 'Lora, Georgia, serif',
            fontSize: 'clamp(1.5rem, 7vw, 2.2rem)',
            color: 'white', fontWeight: 700, lineHeight: 1.05, letterSpacing: '-0.01em', marginBottom: 4 }}>
            {dayData.location.en}
          </div>
          <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
            color: '#6AAF87', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 0 }}>
            {dayData.location.zh} · {dayData.region}
          </div>
        </div>{/* end text */}
        <div style={{ flexShrink:0, paddingBottom:16 }}>
          <DualClock dark={true} layout="horizontal" size={60} />
        </div>
        </div>{/* end flex */}

        <div className="relative"><MountainSilhouette /></div>
      </div>

      {/* Ivory content */}
      <div style={{ background: '#0D2419' }}>
        <div style={{ background: '#FAF9F5', padding: '20px 24px 0' }}>
          {/* Progress */}
          <div className="mb-5">
            <div style={{ height: 3, background: '#E6E1D6', borderRadius: 99, overflow: 'hidden', marginBottom: 6 }}>
              <div style={{ height: '100%', background: '#C4952A', borderRadius: 99,
                width: `${progress * 100}%`, transition: 'width 0.8s ease' }} />
            </div>
            <div className="flex justify-between">
              <span style={{ fontSize: 10, color: '#A8A8A8', fontFamily: 'Inter, sans-serif' }}>Oct 09</span>
              <span style={{ fontSize: 10, color: '#C4952A', fontFamily: 'Inter, sans-serif', fontWeight: 600 }}>
                {Math.round(progress * 100)}%
              </span>
              <span style={{ fontSize: 10, color: '#A8A8A8', fontFamily: 'Inter, sans-serif' }}>Oct 18</span>
            </div>
          </div>

          {/* 今日穿搭 */}
          {outfit && (
            <div className="mb-5">
              <OutfitCard outfit={outfit} onOpenOverview={() => setShowOutfitOverview(true)} />
              {showOutfitOverview && (
                <OutfitOverview initialDate={dayData.date} onClose={() => setShowOutfitOverview(false)} />
              )}
            </div>
          )}

          {/* 今晚極光 */}
          <AuroraCard date={dayData.date} />

          {/* Schedule */}
          {dayData.schedule.length > 0 && (
            <div className="mb-5">
              <div style={{ fontSize: 9, letterSpacing: '0.22em', color: '#8A8A8A',
                fontFamily: 'Inter, sans-serif', textTransform: 'uppercase',
                fontWeight: 600, marginBottom: 12 }}>
                TODAY'S JOURNEY
              </div>
              {dayData.schedule.map((item, i) => (
                <div key={i} className="flex gap-4 py-2.5"
                  style={{ borderBottom: i < dayData.schedule.length - 1 ? '1px solid #F3F0EA' : 'none' }}>
                  <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 12,
                    color: '#3D6E8A', fontWeight: 500, width: 44, flexShrink: 0 }}>
                    {item.time || ''}
                  </span>
                  <div>
                    <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 13,
                      color: '#2A2A2A', lineHeight: 1.4 }}>
                      {item.activity}
                    </div>
                    {item.note && (
                      <div style={{ fontSize: 11, color: '#A8A8A8', marginTop: 2, fontFamily: 'Inter, sans-serif' }}>
                        <PhoneText text={item.note} />
                      </div>
                    )}
                    {item.activityId && <PlanB text={ACTIVITIES.find(x => x.id === item.activityId)?.planB} />}
                  </div>
                </div>
              ))}
            </div>
          )}

          <RouteStops stops={getStopsForDate(dayData.date)} style={{ marginTop: 0, marginBottom: 16 }} />

          {/* Yday/Today/Tmrw */}
          <div style={{ borderTop: '1px solid #E6E1D6', paddingTop: 16, marginBottom: 16 }}>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <div style={{ fontSize: 9, letterSpacing: '0.18em', color: '#A8A8A8',
                  fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 5 }}>YDAY</div>
                <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '0.85rem',
                  color: '#A8A8A8', lineHeight: 1.2 }}>
                  {prevDay ? prevDay.location.zh : '—'}
                </div>
              </div>
              <div style={{ borderLeft: '1px solid #E6E1D6', borderRight: '1px solid #E6E1D6',
                paddingLeft: 10, paddingRight: 10 }}>
                <div style={{ fontSize: 9, letterSpacing: '0.18em', color: '#C4952A',
                  fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 5, fontWeight: 700 }}>
                  TODAY
                </div>
                <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '0.85rem',
                  color: '#173D2A', fontWeight: 700, lineHeight: 1.2 }}>
                  {dayData.location.zh}
                </div>
              </div>
              <div>
                <div style={{ fontSize: 9, letterSpacing: '0.18em', color: '#A8A8A8',
                  fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 5 }}>TMRW</div>
                <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '0.85rem',
                  color: '#4A4A4A', lineHeight: 1.2 }}>
                  {nextDay ? nextDay.location.zh : '返台 ✈'}
                </div>
                {nextOutfit && (
                  <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 10, color: '#8A8A8A', marginTop: 4 }}>
                    {nextOutfit.icon} {nextOutfit.theme}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Route */}
          <div style={{ borderTop: '1px solid #E6E1D6', paddingTop: 16, marginBottom: 4 }}>
            <RouteStrip currentStopEn={currentStopEn} />
          </div>

          {/* Food Quest entry */}
          {foodData && (
            <div style={{ borderTop: '1px solid #E6E1D6', paddingTop: 12, marginTop: 12 }}>
              <button onClick={() => setShowFoodModal(true)}
                className="w-full flex items-center justify-between"
                style={{ textAlign: 'left' }}>
                <div>
                  <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 9,
                    letterSpacing: '0.18em', color: '#A8A8A8',
                    textTransform: 'uppercase', marginBottom: 2 }}>
                    FOOD QUEST · {foodData.quests.length}
                  </div>
                  <div style={{ fontFamily: 'Inter, sans-serif',
                    fontSize: 12, color: '#4A4A4A' }}>
                    {foodData.quests.map(q => q.emoji + ' ' + q.food).join(' · ')}
                  </div>
                </div>
                <div style={{ color: '#C4952A', fontSize: 13 }}>→</div>
              </button>
            </div>
          )}

          {dayData.accommodation && (
            <div style={{ borderTop: '1px solid #E6E1D6', paddingTop: 12, marginTop: 12 }}>
              <span style={{ fontSize: 9, letterSpacing: '0.18em', color: '#A8A8A8',
                fontFamily: 'Inter, sans-serif', textTransform: 'uppercase' }}>STAY</span>
              <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 12,
                color: '#4A4A4A', marginLeft: 10 }}>
                {dayData.accommodation.name}
              </span>
              {dayData.accommodation.phone && (
                <a href={`tel:${dayData.accommodation.phone}`}
                  style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
                    color: '#3D6E8A', marginLeft: 10 }}>
                  {dayData.accommodation.phone}
                </a>
              )}
            </div>
          )}

          <div style={{ borderTop: '1px solid #E6E1D6', paddingTop: 16, marginTop: 8 }}>
            <button onClick={() => setShowChecklist(true)}
              className="w-full flex items-center justify-between">
              <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 9,
                letterSpacing: '0.22em', color: '#8A8A8A',
                textTransform: 'uppercase', fontWeight: 600 }}>
                出發前準備清單
              </div>
              <div style={{ color: '#C4952A', fontSize: 13 }}>→</div>
            </button>
          </div>
          <EmergencyContacts />
        </div>
      </div>

      <div style={{ height: '5rem' }} />
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// AFTER TRIP
// ─────────────────────────────────────────────────────────────────────────────
// ── 墨爾本轉機（CI057 抵達 → QF169 起飛之間） ──
function MelbourneLayover() {
  const [showChecklist, setShowChecklist] = useState(false)
  return (
    <div
      className="min-h-full"
      style={{
        background: '#FAF9F5',
      }}
    >
      {showChecklist && <ChecklistOverlay onClose={() => setShowChecklist(false)} />}
      <div
        className="relative overflow-hidden"
        style={{
          background: '#173D2A',
          paddingTop: '3.5rem',
          paddingBottom: 0,
        }}
      >
        <div
          style={{
            padding: '48px 24px 32px',
          }}
        >
          <div
            style={{
              fontSize: 10,
              letterSpacing: '0.22em',
              color: '#4A9B6F',
              fontFamily: 'Inter, sans-serif',
              textTransform: 'uppercase',
              fontWeight: 600,
              marginBottom: 16,
            }}
          >
            🇦🇺 墨爾本中轉
          </div>
          <div
            style={{
              fontFamily: 'Lora, Georgia, serif',
              fontSize: 'clamp(1.4rem, 6vw, 2rem)',
              color: 'white',
              fontWeight: 700,
              lineHeight: 1.2,
              marginBottom: 6,
            }}
          >
            Melbourne Transit
          </div>
          <div
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: 12,
              color: '#6AAF87',
              marginBottom: 20,
            }}
          >
            QF169 18:40 出發 · 下一站基督城
          </div>
          <DualClock dark={true} layout="horizontal" size={56} />
        </div>
        <div className="relative">
          <MountainSilhouette />
        </div>
      </div>
      <div
        style={{
          background: '#0D2419',
        }}
      >
        <div
          style={{
            background: '#FAF9F5',
            padding: '24px',
          }}
        >
          <div
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: 9,
              letterSpacing: '0.18em',
              color: '#8A8A8A',
              textTransform: 'uppercase',
              marginBottom: 8,
            }}
          >
            TRANSIT MISSION
          </div>
          <div
            style={{
              background: '#EEF7F1',
              borderRadius: 12,
              padding: '12px 14px',
              marginBottom: 16,
              border: '1px solid #B8DFC8',
            }}
          >
            <div
              style={{
                fontFamily: 'Inter, sans-serif',
                fontSize: 12,
                color: '#173D2A',
                marginBottom: 4,
                fontWeight: 600,
              }}
            >
              🎯 Hosier Lane 塗鴉街
            </div>
            <div
              style={{
                fontFamily: 'Inter, sans-serif',
                fontSize: 12,
                color: '#4A4A4A',
                marginBottom: 4,
              }}
            >
              ☕ Melbourne Flat White
            </div>
            <div
              style={{
                fontFamily: 'Inter, sans-serif',
                fontSize: 12,
                color: '#4A4A4A',
              }}
            >
              🥧 Aussie Meat Pie
            </div>
          </div>
          <div
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: 11,
              color: '#C0392B',
              background: '#FEF3F2',
              borderRadius: 8,
              padding: '7px 12px',
              marginBottom: 16,
            }}
          >
            ⚠️ 15:30 Hard Deadline — 搭 SkyBus 回機場
          </div>
          <button
            onClick={() => setShowChecklist(true)}
            className="w-full flex items-center justify-between"
            style={{
              marginTop: 8,
            }}
          >
            <div
              style={{
                fontFamily: 'Inter, sans-serif',
                fontSize: 9,
                letterSpacing: '0.22em',
                color: '#8A8A8A',
                textTransform: 'uppercase',
                fontWeight: 600,
              }}
            >
              出發前準備清單
            </div>
            <div
              style={{
                color: '#C4952A',
                fontSize: 13,
              }}
            >
              →
            </div>
          </button>
          <EmergencyContacts />
        </div>
      </div>
      <div
        style={{
          height: '5rem',
        }}
      />
    </div>
  )
}

function AfterTrip() {
  const [showChecklist, setShowChecklist] = useState(false)
  return (
    <div className="min-h-full" style={{ background: '#FAF9F5' }}>
      <div className="relative overflow-hidden"
        style={{ background: '#173D2A', paddingTop: '3.5rem', paddingBottom: 0 }}>
        <div className="absolute inset-0 pointer-events-none topo-pattern" style={{ opacity: 0.15 }} />
        <div className="relative px-6">
          <div style={{ fontSize: 10, letterSpacing: '0.22em', color: '#6AAF87',
            fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 24 }}>
            NZ · 2026
          </div>
          <div style={{ fontFamily: 'Lora, Georgia, serif',
            fontSize: 'clamp(4.5rem, 18vw, 6.5rem)',
            lineHeight: 0.85, color: 'white', fontWeight: 700,
            letterSpacing: '-0.03em', marginBottom: 12 }}>
            10<br />Days
          </div>
          <GoldLine width={40} />
          <div style={{ fontSize: 11, letterSpacing: '0.22em', color: '#6AAF87',
            fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 16 }}>
            TRIP COMPLETED
          </div>
          <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1.4rem',
            color: 'white', fontWeight: 600, marginBottom: 4 }}>
            東東兄弟出走完畢
          </div>
          <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
            color: '#4A9B6F', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 28 }}>
            09 OCT – 18 OCT, 2026
          </div>
        </div>
        <MountainSilhouette />
      </div>
      <div style={{ background: '#0D2419' }}>
        <div style={{ background: '#FAF9F5', padding: '24px 24px' }}>
          <RouteStrip currentStopEn="Hsinchu" />
          <div style={{ borderTop: '1px solid #E6E1D6', paddingTop: 16, marginTop: 16 }}>
            <button onClick={() => setShowChecklist(true)}
              className="w-full flex items-center justify-between">
              <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 9,
                letterSpacing: '0.22em', color: '#8A8A8A',
                textTransform: 'uppercase', fontWeight: 600 }}>
                出發前準備清單
              </div>
              <div style={{ color: '#C4952A', fontSize: 13 }}>→</div>
            </button>
          </div>
          <EmergencyContacts />
        </div>
      </div>
      {showChecklist && <ChecklistOverlay onClose={() => setShowChecklist(false)} />}
      <div style={{ height: '5rem' }} />
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────────────────────────────────────
export default function Today() {
  const status     = useMemo(getTripStatus, [])
  const currentDay = useMemo(getCurrentDay, [])
  const daysUntil  = useMemo(getDaysUntilTrip, [])
  const zone       = getLocationZone()

  // 飛行中 / 墨爾本轉機 優先於日期狀態
  if (zone === 'flight')    return <OnFlight />
  if (zone === 'melbourne') return <MelbourneLayover />
  if (status === 'before') return <BeforeTrip daysUntil={daysUntil} />
  if (status === 'after')  return <AfterTrip />
  return <DuringTrip currentDay={currentDay} />
}
