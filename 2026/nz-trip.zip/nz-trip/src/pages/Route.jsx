// 冒險頁：overview 地圖（自動播放）＋ Road Book 列表，點任一天開 DayModal
import { useState } from 'react'
import LeafletMap from '../components/LeafletMap'
import DayModal from '../components/DayModal'
import { ROUTE_SEGMENTS } from '../data/routes'
import { getTripStatus, getCurrentDay } from '../utils/nzTime'

const tripStatus = getTripStatus()
const currentDay = tripStatus === 'during' ? getCurrentDay() : null
const drivingSegs = ROUTE_SEGMENTS.filter(e => e.driving && e.km)
const totalKm = drivingSegs.reduce((e, t) => e + t.km, 0)
function RoadBookEntry({ seg, isToday, onClick }) {
  const isCompleted = currentDay != null && seg.day < currentDay,
    isUpcoming = currentDay == null || seg.day > currentDay
  return (
    <button
      onClick={onClick}
      style={{
        width: '100%',
        textAlign: 'left',
        background: isToday ? '#EEF7F1' : 'white',
        border: '1px solid',
        borderColor: isToday ? '#B8DFC8' : '#E6E1D6',
        borderRadius: 12,
        padding: '12px 16px',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        marginBottom: 6,
      }}
    >
      {seg.type === 'flight' ? (
        <span
          style={{
            fontSize: 16,
            flexShrink: 0,
            lineHeight: 1,
          }}
        >
          ✈️
        </span>
      ) : (
        <div
          className={isToday ? 'dot-pulse' : ''}
          style={{
            width: 10,
            height: 10,
            borderRadius: '50%',
            flexShrink: 0,
            background: isToday ? '#C4952A' : isCompleted ? '#173D2A' : '#CEC7B8',
            border: `2px solid ${isToday ? '#F4EBC8' : isCompleted ? '#4A9B6F' : '#E6E1D6'}`,
          }}
        />
      )}
      <div
        style={{
          flex: 1,
          minWidth: 0,
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            marginBottom: 1,
          }}
        >
          <span
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: 9,
              letterSpacing: '0.18em',
              color: isToday ? '#C4952A' : '#8A8A8A',
              textTransform: 'uppercase',
              fontWeight: 700,
            }}
          >
            {'DAY '}
            {String(seg.day).padStart(2, '0')}
          </span>
          {isToday && (
            <span
              style={{
                fontFamily: 'Inter, sans-serif',
                fontSize: 9,
                background: '#FFF3E0',
                color: '#C4952A',
                borderRadius: 999,
                padding: '1px 6px',
                fontWeight: 700,
              }}
            >
              NOW
            </span>
          )}
        </div>
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: 13,
            color: isUpcoming ? '#A8A8A8' : '#2A2A2A',
            fontWeight: 500,
          }}
        >
          {seg.driving ? (
            <>
              {seg.fromZh}{' '}
              <span
                style={{
                  color: '#C4952A',
                  margin: '0 2px',
                }}
              >
                →
              </span>{' '}
              {seg.toZh}
            </>
          ) : (
            seg.toZh
          )}
        </div>
      </div>
      {seg.driving && seg.km && (
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: 11,
            color: '#A8A8A8',
            flexShrink: 0,
            textAlign: 'right',
            lineHeight: 1.4,
          }}
        >
          {seg.km}
          {' km'}
          <br />
          <span
            style={{
              fontSize: 10,
            }}
          >
            ~{seg.hours}h
          </span>
        </div>
      )}
      <div
        style={{
          color: '#C0B8AC',
          fontSize: 14,
          flexShrink: 0,
        }}
      >
        ›
      </div>
    </button>
  )
}
function Route() {
  const [selectedSeg, setSelectedSeg] = useState(null)
  return (
    <div
      className="min-h-full"
      style={{
        background: '#FAF9F5',
        paddingBottom: '5rem',
      }}
    >
      <div
        style={{
          padding: '56px 24px 20px',
        }}
      >
        <div
          style={{
            fontSize: 10,
            letterSpacing: '0.22em',
            color: '#8A8A8A',
            fontFamily: 'Inter, sans-serif',
            textTransform: 'uppercase',
            fontWeight: 600,
            marginBottom: 8,
          }}
        >
          NZ · 2026
        </div>
        <div
          style={{
            fontFamily: 'Lora, Georgia, serif',
            fontSize: '2.2rem',
            color: '#173D2A',
            fontWeight: 700,
            lineHeight: 0.95,
            letterSpacing: '-0.02em',
          }}
        >
          南島冒險
        </div>
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: 11,
            color: '#8A8A8A',
            marginTop: 8,
          }}
        >
          總里程 ~{totalKm}
          {' km · '}
          {drivingSegs.length}
          {' 段自駕 · 10 月 9–17 日'}
        </div>
      </div>
      <div
        className="mx-4 rounded-2xl overflow-hidden"
        style={{
          height: '50vw',
          maxHeight: '320px',
          border: '1px solid #E6E1D6',
        }}
      >
        <LeafletMap currentDay={currentDay} tripStatus={tripStatus} />
      </div>
      <div className="px-6 mt-3 flex items-center gap-4 flex-wrap">
        {[
          {
            color: '#C4952A',
            label: '公路',
            dash: false,
          },
          {
            color: '#3D6E8A',
            label: '飛行',
            dash: true,
          },
        ].map(({ color: i, label: o, dash: a }) => (
          <div key={o} className="flex items-center gap-1.5">
            <div
              style={{
                width: 20,
                height: 2,
                background: a ? 'none' : i,
                borderTop: a ? `2px dashed ${i}` : 'none',
                borderRadius: 2,
              }}
            />
            <span
              style={{
                fontSize: 10,
                color: '#6B6B6B',
                fontFamily: 'Inter',
              }}
            >
              {o}
            </span>
          </div>
        ))}
      </div>
      <div
        style={{
          padding: '20px 16px 0',
        }}
      >
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: 9,
            letterSpacing: '0.22em',
            color: '#8A8A8A',
            textTransform: 'uppercase',
            fontWeight: 600,
            marginBottom: 12,
          }}
        >
          ROAD BOOK · 點擊查看路況與天氣
        </div>
        {ROUTE_SEGMENTS.map(i => (
          <RoadBookEntry key={i.day} seg={i} isToday={currentDay === i.day} onClick={() => setSelectedSeg(i)} />
        ))}
      </div>
      {selectedSeg && <DayModal seg={selectedSeg} onClose={() => setSelectedSeg(null)} />}
    </div>
  )
}
export default Route
