const tabs = [
  {
    id: 'today',
    label: 'Today',
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="10" r="3" stroke="currentColor" strokeWidth={active ? 2 : 1.5}/>
        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"
          stroke="currentColor" strokeWidth={active ? 2 : 1.5}
          fill={active ? 'currentColor' : 'none'} fillOpacity={active ? 0.12 : 0}/>
      </svg>
    ),
  },
  {
    id: 'itinerary',
    label: '行程',
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <rect x="4" y="4" width="16" height="16" rx="2"
          stroke="currentColor" strokeWidth={active ? 2 : 1.5}/>
        <line x1="8" y1="9"  x2="16" y2="9"  stroke="currentColor" strokeWidth={active ? 2 : 1.5} strokeLinecap="round"/>
        <line x1="8" y1="13" x2="16" y2="13" stroke="currentColor" strokeWidth={active ? 2 : 1.5} strokeLinecap="round"/>
        <line x1="8" y1="17" x2="12" y2="17" stroke="currentColor" strokeWidth={active ? 2 : 1.5} strokeLinecap="round"/>
      </svg>
    ),
  },
  {
    id: 'route',
    label: '冒險',
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M3 12 C3 6, 9 3, 12 3 C15 3, 21 6, 21 12 C21 18, 15 21, 12 21 C9 21, 3 18, 3 12Z"
          stroke="currentColor" strokeWidth={active ? 2 : 1.5}/>
        <line x1="3" y1="12" x2="21" y2="12" stroke="currentColor" strokeWidth="0.8" strokeDasharray="2 2"/>
        <line x1="12" y1="3" x2="12" y2="21" stroke="currentColor" strokeWidth="0.8" strokeDasharray="2 2"/>
      </svg>
    ),
  },
  {
    id: 'expenses',
    label: '燒錢',
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <rect x="2" y="6" width="20" height="13" rx="2"
          stroke="currentColor" strokeWidth={active ? 2 : 1.5}/>
        <circle cx="12" cy="13" r="3" stroke="currentColor" strokeWidth={active ? 2 : 1.5}/>
        <path d="M2 10h20" stroke="currentColor" strokeWidth="1.5"/>
      </svg>
    ),
  },
]

export default function BottomNav({ active, onChange }) {
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50"
      style={{
        background: 'rgba(252, 251, 248, 0.96)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        borderTop: '1px solid #E6E1D6',
        boxShadow: '0 -1px 12px rgba(0,0,0,0.06)',
      }}
    >
      <div className="flex" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        {tabs.map((tab) => {
          const isActive = active === tab.id
          return (
            <button
              key={tab.id}
              onClick={() => onChange(tab.id)}
              className="flex-1 flex flex-col items-center justify-center pt-3 pb-2.5 gap-1 relative transition-colors duration-150"
              style={{ color: isActive ? '#173D2A' : '#8A8A8A' }}
            >
              {tab.icon(isActive)}
              <span className="text-[10px] font-sans font-medium tracking-wide"
                style={{ color: isActive ? '#173D2A' : '#8A8A8A' }}>
                {tab.label}
              </span>
              {/* Gold active indicator dot */}
              {isActive && (
                <span className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full"
                  style={{ backgroundColor: '#C4952A' }} />
              )}
            </button>
          )
        })}
      </div>
    </nav>
  )
}
