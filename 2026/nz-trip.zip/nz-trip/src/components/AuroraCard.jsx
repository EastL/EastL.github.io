import { useAurora } from '../hooks/useAurora'
import { AURORA_META, TASSIE_AURORA_URL, gScale } from '../data/aurora'
import { getWeatherPoint } from '../hooks/useDailyForecast'

const SANS = 'Inter, sans-serif'

function AppLink({ strong }) {
  return (
    <a href={TASSIE_AURORA_URL} target="_blank" rel="noopener noreferrer"
      style={strong
        ? { display: 'inline-block', marginTop: 10, fontFamily: SANS, fontSize: 12, fontWeight: 700,
            color: 'white', background: '#2D2A4A', borderRadius: 8, padding: '7px 12px', textDecoration: 'none' }
        : { fontFamily: SANS, fontSize: 11, color: '#6B46C1', textDecoration: 'none', fontWeight: 600 }}>
      開 Tassie Aurora{strong ? '（強極光通知）' : ''} ↗
    </a>
  )
}

// Today：今晚極光（機會低只顯示一行；有機會才變成醒目卡片）
export default function AuroraCard({ date }) {
  const a = useAurora(date)
  if (!getWeatherPoint(date) || !a) return null

  const line = { fontFamily: SANS, fontSize: 11, color: '#8A8A8A', display: 'flex', gap: 8,
    alignItems: 'center', flexWrap: 'wrap', marginBottom: 16 }

  if (a.error || a.kp == null) {
    return (
      <div style={line} data-aurora="none">
        <span>🌌 今晚極光：資料暫時抓不到</span><AppLink />
      </div>
    )
  }

  const kpText = `Kp 最高 ${a.kp.toFixed(1)}${gScale(a.kp) ? `（${gScale(a.kp)} 地磁風暴）` : ''}`
  const cloudText = a.cloud != null ? ` · 雲量 ${a.cloud}%` : ''
  const meta = AURORA_META[a.level]

  if (a.level === 'low') {
    return (
      <div style={line} data-aurora="low">
        <span>🌌 今晚極光：{meta.zh} · {kpText}{cloudText}</span><AppLink />
      </div>
    )
  }

  const tips = a.level === 'cloudy'
    ? [`Kp 夠高，但今晚雲量 ${a.cloud}%，大概會被雲擋住`, '雲可能會散，睡前再打開看一次']
    : [
        '22:00–02:00 朝南方地平線看，離開路燈和市區光害',
        a.level === 'high'
          ? '肉眼可能看到光柱和顏色，手機夜景模式拍更明顯'
          : '肉眼多半只看到淡淡白光，手機夜景模式 / 長曝光拍得出顏色',
      ]

  return (
    <div data-aurora={a.level} style={{ marginBottom: 16, borderRadius: 14, overflow: 'hidden',
      border: `1px solid ${meta.color}55`, background: a.level === 'cloudy' ? '#F4F6F8' : '#F5F1FF' }}>
      <div style={{ padding: '12px 14px' }}>
        <div style={{ fontFamily: SANS, fontSize: 9, letterSpacing: '0.2em', color: meta.color,
          textTransform: 'uppercase', fontWeight: 700 }}>
          🌌 今晚極光 · {meta.zh}
        </div>
        <div style={{ fontFamily: SANS, fontSize: 13, color: '#2A2A2A', marginTop: 6, fontWeight: 600 }}>
          {kpText}{cloudText}
        </div>
        {tips.map(t => (
          <div key={t} style={{ fontFamily: SANS, fontSize: 12, color: '#4A4A4A', marginTop: 4, lineHeight: 1.5 }}>・{t}</div>
        ))}
        <AppLink strong />
        <div style={{ fontFamily: SANS, fontSize: 10, color: '#A8A8A8', marginTop: 8 }}>
          資料：NOAA Kp 預報＋Open-Meteo 雲量 · 網站打開時才更新，即時通知請開 App
        </div>
      </div>
    </div>
  )
}
