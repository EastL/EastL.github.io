// 全螢幕單日 modal：地圖 + 航班/路況/活動/天氣 + Google Maps 按鈕
import { useEffect } from 'react'
import LeafletMap from './LeafletMap'
import WeatherCard from './WeatherCard'
import MelbourneMission from './MelbourneMission'
import RightHandDriveCard from './RightHandDriveCard'
import PlanB from './PlanB'
import RouteStops from './RouteStops'
import { getActivitiesForDate } from '../data/trip'
import { getTripStatus, getCurrentDay } from '../utils/nzTime'

// iOS 用 comgooglemaps:// 直接開 Google Maps app；其他平台直接導向網頁版
function openGoogleMaps(url) {
  if (/iPad|iPhone|iPod/.test(navigator.userAgent)) {
    const parts = url.replace('https://www.google.com/maps/dir/', '').split('/'),
      from = (parts[0] || '').replace(/\+/g, ' '),
      to = (parts[1] || '').replace(/\+/g, ' ')
    window.location.href = `comgooglemaps://?saddr=${encodeURIComponent(from)}&daddr=${encodeURIComponent(to)}&directionsmode=driving`
  } else window.location.href = url
}
// 出發點附近加油站：iOS 直接開 Google Maps app 搜尋，其他平台開網頁版
// （Gaspy 只有 app、API 需登入，也沒有公開的 URL scheme，網站無法直接顯示油價或開啟 Gaspy）
function openFuelMap([lat, lng]) {
  if (/iPad|iPhone|iPod/.test(navigator.userAgent)) {
    window.location.href = `comgooglemaps://?q=petrol+station&center=${lat},${lng}&zoom=13`
  } else {
    window.location.href = `https://www.google.com/maps/search/petrol+station/@${lat},${lng},13z`
  }
}

// 出發前檢查的小方塊：href = 外部網站（開新分頁），onClick = 開 App
function ToolTile({ href, onClick, icon, title, sub }) {
  const style = {
    display: 'block', textAlign: 'left', background: 'white', border: '1px solid #E6E1D6', borderRadius: 12,
    padding: '10px 12px', cursor: 'pointer', textDecoration: 'none', fontFamily: 'Inter, sans-serif', width: '100%',
  }
  const body = (
    <>
      <div style={{ fontSize: 13, fontWeight: 600, color: '#173D2A' }}>{icon} {title}{href && <span style={{ color: '#A8A8A8' }}> ↗</span>}</div>
      <div style={{ fontSize: 10, color: '#8A8A8A', marginTop: 3, lineHeight: 1.4 }}>{sub}</div>
    </>
  )
  return href ? (
    <a href={href} target="_blank" rel="noopener noreferrer" style={style}>{body}</a>
  ) : (
    <button onClick={onClick} style={style}>{body}</button>
  )
}

function DayModal({ seg, onClose }) {
  const activities = getActivitiesForDate(seg.date),
    tripStatus = getTripStatus(),
    currentDay = tripStatus === 'during' ? getCurrentDay() : null,
    isToday = currentDay === seg.day
  // 開 modal 時鎖住背景捲動
  useEffect(() => {
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = ''
    }
  }, [])
  const dest = seg.coords[seg.coords.length - 1]
  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 1100,
        display: 'flex',
        flexDirection: 'column',
        background: '#FAF9F5',
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          // 主畫面 app（black-translucent 狀態列）時往下讓出狀態列高度，✕ 才按得到；Safari 中為 0
          padding: 'calc(14px + env(safe-area-inset-top)) 16px 12px',
          background: '#173D2A',
          flexShrink: 0,
        }}
      >
        <div>
          <div
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: 9,
              letterSpacing: '0.2em',
              color: '#6AAF87',
              textTransform: 'uppercase',
              marginBottom: 2,
            }}
          >
            {isToday ? '📍 TODAY · ' : ''}
            {'DAY '}
            {String(seg.day).padStart(2, '0')}
          </div>
          <div
            style={{
              fontFamily: 'Lora, Georgia, serif',
              fontSize: '1.1rem',
              color: 'white',
              fontWeight: 700,
            }}
          >
            {seg.driving ? (
              <>
                {seg.fromZh}{' '}
                <span
                  style={{
                    color: '#C4952A',
                  }}
                >
                  →
                </span>{' '}
                {seg.toZh}
              </>
            ) : (
              seg.toZh
            )}
          </div>
        </div>
        <button
          onClick={onClose}
          style={{
            color: 'rgba(255,255,255,0.7)',
            background: 'rgba(255,255,255,0.1)',
            border: 'none',
            borderRadius: '50%',
            width: 36,
            height: 36,
            cursor: 'pointer',
            fontSize: 18,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          ✕
        </button>
      </div>
      <div
        style={{
          height: seg.day === 1 || seg.day === 2 || seg.day === 10 ? '30%' : '52%',
          flexShrink: 0,
        }}
      >
        <LeafletMap
          currentDay={currentDay}
          tripStatus={tripStatus}
          activeBounds={seg.coords}
          activeMode={seg.type === 'flight' ? 'flight' : 'drive'}
        />
      </div>
      <div
        style={{
          flex: 1,
          overflowY: 'auto',
          padding: '14px 16px 80px',
        }}
      >
        {seg.day === 1 && <MelbourneMission />}
        {seg.day === 2 && <RightHandDriveCard />}
        {seg.type === 'flight' && seg.flights && (
          <div
            style={{
              marginBottom: 12,
            }}
          >
            {seg.flights.map((h, p) => (
              <div
                key={p}
                style={{
                  background: '#F3F0EA',
                  borderRadius: 10,
                  padding: '10px 14px',
                  marginBottom: 8,
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    marginBottom: 4,
                  }}
                >
                  <span
                    style={{
                      fontFamily: 'Lora, Georgia, serif',
                      fontSize: 15,
                      color: '#173D2A',
                      fontWeight: 700,
                    }}
                  >
                    {'✈️ '}
                    {h.code}
                  </span>
                  <span
                    style={{
                      fontFamily: 'Inter, sans-serif',
                      fontSize: 11,
                      color: '#8A8A8A',
                    }}
                  >
                    {h.dep}
                    {' → '}
                    {h.arr}
                  </span>
                </div>
                <div
                  style={{
                    fontFamily: 'Inter, sans-serif',
                    fontSize: 12,
                    color: '#4A4A4A',
                  }}
                >
                  {h.fromZh}
                  {' → '}
                  {h.toZh}
                </div>
                {h.note && (
                  <div
                    style={{
                      fontFamily: 'Inter, sans-serif',
                      fontSize: 11,
                      color: '#C4952A',
                      marginTop: 4,
                    }}
                  >
                    {'⏱ '}
                    {h.note}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
        {seg.driving && seg.km && (
          <div
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: 12,
              color: '#6B6B6B',
              marginBottom: 10,
              display: 'flex',
              alignItems: 'center',
              gap: 6,
            }}
          >
            🛣
            <span
              style={{
                fontWeight: 600,
                color: '#2A2A2A',
              }}
            >
              {seg.highway}
            </span>
            <span
              style={{
                color: '#A8A8A8',
              }}
            >
              {'· '}
              {seg.km}
              {' km · 約 '}
              {seg.hours}h
            </span>
          </div>
        )}
        {seg.note && (
          <div
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: 12,
              color: '#6B6B6B',
              marginBottom: 10,
            }}
          >
            {'📌 '}
            {seg.note}
          </div>
        )}
        {seg.warning && (
          <div
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: 12,
              color: '#C0392B',
              background: '#FEF3F2',
              borderRadius: 10,
              padding: '8px 12px',
              marginBottom: 10,
            }}
          >
            {'⚠️ '}
            {seg.warning}
          </div>
        )}
        {activities.length > 0 && (
          <div
            style={{
              marginBottom: 10,
            }}
          >
            {activities.map(h => (
              <div
                key={h.id}
                style={{
                  background: '#F3F0EA',
                  borderRadius: 8,
                  padding: '8px 10px',
                  marginBottom: 6,
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'flex-start',
                    gap: 8,
                  }}
                >
                  <div
                    style={{
                      fontFamily: 'Inter, sans-serif',
                      fontSize: 12,
                      color: '#173D2A',
                      fontWeight: 600,
                    }}
                  >
                    {'⭐ '}
                    {h.startTime && (
                      <span
                        style={{
                          marginRight: 4,
                        }}
                      >
                        {h.startTime}
                      </span>
                    )}
                    {h.nameZh}
                  </div>
                  {h.mapsQuery && (
                    <a
                      href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(h.mapsQuery)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        fontFamily: 'Inter, sans-serif',
                        fontSize: 9,
                        color: '#3D6E8A',
                        textDecoration: 'none',
                        flexShrink: 0,
                        border: '1px solid #C5DDE8',
                        borderRadius: 4,
                        padding: '2px 7px',
                      }}
                    >
                      MAP ↗
                    </a>
                  )}
                </div>
                {h.meetingPoint && (
                  <div
                    style={{
                      fontFamily: 'Inter, sans-serif',
                      fontSize: 10,
                      color: '#8A8A8A',
                      marginTop: 3,
                    }}
                  >
                    {'📍 '}
                    {h.meetingPoint}
                  </div>
                )}
                {h.startNote && (
                  <div
                    style={{
                      fontFamily: 'Inter, sans-serif',
                      fontSize: 10,
                      color: '#C4952A',
                      marginTop: 2,
                    }}
                  >
                    {'⏱ '}
                    {h.startNote}
                  </div>
                )}
                <PlanB text={h.planB} />
              </div>
            ))}
          </div>
        )}
        <RouteStops stops={seg.stops} />
        <WeatherCard date={seg.date} lat={dest[0]} lng={dest[1]} />
        {/* 出發前檢查（有開車的日子）：官方路況、官方預報、加油站、沿途設施 */}
        {seg.metservice && (
          <div style={{ marginTop: 14 }}>
            <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 9, letterSpacing: '0.18em', color: '#8A8A8A',
              textTransform: 'uppercase', fontWeight: 700, marginBottom: 6 }}>
              出發前檢查 · {seg.fromZh}出發
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <ToolTile href="https://www.journeys.nzta.govt.nz/highway-conditions" icon="🚧" title="NZTA 路況" sub="官方封路 / 施工 / 積雪" />
              <ToolTile href={seg.metservice.url} icon="🌦" title="MetService" sub={`官方預報 · ${seg.metservice.label}`} />
              <ToolTile onClick={() => openFuelMap(seg.coords[0])} icon="⛽" title="附近加油站" sub="Google Maps · 比價開 Gaspy" />
              <ToolTile href="https://campermate.com" icon="🚻" title="CamperMate" sub="公廁 / 停車 / 沿途設施" />
            </div>
            <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, color: '#6B6B6B', lineHeight: 1.5, marginTop: 8 }}>
              ⛽ 油種看油箱蓋標示（91 / 95 / 98 / 柴油），不要加錯；自助加油機要信用卡 PIN，沒有的話記住 Pump 號碼，加完到櫃台付款
            </div>
          </div>
        )}
        {seg.gmapsUrl && (
          <button
            onClick={() => openGoogleMaps(seg.gmapsUrl)}
            style={{
              width: '100%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
              marginTop: 14,
              background: '#173D2A',
              color: 'white',
              border: 'none',
              cursor: 'pointer',
              fontFamily: 'Inter, sans-serif',
              fontSize: 13,
              fontWeight: 600,
              borderRadius: 12,
              padding: '12px 16px',
            }}
          >
            🗺 Google Maps 路線（開啟 App）
          </button>
        )}
      </div>
    </div>
  )
}
export default DayModal
