// 文字裡的電話自動變成可按的 tel: 連結（規則與 nz-trip-test.html E 組 mock 一致）
// +國碼 或 0800 開頭；「+64 03…」這種多寫的 0 撥號時要拿掉
const PHONE_RE = /(\+\d{1,3}(?:[ -]?\d){7,12}|\b0800(?:[ -]?\d){6})/g

export function telHref(num) {
  let d = num.replace(/[^\d+]/g, '')
  if (d.startsWith('+640')) d = '+64' + d.slice(4)
  return 'tel:' + d
}

export default function PhoneText({ text }) {
  if (typeof text !== 'string') return text ?? null
  const parts = text.split(PHONE_RE)
  if (parts.length === 1) return text
  return parts.map((p, i) =>
    i % 2 === 1 ? (
      <a key={i} href={telHref(p)} onClick={e => e.stopPropagation()}
        style={{ color: '#3D6E8A', textDecoration: 'underline', whiteSpace: 'nowrap' }}>
        {p}
      </a>
    ) : (
      p
    ),
  )
}
