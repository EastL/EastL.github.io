// Day 2 右駕適應清單（DayModal 內顯示）
// 圓環 / STOP / 停車標誌 / 巴士專用道 / 中央緩衝區 / 單線橋 / 斑馬線依 NZ Road Code（NZTA）＋ AA 整理，2026-10-07 查證

const SECTIONS = [
  {
    title: '起步前（停車場內完成）',
    icon: '🚗',
    items: [
      '座椅 / 三面後視鏡 / 排檔 / 手煞車位置確認',
      '方向燈 vs 雨刷 — 左右跟台灣相反，手動試幾次',
      '導航設好目的地再出發，不邊開邊設',
    ],
  },
  {
    title: '上路後練習重點',
    icon: '🛞',
    items: [
      '靠左習慣 — 車身中心感覺偏右是正常的',
      '方向燈（不是雨刷）',
      '左轉 / 右轉後回到左側車道',
      '圓環：進去前讓右邊來的車（Give Way）',
      '圓環左轉（第一個出口）：進圓環前就打左燈',
      '圓環直走：進圓環不打燈，經過前一個出口打左燈',
      '圓環右轉 / 迴轉：進圓環打右燈，經過前一個出口打左燈',
      'STOP 要完全停住，讓完所有車才走（不是減速而已）',
      '停車：找空曠場地，不硬塞，不成功就換位置',
      '車身左側距離判斷',
    ],
  },
  {
    title: '停車標誌',
    icon: '🅿️',
    items: [
      'P120 = 最多停 120 分鐘（P 下面的數字是分鐘）',
      '有箭頭：限制只適用箭頭方向那一段',
      '標誌沒寫時間的：8:00–18:00 有效（國定假日除外）',
      '要付費的路段：買票後把票券放在擋風玻璃內側',
    ],
  },
  {
    title: '巴士專用道 / 中央緩衝區',
    icon: '🚌',
    items: [
      '巴士專用道：路面綠色、寫 BUS LANE，一般車不能開（罰款 NZ$150，基督城有攝影機）',
      '看路邊標誌的時段，沒寫時間 = 24 小時都不能開',
      '要左轉進巷子、車道或停車格時，可以提前進巴士專用道，最多開 50 公尺',
      '中央緩衝區（Flush Median）：路中間畫斜線的那一條，不是車道',
      '中央緩衝區可以用來：右轉前先開進去減速等空檔；從巷子右轉出來時先停在這裡，再併入左側車流',
      '中央緩衝區只能開一小段，不能拿來超車，也不能停車；進去前要打燈',
    ],
  },
  {
    title: '單線橋 / 斑馬線',
    icon: '🌉',
    items: [
      '單線橋（One-lane bridge）：南島很多，橋前會先有黃色菱形警告牌',
      '紅色圓形 = 我方要讓，等對向車過完再上橋',
      '藍色方形 = 我方優先，但還是要減速，確認橋上沒車才開',
      '斑馬線：黑白條紋桿子＋頂端橘色圓盤（晚上是閃黃燈），路面前有白色菱形預告',
      '看到有人在斑馬線上或站在旁邊準備過，就要停在白色停止線前',
      '沒有安全島：整條斑馬線上有人都要停；有安全島：只讓我這半邊的人',
      '前車在斑馬線前減速或停下時，不能超車；過了斑馬線那頭沒空間，就先別開上去',
    ],
  },
  {
    title: '嘴巴一直念的時機',
    icon: '💬',
    items: ['從停車場出去後 → 靠左、靠左', '左轉 / 右轉後 → 靠左、靠左', '圓環出口後 → 靠左、靠左'],
    note: '不是學開車，是把既有能力重新映射到左側通行。',
  },
]
function RightHandDriveCard() {
  return (
    <div
      style={{
        marginTop: 14,
        borderRadius: 14,
        border: '1px solid #E6E1D6',
        overflow: 'hidden',
      }}
    >
      <div
        style={{
          background: '#2A1F0A',
          padding: '10px 14px',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
        }}
      >
        <span
          style={{
            fontSize: 18,
          }}
        >
          🚗
        </span>
        <div>
          <div
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: 9,
              letterSpacing: '0.2em',
              color: '#C4952A',
              textTransform: 'uppercase',
            }}
          >
            DAY ONE
          </div>
          <div
            style={{
              fontFamily: 'Lora, Georgia, serif',
              fontSize: '1rem',
              color: 'white',
              fontWeight: 700,
            }}
          >
            Right-hand Drive
          </div>
        </div>
      </div>
      <div
        style={{
          background: '#FAF9F5',
          padding: '12px 14px',
        }}
      >
        {SECTIONS.map((e, t) => (
          <div
            key={t}
            style={{
              marginBottom: t < SECTIONS.length - 1 ? 14 : 0,
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                marginBottom: 8,
              }}
            >
              <span
                style={{
                  fontSize: 14,
                }}
              >
                {e.icon}
              </span>
              <div
                style={{
                  fontFamily: 'Inter, sans-serif',
                  fontSize: 9,
                  letterSpacing: '0.15em',
                  color: '#C4952A',
                  textTransform: 'uppercase',
                  fontWeight: 700,
                }}
              >
                {e.title}
              </div>
            </div>
            {e.items.map((i, o) => (
              <div
                key={o}
                style={{
                  display: 'flex',
                  gap: 10,
                  padding: '6px 0',
                  borderBottom: '1px solid #F3F0EA',
                  alignItems: 'flex-start',
                }}
              >
                <div
                  style={{
                    width: 16,
                    height: 16,
                    borderRadius: 3,
                    border: '1.5px solid #CEC7B8',
                    flexShrink: 0,
                    marginTop: 1,
                  }}
                />
                <div
                  style={{
                    fontFamily: 'Inter, sans-serif',
                    fontSize: 12,
                    color: '#2A2A2A',
                    lineHeight: 1.5,
                  }}
                >
                  {i}
                </div>
              </div>
            ))}
            {e.note && (
              <div
                style={{
                  fontFamily: 'Lora, Georgia, serif',
                  fontSize: 11,
                  color: '#8A8A8A',
                  fontStyle: 'italic',
                  marginTop: 8,
                }}
              >
                {e.note}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
export default RightHandDriveCard
