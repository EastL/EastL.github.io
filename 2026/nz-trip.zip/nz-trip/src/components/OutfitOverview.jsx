import { useEffect, useState } from 'react'
import OutfitCard, { LayerBar } from './OutfitCard'
import {
  OUTFITS, LAYER_KEYS, LAYER_META, LEVELS, SHOPPING, PACKING_STRATEGY, outfitSummary,
} from '../data/outfits'

const SANS = 'Inter, sans-serif'
const SERIF = 'Lora, Georgia, serif'

function SectionTitle({ children }) {
  return (
    <div style={{ fontFamily: SANS, fontSize: 9, letterSpacing: '0.22em', color: '#8A8A8A',
      textTransform: 'uppercase', fontWeight: 700, margin: '22px 0 10px' }}>
      {children}
    </div>
  )
}

function dateLabel(date) {
  const [, m, d] = date.split('-').map(Number)
  return `${m}/${d}`
}

function MapLink({ query }) {
  return (
    <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`} target="_blank" rel="noopener noreferrer"
      style={{ fontFamily: SANS, fontSize: 9, color: '#3D6E8A', textDecoration: 'none', flexShrink: 0,
        border: '1px solid #C5DDE8', borderRadius: 4, padding: '2px 7px' }}>
      MAP ↗
    </a>
  )
}

function StoreCard({ store, index, label, muted = false }) {
  return (
    <div style={{ background: muted ? '#FAF9F5' : 'white', border: `1px ${muted ? 'dashed' : 'solid'} #E6E1D6`,
      borderRadius: 10, padding: '10px 12px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
        <div>
          <div style={{ fontFamily: SANS, fontSize: 9, letterSpacing: '0.16em', color: '#C4952A', fontWeight: 700 }}>
            {label || `${index} · ${store.place}`}{store.priority && ' · 最優先'}
          </div>
          <div style={{ fontFamily: SERIF, fontSize: 15, color: '#173D2A', fontWeight: 700, marginTop: 2 }}>{store.name}</div>
        </div>
        <MapLink query={store.mapsQuery} />
      </div>
      <div style={{ fontFamily: SANS, fontSize: 11, color: '#6B6B6B', marginTop: 4 }}>{store.address}</div>
      <div style={{ fontFamily: SANS, fontSize: 11, color: '#4A4A4A', marginTop: 4 }}>
        🕙 週六 {store.hoursSat || '官網未公開，出發前用 Google Maps 確認'}
      </div>
      {store.buyQty && (
        <div style={{ display: 'inline-block', marginTop: 6, fontFamily: SANS, fontSize: 11, fontWeight: 700, color: '#173D2A',
          background: '#EEF7F1', border: '1px solid #B8DFC8', borderRadius: 999, padding: '2px 9px' }}>
          要買：{store.buyQty}
        </div>
      )}
      {store.buy && <div style={{ fontFamily: SANS, fontSize: 12, color: '#6B6B6B', marginTop: 4 }}>可以看：{store.buy}</div>}
      {store.brands && <div style={{ fontFamily: SANS, fontSize: 11, color: '#4A4A4A', marginTop: 4 }}>品牌：{store.brands}</div>}
      {store.note && <div style={{ fontFamily: SERIF, fontSize: 11, color: '#8A8A8A', fontStyle: 'italic', marginTop: 4 }}>{store.note}</div>}
    </div>
  )
}

// 寬螢幕（桌機）：10 天 × 各層 表格，方便橫向比較
function OverviewTable({ onPick }) {
  const cell = { fontFamily: SANS, fontSize: 12, color: '#2A2A2A', padding: '8px 10px',
    borderBottom: '1px solid #F3F0EA', verticalAlign: 'top' }
  // th 預設置中，td 靠左 → 統一靠左才會對齊
  const head = { ...cell, fontSize: 9, letterSpacing: '0.14em', color: '#8A8A8A', textTransform: 'uppercase',
    fontWeight: 700, background: '#FAF9F5', textAlign: 'left', whiteSpace: 'nowrap' }
  return (
    <div style={{ overflowX: 'auto', border: '1px solid #E6E1D6', borderRadius: 12, background: 'white' }}>
      <table style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead>
          <tr>
            <th style={head}>日期</th><th style={head}>主題</th>
            {LAYER_KEYS.map(k => <th key={k} style={head}>{LAYER_META[k].icon} {LAYER_META[k].short}</th>)}
            <th style={head}>👖 褲</th><th style={head}>備註</th>
          </tr>
        </thead>
        <tbody>
          {OUTFITS.map(o => (
            <tr key={o.date} onClick={() => onPick(o.date)} style={{ cursor: 'pointer' }}>
              <td style={{ ...cell, color: '#8A8A8A', whiteSpace: 'nowrap' }}>{dateLabel(o.date)}</td>
              <td style={{ ...cell, whiteSpace: 'nowrap', fontWeight: 600, color: '#173D2A' }}>
                {o.icon} {o.theme}
                <div style={{ marginTop: 5 }}><LayerBar outfit={o} height={6} width={16} /></div>
              </td>
              {LAYER_KEYS.map(k => (
                <td key={k} style={{ ...cell, color: o.layers[k] ? '#2A2A2A' : '#C0B8AC' }}>
                  {o.layers[k] || ((o.carry || []).includes(k) ? '帶著' : '—')}
                  {o.night?.layers[k] && o.night.layers[k] !== o.layers[k] && (
                    <div style={{ fontSize: 10, color: '#3D6E8A' }}>🌌 {o.night.layers[k]}</div>
                  )}
                </td>
              ))}
              <td style={cell}>{o.bottom}</td>
              <td style={{ ...cell, fontSize: 11, color: '#6B6B6B' }}>
                {o.avoid?.map(a => <div key={a.item} style={{ color: '#C0392B' }}>⚠️ 不要{a.item}</div>)}
                {o.shop && <div>🛍 買衣服日</div>}
                {o.night && <div>🌌 {o.night.from} 後全套保暖</div>}
                {o.laundry && <div style={{ color: '#3D6E8A' }}>🧺 {o.laundry.startsWith('洗衣備案') ? '洗衣備案' : '洗衣日'}</div>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// 穿搭總覽：洋蔥說明 → 10 天 → Christchurch 採購 → 行李策略
export default function OutfitOverview({ initialDate = null, onClose }) {
  const [openDate, setOpenDate] = useState(initialDate)
  const [wide, setWide] = useState(() => typeof window !== 'undefined' && window.matchMedia('(min-width: 768px)').matches)

  useEffect(() => {
    document.body.style.overflow = 'hidden'
    const mq = window.matchMedia('(min-width: 768px)')
    const onChange = e => setWide(e.matches)
    mq.addEventListener?.('change', onChange)
    return () => {
      document.body.style.overflow = ''
      mq.removeEventListener?.('change', onChange)
    }
  }, [])

  // 從行程頁點進來時，捲到那一天
  useEffect(() => {
    if (initialDate) document.getElementById(`outfit-${initialDate}`)?.scrollIntoView({ block: 'center' })
  }, [initialDate])

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 1200, display: 'flex', flexDirection: 'column', background: '#FAF9F5' }}>
      {/* Header（主畫面 app 讓出狀態列高度） */}
      <div style={{ background: '#173D2A', padding: 'calc(14px + env(safe-area-inset-top)) 16px 14px', flexShrink: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontFamily: SANS, fontSize: 9, letterSpacing: '0.2em', color: '#6AAF87', textTransform: 'uppercase' }}>
            WHAT TO WEAR
          </div>
          <div style={{ fontFamily: SERIF, fontSize: '1.2rem', color: 'white', fontWeight: 700 }}>穿搭總覽</div>
        </div>
        <button onClick={onClose} aria-label="關閉"
          style={{ color: 'rgba(255,255,255,0.7)', background: 'rgba(255,255,255,0.1)', border: 'none', borderRadius: '50%',
            width: 36, height: 36, cursor: 'pointer', fontSize: 18 }}>
          ✕
        </button>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '0 16px calc(40px + env(safe-area-inset-bottom))' }}>
        <div style={{ maxWidth: wide ? 980 : 'none', margin: '0 auto' }}>
          {/* 洋蔥式穿法 */}
          <SectionTitle>洋蔥式穿法 · LAYERING</SectionTitle>
          <div style={{ display: 'grid', gridTemplateColumns: wide ? 'repeat(4, 1fr)' : '1fr 1fr', gap: 8 }}>
            {LAYER_KEYS.map((k, i) => (
              <div key={k} style={{ background: 'white', border: '1px solid #E6E1D6', borderRadius: 10, padding: '10px 12px' }}>
                <div style={{ fontFamily: SANS, fontSize: 9, color: '#C4952A', letterSpacing: '0.15em', fontWeight: 700 }}>
                  {i + 1} · {LAYER_META[k].icon}
                </div>
                <div style={{ fontFamily: SERIF, fontSize: 14, color: '#173D2A', fontWeight: 700, marginTop: 2 }}>
                  {LAYER_META[k].en}
                </div>
                <div style={{ fontFamily: SANS, fontSize: 11, color: '#6B6B6B', marginTop: 2 }}>{LAYER_META[k].zh}</div>
              </div>
            ))}
          </div>
          <div style={{ fontFamily: SANS, fontSize: 11, color: '#8A8A8A', marginTop: 8 }}>
            依當天天氣與活動增加或減少；▰ 穿上　⬚ 帶著備用
          </div>
          <div style={{ background: 'white', border: '1px solid #E6E1D6', borderRadius: 10, marginTop: 10, padding: '4px 12px' }}>
            {Object.entries(LEVELS).map(([k, l], i, arr) => (
              <div key={k} style={{ display: 'flex', gap: 10, padding: '7px 0', fontFamily: SANS, fontSize: 12,
                borderBottom: i < arr.length - 1 ? '1px solid #F3F0EA' : 'none' }}>
                <span style={{ width: 52, flexShrink: 0, color: '#173D2A', fontWeight: 600 }}>{l.icon} {l.zh}</span>
                <span style={{ color: '#4A4A4A' }}>{l.rule}</span>
              </div>
            ))}
          </div>

          {/* 每日穿搭 */}
          <SectionTitle>每日穿搭 · 10 DAYS</SectionTitle>
          {wide ? (
            <>
              <OverviewTable onPick={d => setOpenDate(d)} />
              {openDate && (
                <div style={{ marginTop: 12, maxWidth: 480 }}>
                  <OutfitCard outfit={OUTFITS.find(o => o.date === openDate)} label={dateLabel(openDate)} autoSession={false} />
                </div>
              )}
            </>
          ) : (
            OUTFITS.map(o => (
              <div key={o.date} id={`outfit-${o.date}`} style={{ marginBottom: 8 }}>
                {openDate === o.date ? (
                  <div>
                    <OutfitCard outfit={o} label={dateLabel(o.date)} autoSession={false} />
                    <button onClick={() => setOpenDate(null)}
                      style={{ background: 'none', border: 'none', fontFamily: SANS, fontSize: 11, color: '#8A8A8A',
                        padding: '6px 2px', cursor: 'pointer' }}>
                      收合 ▲
                    </button>
                  </div>
                ) : (
                  <button onClick={() => setOpenDate(o.date)}
                    style={{ width: '100%', textAlign: 'left', background: 'white', border: '1px solid #E6E1D6',
                      borderRadius: 10, padding: '10px 12px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span style={{ fontFamily: SANS, fontSize: 11, color: '#8A8A8A', width: 36, flexShrink: 0 }}>
                      {dateLabel(o.date)}
                    </span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontFamily: SANS, fontSize: 10, letterSpacing: '0.14em', color: '#173D2A', fontWeight: 700 }}>
                        {o.icon} {o.theme}
                      </div>
                      <div style={{ fontFamily: SANS, fontSize: 11, color: '#6B6B6B', marginTop: 2, whiteSpace: 'nowrap',
                        overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {outfitSummary(o).replace(`${o.icon} `, '')}
                      </div>
                    </div>
                    <LayerBar outfit={o} height={6} width={14} />
                    <span style={{ color: '#C0B8AC', fontSize: 11 }}>▼</span>
                  </button>
                )}
              </div>
            ))
          )}

          {/* Christchurch 採購：照逛法順序，地址＋週六營業時間＋MAP */}
          <SectionTitle>CHRISTCHURCH 採購 · 10/10（六）</SectionTitle>
          <div style={{ background: '#173D2A', borderRadius: 10, padding: '10px 12px', marginBottom: 10 }}>
            <div style={{ fontFamily: SANS, fontSize: 9, letterSpacing: '0.18em', color: '#6AAF87', fontWeight: 700 }}>
              🇳🇿 紐西蘭要買 · 共 {SHOPPING.buyList.reduce((n, b) => n + b.qty, 0)} 件
            </div>
            {SHOPPING.buyList.map(b => (
              <div key={b.item} style={{ display: 'flex', gap: 10, alignItems: 'baseline', marginTop: 6 }}>
                <span style={{ fontFamily: SERIF, fontSize: 15, color: 'white', fontWeight: 700, flexShrink: 0 }}>
                  {b.item} ×{b.qty}
                </span>
                <span style={{ fontFamily: SANS, fontSize: 11, color: '#B8DFC8' }}>{b.where} · {b.note}</span>
              </div>
            ))}
          </div>
          <div style={{ fontFamily: SANS, fontSize: 12, color: '#4A4A4A', marginBottom: 8 }}>
            {SHOPPING.slot} · {SHOPPING.route}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: wide ? 'repeat(3, 1fr)' : '1fr', gap: 8 }}>
            {SHOPPING.stores.map((st, i) => (
              <StoreCard key={st.name} store={st} index={i + 1} />
            ))}
          </div>
          <div style={{ background: '#F3F0EA', borderRadius: 10, padding: '10px 12px', marginTop: 8,
            display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
            <div>
              <div style={{ fontFamily: SANS, fontSize: 12, color: '#173D2A', fontWeight: 700 }}>🅿️ {SHOPPING.parking.name}</div>
              <div style={{ fontFamily: SANS, fontSize: 11, color: '#6B6B6B', marginTop: 2 }}>{SHOPPING.parking.address}</div>
              <div style={{ fontFamily: SANS, fontSize: 11, color: '#8A8A8A', marginTop: 2 }}>{SHOPPING.parking.note}</div>
            </div>
            <MapLink query={SHOPPING.parking.mapsQuery} />
          </div>
          <div style={{ fontFamily: SANS, fontSize: 11, color: '#8A8A8A', marginTop: 8 }}>
            預計：{SHOPPING.plan.join('、')}　·　{SHOPPING.note}
          </div>
          <div style={{ marginTop: 10 }}>
            <StoreCard store={SHOPPING.backup} label="備選 · OUTLET" muted />
          </div>

          {/* 行李策略 */}
          <SectionTitle>行李策略</SectionTitle>
          <div style={{ background: 'white', border: '1px solid #E6E1D6', borderRadius: 10, padding: '10px 12px' }}>
            {PACKING_STRATEGY.map(t => (
              <div key={t} style={{ fontFamily: SANS, fontSize: 12, color: '#4A4A4A', padding: '3px 0' }}>· {t}</div>
            ))}
            <div style={{ fontFamily: SANS, fontSize: 11, color: '#8A8A8A', marginTop: 6 }}>
              完整件數清單在「出發前準備 → 衣物」，可以打勾
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
