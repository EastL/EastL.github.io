// 當天順路停靠點（routes.js stops）
const SANS = 'Inter, sans-serif'

export default function RouteStops({ stops, style }) {
  if (!stops?.length) return null
  return (
    <div style={{ marginTop: 10, ...style }}>
      <div style={{ fontFamily: SANS, fontSize: 9, letterSpacing: '0.18em', color: '#8A8A8A', textTransform: 'uppercase',
        fontWeight: 700, marginBottom: 6 }}>
        🚏 順路停靠 · 可選
      </div>
      {stops.map(s => (
        <div key={s.name} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', background: 'white',
          border: '1px solid #E6E1D6', borderRadius: 10, padding: '8px 10px', marginBottom: 6 }}>
          <span style={{ fontSize: 16, lineHeight: 1.3 }}>{s.icon}</span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: SANS, fontSize: 12, fontWeight: 600, color: '#173D2A' }}>
              {s.name} <span style={{ fontWeight: 400, fontSize: 10, color: '#C4952A' }}>{s.when}</span>
            </div>
            <div style={{ fontFamily: SANS, fontSize: 11, color: '#4A4A4A', marginTop: 2 }}>{s.what}</div>
            <div style={{ fontFamily: SANS, fontSize: 10, color: '#8A8A8A', marginTop: 2 }}>{s.info}</div>
          </div>
          <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(s.mapsQuery)}`} target="_blank"
            rel="noopener noreferrer"
            style={{ fontFamily: SANS, fontSize: 9, color: '#3D6E8A', textDecoration: 'none', flexShrink: 0,
              border: '1px solid #C5DDE8', borderRadius: 4, padding: '2px 7px' }}>
            MAP ↗
          </a>
        </div>
      ))}
    </div>
  )
}
