// 天氣取消時的替代方案（ACTIVITIES.planB）
export default function PlanB({ text, style }) {
  if (!text) return null
  return (
    <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, color: '#6B6B6B', lineHeight: 1.5, marginTop: 4,
      background: '#F4F6F8', borderLeft: '2px solid #9AAAB8', borderRadius: 4, padding: '4px 8px', ...style }}>
      ☁️ <b style={{ color: '#3D6E8A' }}>取消的話</b>：{text}
    </div>
  )
}
