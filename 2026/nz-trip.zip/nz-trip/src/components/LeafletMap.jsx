// Leaflet 地圖：總覽（路線＋住宿/活動 popup）、點選某天 flyTo＋導航風格路線動畫、無選擇時 overview 自動播放 ✈️/🚗
import { useEffect, useRef } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { ACCOMMODATIONS, ACTIVITIES } from '../data/trip'
import { FULL_ROUTE } from '../data/routes'

const ROUTE_STOPS = [
  {
    id: 'CHR',
    city: 'Christchurch',
    zh: '基督城',
    coords: [-43.5321, 172.6362],
    dayNums: [2, 3],
    dayLabel: 'Day 2–3',
  },
  {
    id: 'TEK',
    city: 'Lake Tekapo',
    zh: '蒂卡波湖',
    coords: [-44.0053, 170.4778],
    dayNums: [3],
    dayLabel: 'Day 3',
  },
  {
    id: 'MTK',
    city: 'Mt Cook',
    zh: '庫克山',
    coords: [-43.5965, 170.1418],
    dayNums: [4],
    dayLabel: 'Day 4',
  },
  {
    id: 'WAN',
    city: 'Wanaka',
    zh: '瓦納卡',
    coords: [-44.7031, 169.1317],
    dayNums: [5],
    dayLabel: 'Day 5',
  },
  {
    id: 'QTN',
    city: 'Queenstown',
    zh: '皇后鎮',
    coords: [-45.0312, 168.6626],
    dayNums: [6, 7, 8, 9],
    dayLabel: 'Day 6–9',
  },
]
const TRANSIT = [
  {
    id: 'HSC',
    city: 'Hsinchu',
    zh: '新竹',
    coords: [24.8039, 120.9717],
    type: 'home',
  },
  {
    id: 'TPE',
    city: 'Taoyuan Airport',
    zh: '桃園機場',
    coords: [25.0797, 121.2342],
    type: 'airport',
  },
  {
    id: 'MEL',
    city: 'Melbourne',
    zh: '墨爾本',
    coords: [-37.8136, 144.9631],
    type: 'transit',
  },
  {
    id: 'BNE',
    city: 'Brisbane',
    zh: '布里斯本',
    coords: [-27.4705, 153.026],
    type: 'transit',
  },
]
const DRIVE_TO_AIRPORT = [
  [24.8039, 120.9717],
  [25.0797, 121.2342],
]
const DRIVE_FROM_AIRPORT = [
  [25.0797, 121.2342],
  [24.8039, 120.9717],
]
const OUTBOUND_FLIGHT = [
  [25.0797, 121.2342],
  [-37.8136, 144.9631],
  [-43.5321, 172.6362],
]
const RETURN_FLIGHT = [
  [-45.0312, 168.6626],
  [-27.4705, 153.026],
  [25.0797, 121.2342],
]
const NZ_ROAD = ROUTE_STOPS.map(e => e.coords)
const DAY_DATES = {
  2: '2026-10-10',
  3: '2026-10-11',
  4: '2026-10-12',
  5: '2026-10-13',
  6: '2026-10-14',
  7: '2026-10-15',
  8: '2026-10-16',
  9: '2026-10-17',
}
function stopStatus(stop, currentDay, tripStatus) {
  if (tripStatus === 'before') return 'upcoming'
  if (tripStatus === 'after') return 'completed'
  const min = Math.min(...stop.dayNums),
    max = Math.max(...stop.dayNums)
  return currentDay > max ? 'completed' : currentDay >= min ? 'today' : 'upcoming'
}
function LeafletMap({
  currentDay,
  tripStatus,
  activeBounds = null,
  activeMode = 'drive',
}) {
  const containerRef = useRef(null),
    mapRef = useRef(null),
    activeLayerRef = useRef(null),
    autoplayRef = useRef(null)
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return
    const map = L.map(containerRef.current, {
      zoomControl: true,
      scrollWheelZoom: true,
    })
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© <a href="https://openstreetmap.org">OpenStreetMap</a>',
      maxZoom: 18,
    }).addTo(map)
    L.polyline(NZ_ROAD, {
      color: '#C4952A',
      weight: 3,
      opacity: 0.9,
    }).addTo(map)
    L.polyline(DRIVE_TO_AIRPORT, {
      color: '#173D2A',
      weight: 2,
      opacity: 0.6,
    }).addTo(map)
    L.polyline(DRIVE_FROM_AIRPORT, {
      color: '#173D2A',
      weight: 2,
      opacity: 0.6,
      dashArray: '3 4',
    }).addTo(map)
    L.polyline(OUTBOUND_FLIGHT, {
      color: '#3D6E8A',
      weight: 2,
      dashArray: '6 5',
      opacity: 0.7,
    }).addTo(map)
    L.polyline(RETURN_FLIGHT, {
      color: '#3D6E8A',
      weight: 2,
      dashArray: '6 5',
      opacity: 0.7,
    }).addTo(map)
    TRANSIT.forEach(T => {
      const S = T.type === 'home',
        w = T.type === 'airport'
      L.circleMarker(T.coords, {
        radius: w ? 6 : 7,
        fillColor: S ? '#173D2A' : w ? '#C4952A' : '#3D6E8A',
        color: '#FAF9F5',
        weight: 2,
        fillOpacity: 0.85,
      })
        .addTo(map)
        .bindPopup(
          `
        <div style="font-family:Inter,sans-serif;min-width:120px;">
          <div style="font-size:13px;font-weight:700;color:#173D2A;">${T.city}</div>
          <div style="font-size:11px;color:#8A8A8A;">${T.zh} · ${S ? '出發 / 返抵' : w ? '台灣出入境' : '中轉'}</div>
          ${S ? '<div style="font-size:10px;color:#C4952A;margin-top:4px;">🏠 Home</div>' : w ? '<div style="font-size:10px;color:#C4952A;margin-top:4px;">✈ CI057 出發</div>' : '<div style="font-size:10px;color:#3D6E8A;margin-top:4px;">✈ Transit</div>'}
        </div>
      `,
          {
            className: 'nz-popup',
            maxWidth: 200,
          },
        )
    })
    ROUTE_STOPS.forEach(T => {
      const S = stopStatus(T, currentDay, tripStatus),
        w = S === 'today',
        E = S === 'completed',
        z = ACCOMMODATIONS.find(_ =>
          T.dayNums.some(v => _.checkIn <= DAY_DATES[v] && DAY_DATES[v] < _.checkOut),
        ),
        A = ACTIVITIES.filter(_ => T.dayNums.some(v => DAY_DATES[v] === _.date))
      L.circleMarker(T.coords, {
        radius: w ? 10 : 7,
        fillColor: w ? '#C4952A' : E ? '#173D2A' : '#9BBFD5',
        color: '#FAF9F5',
        weight: 2.5,
        fillOpacity: w ? 1 : E ? 0.9 : 0.55,
      })
        .addTo(map)
        .bindPopup(
          `
        <div style="font-family:Inter,sans-serif;min-width:155px;">
          <div style="font-size:13px;font-weight:700;color:#173D2A;">${T.city}</div>
          <div style="font-size:11px;color:#8A8A8A;">${T.zh} · ${T.dayLabel}</div>
          ${w ? '<div style="font-size:10px;font-weight:700;color:#C4952A;margin-top:4px;">📍 NOW</div>' : ''}
          ${z ? `<div style="font-size:11px;color:#4A4A4A;margin-top:5px;padding-top:5px;border-top:1px solid #E6E1D6;">🏠 ${z.name}</div>` : ''}
          ${A.map(_ => `<div style="font-size:11px;color:#4A4A4A;margin-top:3px;">⭐ ${_.nameZh}</div>`).join('')}
        </div>
      `,
          {
            className: 'nz-popup',
            maxWidth: 230,
          },
        )
    })
    const y = [...TRANSIT.map(T => T.coords), ...ROUTE_STOPS.map(T => T.coords)]
    map.fitBounds(L.latLngBounds(y), {
      padding: [30, 30],
    })
    mapRef.current = map
    return () => {
      if (mapRef.current) {
        mapRef.current.remove()
        mapRef.current = null
      }
    }
  }, [])
  useEffect(() => {
    const map = mapRef.current
    if (map) {
      if (activeLayerRef.current) {
        const y = activeLayerRef.current
        y.remove ? y.remove(map) : map.removeLayer(y)
        activeLayerRef.current = null
      }
      if (
        activeBounds &&
        (activeBounds.length === 1
          ? map.flyTo(activeBounds[0], 10, {
              duration: 1,
            })
          : map.flyToBounds(L.latLngBounds(activeBounds), {
              padding: [60, 60],
              duration: 1,
              maxZoom: 11,
            }),
        activeBounds.length >= 2)
      ) {
        const y = L.polyline(activeBounds, {
            color: '#FFFFFF',
            weight: 10,
            opacity: 0.9,
          }).addTo(map),
          T = L.polyline(activeBounds, {
            color: '#1A73E8',
            weight: 6,
            opacity: 1,
            className: 'route-highlight',
          }).addTo(map),
          S = activeMode === 'flight' ? '✈️' : '🚗',
          w = L.divIcon({
            html: `<div style="font-size:20px;line-height:1;filter:drop-shadow(0 1px 3px rgba(0,0,0,0.5))">${S}</div>`,
            className: '',
            iconSize: [24, 24],
            iconAnchor: [12, 12],
          }),
          E = L.marker(activeBounds[0], {
            icon: w,
          }).addTo(map),
          z = () => {
            var B
            const A = T.getElement()
            if (A) {
              const M = Math.max(((B = A.getTotalLength) == null ? undefined : B.call(A)) ?? 0, 3e3)
              A.style.strokeDasharray = `${M} ${M}`
              A.style.strokeDashoffset = M
              requestAnimationFrame(() =>
                requestAnimationFrame(() => {
                  A.style.transition = 'stroke-dashoffset 1.5s ease-out'
                  A.style.strokeDashoffset = '0'
                }),
              )
            }
            const H = activeBounds,
              _ = 1800,
              v = Date.now()
            let x = 0
            const j = []
            for (let M = 0; M < H.length - 1; M++) {
              const b = H[M + 1][0] - H[M][0],
                K = H[M + 1][1] - H[M][1],
                Z = Math.sqrt(b * b + K * K)
              j.push({
                from: H[M],
                to: H[M + 1],
                d: Z,
              })
              x += Z
            }
            function D() {
              const M = Math.min((Date.now() - v) / _, 1),
                b = x * M
              let K = 0
              for (const Z of j) {
                if (K + Z.d >= b) {
                  const ne = Z.d > 0 ? (b - K) / Z.d : 0,
                    he = Z.from[0] + (Z.to[0] - Z.from[0]) * ne,
                    je = Z.from[1] + (Z.to[1] - Z.from[1]) * ne
                  E.setLatLng([he, je])
                  break
                }
                K += Z.d
              }
              M < 1 ? requestAnimationFrame(D) : E.setLatLng(H[H.length - 1])
            }
            requestAnimationFrame(D)
          }
        map.once('moveend', () => setTimeout(z, 80))
        activeLayerRef.current = {
          highlight: T,
          carMarker: E,
          remove: A => {
            A.removeLayer(y)
            A.removeLayer(T)
            A.removeLayer(E)
          },
        }
      }
    }
  }, [activeBounds])
  useEffect(() => {
    if (!mapRef.current) return
    const map = mapRef.current
    if (autoplayRef.current) {
      const D = autoplayRef.current
      D.cancelled = true
      D.timers.forEach(clearTimeout)
      map.off('zoomend', D.onZoom)
      if (D.marker) {
        map.removeLayer(D.marker)
      }
      autoplayRef.current = null
    }
    if (activeBounds) return
    function y(D, B) {
      const M = Math.max(3, Math.min(map.getZoom(), 12)),
        b = Math.round(14 + (M - 3) * 2.2)
      return L.divIcon({
        html: `<div style="font-size:${b}px;line-height:1;filter:drop-shadow(0 1px 3px rgba(0,0,0,0.6))">${D}</div>`,
        className: '',
        iconSize: [b + 4, b + 4],
        iconAnchor: [(b + 4) / 2, (b + 4) / 2],
      })
    }
    let T = '✈️'
    const S = L.marker(FULL_ROUTE[0].pos, {
        icon: y('✈️'),
      }).addTo(map),
      w = () => {
        S.setIcon(y(T))
      }
    map.on('zoomend', w)
    const E = {
      cancelled: false,
      timers: [],
      marker: S,
      onZoom: w,
    }
    autoplayRef.current = E
    const z = {
        flight: 0.025,
        drive: 0.012,
        home: 0.03,
      },
      A = {
        flight: 1800,
        drive: 1e3,
        home: 300,
      },
      H = {
        flight: 3500,
        drive: 2500,
        home: 800,
      },
      _ = 1500
    function v(D, B, M) {
      const b = B[0] - D[0],
        K = B[1] - D[1],
        ne = (Math.sqrt(b * b + K * K) * 111) / z[M]
      return Math.min(Math.max(ne, A[M]), H[M])
    }
    function x(D, B, M) {
      if (E.cancelled) return
      const b = FULL_ROUTE[D],
        K = FULL_ROUTE[B]
      T = K.mode === 'flight' || K.mode === 'home' ? '✈️' : '🚗'
      S.setIcon(y(T))
      const Z = v(b.pos, K.pos, K.mode),
        ne = Date.now()
      function he() {
        if (E.cancelled) return
        const je = Math.min((Date.now() - ne) / Z, 1),
          le = je < 0.5 ? 2 * je * je : -1 + (4 - 2 * je) * je,
          W = b.pos[0] + (K.pos[0] - b.pos[0]) * le,
          V = b.pos[1] + (K.pos[1] - b.pos[1]) * le
        S.setLatLng([W, V])
        je < 1 ? requestAnimationFrame(he) : M()
      }
      requestAnimationFrame(he)
    }
    function j(D) {
      if (!E.cancelled) {
        if (D >= FULL_ROUTE.length - 1) {
          const B = setTimeout(() => {
            E.cancelled || j(0)
          }, _)
          E.timers.push(B)
          return
        }
        x(D, D + 1, () => {
          E.cancelled || j(D + 1)
        })
      }
    }
    j(0)
    return () => {
      E.cancelled = true
      E.timers.forEach(clearTimeout)
      map.off('zoomend', w)
      if (S) {
        map.removeLayer(S)
      }
    }
  }, [activeBounds])
  return (
    <div
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
      }}
    >
      <div
        ref={containerRef}
        style={{
          width: '100%',
          height: '100%',
        }}
      />
      <style>{`
        .nz-popup .leaflet-popup-content-wrapper {
          background: #FAF9F5; border-radius: 10px;
          box-shadow: 0 3px 14px rgba(0,0,0,0.18); border: 1px solid #E6E1D6;
        }
        .nz-popup .leaflet-popup-content { margin: 11px 13px; }
        .nz-popup .leaflet-popup-tip { background: #FAF9F5; }
        .nz-popup .leaflet-popup-close-button { color: #8A8A8A !important; }
        .leaflet-control-zoom a { color: #173D2A !important; font-weight: 700 !important; }
        .leaflet-control-attribution { font-size: 9px !important; background: rgba(250,249,245,0.85) !important; }
      `}</style>
    </div>
  )
}
export default LeafletMap
