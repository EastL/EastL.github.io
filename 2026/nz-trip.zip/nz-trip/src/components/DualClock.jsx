import { useState, useEffect } from 'react'

function getTimeInZone(tz) {
  const now = new Date()
  const p = new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hour12: false,
  }).formatToParts(now)
  const get = t => parseInt(p.find(x => x.type === t)?.value || '0')
  const h = get('hour'), m = get('minute'), s = get('second')
  const dateStr = new Intl.DateTimeFormat('zh-TW', {
    timeZone: tz, month: 'numeric', day: 'numeric', weekday: 'short',
  }).format(now)
  return { h, m, s, dateStr,
    timeStr: `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}` }
}

function AnalogClock({ tz, flag, label, size = 120, dark = false }) {
  const [t, setT] = useState(() => getTimeInZone(tz))
  useEffect(() => {
    const id = setInterval(() => setT(getTimeInZone(tz)), 1000)
    return () => clearInterval(id)
  }, [tz])

  const cx = 50, cy = 50
  const deg = d => d * Math.PI / 180
  const hand = (angle, len) => ({
    x: cx + len * Math.sin(deg(angle)),
    y: cy - len * Math.cos(deg(angle)),
  })

  const hourAngle   = ((t.h % 12) / 12) * 360 + (t.m / 60) * 30
  const minuteAngle = (t.m / 60) * 360 + (t.s / 60) * 6
  const secondAngle = (t.s / 60) * 360

  const hEnd = hand(hourAngle, 26)
  const mEnd = hand(minuteAngle, 34)
  const sEnd = hand(secondAngle, 37)

  return (
    <div className="flex flex-col items-center" style={{ width: size }}>
      <svg viewBox="0 0 100 100" width={size} height={size}>
        {/* Face */}
        <circle cx={cx} cy={cy} r="46"
          fill={dark ? 'rgba(255,255,255,0.08)' : '#FAF9F5'}
          stroke={dark ? 'rgba(255,255,255,0.5)' : '#173D2A'} strokeWidth="1.8"/>
        {/* Hour markers */}
        {Array.from({length: 12}, (_, i) => {
          const a = deg((i / 12) * 360)
          const r1 = i % 3 === 0 ? 38 : 41
          return <line key={i}
            x1={cx + r1 * Math.sin(a)} y1={cy - r1 * Math.cos(a)}
            x2={cx + 44 * Math.sin(a)} y2={cy - 44 * Math.cos(a)}
            stroke={dark ? 'rgba(255,255,255,0.7)' : '#173D2A'}
            strokeWidth={i % 3 === 0 ? 2 : 1}/>
        })}
        {/* Hour hand */}
        <line x1={cx} y1={cy} x2={hEnd.x} y2={hEnd.y}
          stroke={dark ? 'white' : '#173D2A'} strokeWidth="3" strokeLinecap="round"/>
        {/* Minute hand */}
        <line x1={cx} y1={cy} x2={mEnd.x} y2={mEnd.y}
          stroke={dark ? 'white' : '#173D2A'} strokeWidth="2" strokeLinecap="round"/>
        {/* Second hand */}
        <line x1={cx} y1={cy} x2={sEnd.x} y2={sEnd.y}
          stroke="#C4952A" strokeWidth="1.2" strokeLinecap="round"/>
        {/* Center */}
        <circle cx={cx} cy={cy} r="3.5" fill="#C4952A"/>
        <circle cx={cx} cy={cy} r="1.5" fill={dark ? '#173D2A' : '#FAF9F5'}/>
      </svg>

      {/* Label */}
      <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 10,
        letterSpacing: '0.1em', color: dark ? '#6AAF87' : '#8A8A8A',
        marginTop: 5, textAlign: 'center' }}>
        {flag} {label}
      </div>
      {/* Digital time */}
      <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1.1rem',
        color: dark ? 'white' : '#173D2A', fontWeight: 700, lineHeight: 1.2 }}>
        {t.timeStr}
      </div>
      {/* Date */}
      <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 9,
        color: dark ? '#4A9B6F' : '#A8A8A8', marginTop: 2 }}>
        {t.dateStr}
      </div>
    </div>
  )
}

// layout="horizontal" (default) | "vertical" (stacked, for sidebar use)
export default function DualClock({ dark = false, layout = 'horizontal', size = 130 }) {
  if (layout === 'vertical') {
    return (
      <div className="flex flex-col items-center" style={{ gap: 12 }}>
        <AnalogClock tz="Asia/Taipei"      flag="🇹🇼" label="台灣"   size={size} dark={dark} />
        <AnalogClock tz="Pacific/Auckland" flag="🇳🇿" label="紐西蘭" size={size} dark={dark} />
      </div>
    )
  }
  return (
    <div>
      <div style={{ fontSize: 9, letterSpacing: '0.22em',
        color: dark ? '#6AAF87' : '#8A8A8A',
        fontFamily: 'Inter, sans-serif', textTransform: 'uppercase',
        fontWeight: 600, marginBottom: 14, textAlign: 'center' }}>
        現在時間
      </div>
      <div className="flex justify-center gap-3">
        <AnalogClock tz="Asia/Taipei"      flag="🇹🇼" label="台灣"   size={size} dark={dark} />
        <AnalogClock tz="Pacific/Auckland" flag="🇳🇿" label="紐西蘭" size={size} dark={dark} />
      </div>
    </div>
  )
}
