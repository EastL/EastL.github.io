// Day 1 墨爾本轉機任務卡（DayModal 內顯示）

const QUESTS = [
  {
    type: 'main',
    emoji: '🎯',
    label: 'MAIN QUEST',
    name: 'Hosier Lane 塗鴉街',
    note: '從 SCS 步行約 15 分鐘，拍照就走',
    gmapsUrl: 'https://www.google.com/maps/search/?api=1&query=Hosier%20Lane%20Melbourne',
  },
  {
    type: 'side',
    emoji: '☕',
    label: 'SIDE QUEST',
    name: 'Melbourne Flat White',
    note: 'SCS 站內順路買，不用繞路',
    gmapsUrl:
      'https://www.google.com/maps/search/?api=1&query=Dukes%20Coffee%20Roasters%20247%20Flinders%20Lane%20Melbourne',
  },
  {
    type: 'bonus',
    emoji: '🥧',
    label: 'BONUS QUEST',
    name: 'Aussie Meat Pie',
    note: '跟咖啡同一區，有空就順手',
    gmapsUrl:
      'https://www.google.com/maps/search/?api=1&query=meat+pie+near+Southern+Cross+Station+Melbourne',
  },
]
const TIME_TIERS = [
  {
    arrival: '14:00 前到 SCS',
    mins: 90,
    quests: '🎯 + ☕ + 🥧 全部',
    color: '#173D2A',
  },
  {
    arrival: '14:30 前到 SCS',
    mins: 60,
    quests: '🎯 + ☕',
    color: '#2E7D50',
  },
  {
    arrival: '15:00 前到 SCS',
    mins: 30,
    quests: '🎯 快閃',
    color: '#C4952A',
  },
  {
    arrival: '15:15 後',
    mins: 0,
    quests: '放棄，直接回機場',
    color: '#C0392B',
  },
]
function MelbourneMission() {
  return (
    <div
      style={{
        marginTop: 14,
        borderRadius: 14,
        border: '1px solid #E6E1D6',
        overflow: 'hidden',
      }}
    >
      <div
        style={{
          background: '#173D2A',
          padding: '10px 14px',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
        }}
      >
        <span
          style={{
            fontSize: 18,
          }}
        >
          🇦🇺
        </span>
        <div>
          <div
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: 9,
              letterSpacing: '0.2em',
              color: '#6AAF87',
              textTransform: 'uppercase',
            }}
          >
            TRANSIT MISSION
          </div>
          <div
            style={{
              fontFamily: 'Lora, Georgia, serif',
              fontSize: '1rem',
              color: 'white',
              fontWeight: 700,
            }}
          >
            Melbourne City Sprint
          </div>
        </div>
      </div>
      <div
        style={{
          background: '#FAF9F5',
          padding: '12px 14px',
        }}
      >
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: 9,
            letterSpacing: '0.18em',
            color: '#8A8A8A',
            textTransform: 'uppercase',
            marginBottom: 8,
          }}
        >
          13:30 GO / NO-GO
        </div>
        <div
          style={{
            display: 'flex',
            gap: 8,
            marginBottom: 14,
          }}
        >
          <div
            style={{
              flex: 1,
              background: '#EEF7F1',
              borderRadius: 8,
              padding: '8px 10px',
              border: '1px solid #B8DFC8',
            }}
          >
            <div
              style={{
                fontSize: 16,
                marginBottom: 2,
              }}
            >
              ✅
            </div>
            <div
              style={{
                fontFamily: 'Inter, sans-serif',
                fontSize: 11,
                color: '#173D2A',
                fontWeight: 600,
              }}
            >
              GO
            </div>
            <div
              style={{
                fontFamily: 'Inter, sans-serif',
                fontSize: 10,
                color: '#6B6B6B',
              }}
            >
              入境＋重掛完成
            </div>
          </div>
          <div
            style={{
              flex: 1,
              background: '#FEF3F2',
              borderRadius: 8,
              padding: '8px 10px',
              border: '1px solid #F5C6C2',
            }}
          >
            <div
              style={{
                fontSize: 16,
                marginBottom: 2,
              }}
            >
              ❌
            </div>
            <div
              style={{
                fontFamily: 'Inter, sans-serif',
                fontSize: 11,
                color: '#C0392B',
                fontWeight: 600,
              }}
            >
              NO-GO
            </div>
            <div
              style={{
                fontFamily: 'Inter, sans-serif',
                fontSize: 10,
                color: '#6B6B6B',
              }}
            >
              留機場方案 A
            </div>
          </div>
        </div>
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: 9,
            letterSpacing: '0.18em',
            color: '#8A8A8A',
            textTransform: 'uppercase',
            marginBottom: 8,
          }}
        >
          任務清單
        </div>
        {QUESTS.map(q => (
          <div
            key={q.type}
            style={{
              display: 'flex',
              gap: 10,
              paddingBottom: 8,
              marginBottom: 8,
              borderBottom: '1px solid #F3F0EA',
            }}
          >
            <span
              style={{
                fontSize: 20,
                flexShrink: 0,
                lineHeight: 1.4,
              }}
            >
              {q.emoji}
            </span>
            <div>
              <div
                style={{
                  fontFamily: 'Inter, sans-serif',
                  fontSize: 9,
                  letterSpacing: '0.14em',
                  color: '#C4952A',
                  textTransform: 'uppercase',
                  fontWeight: 700,
                }}
              >
                {q.label}
              </div>
              <div
                style={{
                  fontFamily: 'Inter, sans-serif',
                  fontSize: 12,
                  color: '#2A2A2A',
                  fontWeight: 600,
                }}
              >
                {q.name}
              </div>
              <div
                style={{
                  fontFamily: 'Inter, sans-serif',
                  fontSize: 10,
                  color: '#8A8A8A',
                }}
              >
                {q.note}
              </div>
              {q.gmapsUrl && (
                <a
                  href={q.gmapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    fontFamily: 'Inter, sans-serif',
                    fontSize: 9,
                    color: '#3D6E8A',
                    textDecoration: 'none',
                    border: '1px solid #C5DDE8',
                    borderRadius: 4,
                    padding: '2px 7px',
                    display: 'inline-block',
                    marginTop: 5,
                  }}
                >
                  MAP ↗
                </a>
              )}
            </div>
          </div>
        ))}
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: 9,
            letterSpacing: '0.18em',
            color: '#8A8A8A',
            textTransform: 'uppercase',
            marginBottom: 8,
            marginTop: 4,
          }}
        >
          到 SCS 的時間決定任務組合
        </div>
        {TIME_TIERS.map((q, ti) => (
          <div
            key={ti}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              marginBottom: 6,
            }}
          >
            <div
              style={{
                width: 3,
                height: 32,
                borderRadius: 2,
                background: q.color,
                flexShrink: 0,
              }}
            />
            <div>
              <div
                style={{
                  fontFamily: 'Inter, sans-serif',
                  fontSize: 11,
                  color: '#2A2A2A',
                  fontWeight: 600,
                }}
              >
                {q.arrival}
              </div>
              <div
                style={{
                  fontFamily: 'Inter, sans-serif',
                  fontSize: 10,
                  color: '#6B6B6B',
                }}
              >
                {q.quests}
              </div>
            </div>
          </div>
        ))}
        <div
          style={{
            marginTop: 10,
            background: '#FFF3E0',
            borderRadius: 8,
            padding: '7px 12px',
            fontFamily: 'Inter, sans-serif',
            fontSize: 11,
            color: '#C4952A',
            fontWeight: 600,
          }}
        >
          ⚠️ 15:30 Hard Deadline — 搭 SkyBus 回機場，不能動
        </div>
        <div
          style={{
            marginTop: 10,
            fontFamily: 'Inter, sans-serif',
            fontSize: 10,
            color: '#8A8A8A',
            lineHeight: 1.8,
          }}
        >
          路線：SCS → ☕ 咖啡 → 🥧 Pie → 🎯 Hosier Lane → SCS
        </div>
      </div>
    </div>
  )
}
export default MelbourneMission
