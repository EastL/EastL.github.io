import { useState } from 'react'
import { EXPENSE_CATEGORIES, TRIP } from '../data/config'
import { getNZDateString } from '../utils/nzTime'
import { itinerary } from '../data/itinerary'

// ── PIN Gate ─────────────────────────────────────────────────────────────────
export function PinGate({ onSuccess, onCancel }) {
  const [pin, setPin] = useState('')
  const [error, setError] = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    const ok = onSuccess(pin)
    if (!ok) {
      setError(true)
      setPin('')
      setTimeout(() => setError(false), 1500)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-6"
      onClick={(e) => { if (e.target === e.currentTarget) onCancel?.() }}>
      <div className="bg-stone-100 rounded-2xl p-7 w-full max-w-xs shadow-2xl">
        <div className="flex justify-end mb-1">
          <button onClick={() => onCancel?.()} style={{ color: '#A8A8A8', lineHeight: 1 }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
        <div className="text-center mb-6">
          <div className="text-3xl mb-3">🔒</div>
          <h3 className="font-serif text-lg text-ink-900 font-semibold">輸入 PIN 碼</h3>
          <p className="font-sans text-sm text-ink-500 mt-1">僅限旅行者新增花費</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="password"
            inputMode="numeric"
            maxLength={6}
            value={pin}
            onChange={e => setPin(e.target.value)}
            placeholder="PIN"
            className={`w-full text-center text-2xl tracking-[0.5em] font-serif
              border-2 rounded-xl py-3 px-4 bg-white outline-none
              transition-colors
              ${error
                ? 'border-red-400 bg-red-50'
                : 'border-stone-300 focus:border-forest-500'}`}
            autoFocus
          />
          {error && (
            <p className="text-center text-sm text-red-500 font-sans">PIN 碼不正確</p>
          )}
          <button
            type="submit"
            className="w-full bg-forest-800 text-white font-sans font-medium
              py-3 rounded-xl transition-colors hover:bg-forest-700 active:bg-forest-900"
          >
            確認
          </button>
        </form>
      </div>
    </div>
  )
}

// ── Expense Form ──────────────────────────────────────────────────────────────
export function ExpenseForm({ onSave, onCancel }) {
  const today = getNZDateString()
  const [form, setForm] = useState({
    date:     today,
    item:     '',
    category: 'food',
    amount:   '',
    currency: 'NZD',
    paidBy:   TRIP.travelers[0],
    note:     '',
  })

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }))

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!form.item.trim() || !form.amount) return

    const dayEntry = itinerary.find(d => d.date === form.date)

    const expense = {
      day:      dayEntry ? dayEntry.day : 0,
      date:     form.date,
      item:     form.item.trim(),
      category: form.category,
      NZD:      form.currency === 'NZD' ? parseFloat(form.amount) : null,
      TWD:      form.currency === 'TWD' ? parseFloat(form.amount) : null,
      paidBy:   form.paidBy,
      note:     form.note.trim(),
    }
    onSave(expense)
  }

  return (
    <div className="fixed inset-0 z-[200] bg-black/60 flex items-center justify-center p-4" style={{ paddingBottom: 'calc(72px + env(safe-area-inset-bottom, 0px))' }}>
      <div className="bg-stone-100 rounded-2xl w-full max-w-lg
        shadow-2xl flex flex-col" style={{ maxHeight: 'calc(100vh - 200px)', height: 'calc(100vh - 200px)' }}>

        {/* ── Fixed header ── */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-stone-200 flex-shrink-0">
          <h3 className="font-serif text-lg text-ink-900 font-semibold">新增花費</h3>
          <button onClick={onCancel}
            className="text-ink-400 hover:text-ink-700 transition-colors p-1">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>

        <form onSubmit={handleSubmit}
          style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>

          {/* ── Scrollable fields ── */}
          <div style={{ overflowY: 'auto', flex: 1, minHeight: 0, padding: '16px 20px' }}
            className="space-y-4">

            <div>
              <label className="section-label">日期</label>
              <input type="date" value={form.date}
                onChange={e => set('date', e.target.value)}
                className="w-full border border-stone-300 rounded-xl px-4 py-2.5
                  bg-white font-sans text-sm text-ink-800 outline-none
                  focus:border-forest-500 transition-colors"
              />
            </div>

            <div>
              <label className="section-label">項目</label>
              <input type="text" placeholder="例：午餐、門票、加油" value={form.item}
                onChange={e => set('item', e.target.value)}
                className="w-full border border-stone-300 rounded-xl px-4 py-2.5
                  bg-white font-sans text-sm text-ink-800 outline-none
                  focus:border-forest-500 transition-colors"
                required
              />
            </div>

            <div>
              <label className="section-label">類別</label>
              <div className="grid grid-cols-3 gap-2">
                {EXPENSE_CATEGORIES.map(cat => (
                  <button key={cat.id} type="button"
                    onClick={() => set('category', cat.id)}
                    className={`px-2 py-2 rounded-lg text-xs font-sans font-medium
                      border transition-all
                      ${form.category === cat.id
                        ? 'border-forest-500 bg-forest-50 text-forest-800'
                        : 'border-stone-300 bg-white text-ink-500 hover:border-stone-400'
                      }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="section-label">金額</label>
              <div className="flex gap-2">
                <div className="flex rounded-xl border border-stone-300 overflow-hidden bg-white flex-shrink-0">
                  {['NZD', 'TWD'].map(c => (
                    <button key={c} type="button"
                      onClick={() => set('currency', c)}
                      className={`px-3 py-2.5 text-xs font-sans font-medium transition-colors
                        ${form.currency === c
                          ? 'bg-forest-800 text-white'
                          : 'text-ink-500 hover:bg-stone-100'
                        }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
                <input type="number" inputMode="decimal" step="0.01" min="0"
                  placeholder="0.00" value={form.amount}
                  onChange={e => set('amount', e.target.value)}
                  className="flex-1 border border-stone-300 rounded-xl px-4 py-2.5
                    bg-white font-sans text-sm text-ink-800 outline-none
                    focus:border-forest-500 transition-colors"
                  required
                />
              </div>
            </div>

            <div>
              <label className="section-label">付款人</label>
              <div className="flex gap-2">
                {TRIP.travelers.map(t => (
                  <button key={t} type="button"
                    onClick={() => set('paidBy', t)}
                    className={`flex-1 py-2.5 rounded-xl text-sm font-sans font-medium
                      border transition-all
                      ${form.paidBy === t
                        ? 'bg-forest-800 text-white border-forest-800'
                        : 'bg-white text-ink-600 border-stone-300 hover:border-stone-400'
                      }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="section-label">備註 <span className="text-ink-300 normal-case">(可略)</span></label>
              <input type="text" placeholder="備註..." value={form.note}
                onChange={e => set('note', e.target.value)}
                className="w-full border border-stone-300 rounded-xl px-4 py-2.5
                  bg-white font-sans text-sm text-ink-800 outline-none
                  focus:border-forest-500 transition-colors"
              />
            </div>
          </div>

          {/* ── Fixed footer ── */}
          <div style={{ flexShrink: 0, padding: '12px 20px 20px',
            borderTop: '1px solid #e7e5e4', background: '#f5f5f4' }}>
            <button type="submit"
              className="w-full bg-forest-800 text-white font-sans font-medium
                py-3.5 rounded-xl transition-colors hover:bg-forest-700
                active:bg-forest-900"
            >
              儲存花費
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
