import { useState } from 'react'
import { LAYER_KEYS, LAYER_META, LEVELS, SHOPPING, layerBar, pickSession, weatherAdvice } from '../data/outfits'
import { useDailyForecast } from '../hooks/useDailyForecast'
import { sunAdvice, uvLevel, UV_META } from '../data/sun'
import { getNZTimeHHMM } from '../utils/nzTime'

const SANS = 'Inter, sans-serif'
const SERIF = 'Lora, Georgia, serif'

// 洋蔥層數條：實心 = 穿上、虛線框 = 帶著備用、淡色 = 不需要
export function LayerBar({ outfit, height = 8, width = 22 }) {
  return (
    <div style={{ display: 'flex', gap: 3 }} aria-label="洋蔥層數">
      {layerBar(outfit).map((s, i) => (
        <div
          key={i}
          title={`${LAYER_META[LAYER_KEYS[i]].en}：${s === 'wear' ? '穿上' : s === 'carry' ? '帶著備用' : '不需要'}`}
          style={{
            width, height, borderRadius: 2,
            background: s === 'wear' ? '#173D2A' : s === 'carry' ? 'transparent' : '#EEE9DF',
            border: s === 'carry' ? '1.5px dashed #C4952A' : '1.5px solid transparent',
            boxSizing: 'border-box',
          }}
        />
      ))}
    </div>
  )
}

function Row({ icon, label, children, color = '#2A2A2A' }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, padding: '6px 0', borderBottom: '1px solid #F3F0EA' }}>
      <span style={{ width: 18, textAlign: 'center', flexShrink: 0, fontSize: 14 }}>{icon}</span>
      <span style={{ width: 40, flexShrink: 0, fontFamily: SANS, fontSize: 9, letterSpacing: '0.12em',
        color: '#A8A8A8', textTransform: 'uppercase', fontWeight: 600 }}>
        {label}
      </span>
      <span style={{ fontFamily: SANS, fontSize: 13, color, lineHeight: 1.45 }}>{children}</span>
    </div>
  )
}

// 今日穿搭卡（Today 頁、穿搭總覽展開時共用）
// 天氣連動：抓當天預報，依目前顯示的那套（白天 / 晚上）算提醒
export default function OutfitCard({ outfit, onOpenOverview, label = '今日穿搭', autoSession = true }) {
  const weather = useDailyForecast(outfit.date)
  const hasNight = !!outfit.night
  const autoNight = hasNight && autoSession && getNZTimeHHMM() >= outfit.night.from
  const [night, setNight] = useState(autoNight)
  const o = pickSession(outfit, night ? outfit.night.from : '00:00')
  const level = LEVELS[o.level]
  // 一天兩段的日子：最低溫通常出現在晚上，由晚上那套處理，白天不提醒穿羽絨
  const weatherForSession = weather && hasNight && !night ? { ...weather, tmin: null } : weather
  const weatherTips = weatherForSession ? weatherAdvice(o, weatherForSession) : []
  // 防曬：依當天 UV（冰川日加一級）
  const sun = sunAdvice(weather, !!outfit.snow)
  const carryNames = (o.carry || []).filter(k => !o.layers[k]).map(k => LAYER_META[k].zh)

  return (
    <div style={{ border: '1px solid #E6E1D6', borderRadius: 14, background: 'white', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ padding: '12px 14px 10px', background: '#FAF9F5', borderBottom: '1px solid #E6E1D6' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
          <div style={{ fontFamily: SANS, fontSize: 9, letterSpacing: '0.2em', color: '#C4952A',
            textTransform: 'uppercase', fontWeight: 700 }}>
            {outfit.icon} {outfit.theme} · {label}
          </div>
          {level && (
            <span style={{ fontFamily: SANS, fontSize: 10, color: '#6B6B6B', background: '#F3F0EA',
              borderRadius: 999, padding: '2px 8px', flexShrink: 0 }}>
              {level.icon} {level.zh}
            </span>
          )}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8 }}>
          <LayerBar outfit={o} />
          <span style={{ fontFamily: SANS, fontSize: 11, color: '#6B6B6B' }}>{outfit.place}</span>
        </div>
        {weather && (
          <div style={{ fontFamily: SANS, fontSize: 11, color: '#8A8A8A', marginTop: 6 }}>
            🌡 預報 {Math.round(weather.tmin)}–{Math.round(weather.tmax)}°C
            {weather.precip > 0 && ` · 🌧 ${weather.precip.toFixed(1)}mm`}
            {weather.snow > 0 && ` · ❄️ ${weather.snow}cm`}
            {` · 💨 ${Math.round(weather.wind)}km/h`}
            {sun && ` · ☀️ UV ${Math.round(weather.uv)} ${UV_META[uvLevel(weather.uv)].zh}`}
          </div>
        )}
        {hasNight && (
          <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
            {[[false, outfit.session || '白天'], [true, outfit.night.session]].map(([isNight, text]) => (
              <button key={text} onClick={() => setNight(isNight)}
                style={{
                  fontFamily: SANS, fontSize: 11, fontWeight: 600, borderRadius: 999, padding: '4px 10px',
                  cursor: 'pointer', border: '1px solid',
                  borderColor: night === isNight ? '#173D2A' : '#E6E1D6',
                  background: night === isNight ? '#173D2A' : 'white',
                  color: night === isNight ? 'white' : '#6B6B6B',
                }}>
                {isNight ? '🌌 ' : '☀️ '}{text}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Body */}
      <div style={{ padding: '4px 14px 12px' }}>
        {weatherTips.length > 0 && (
          <div style={{ margin: '8px 0 4px', background: '#FFF8E7', border: '1px solid #F1DFAE', borderRadius: 8,
            padding: '7px 10px' }}>
            {weatherTips.map(t => (
              <div key={t} style={{ fontFamily: SANS, fontSize: 12, color: '#7A5A12', lineHeight: 1.5 }}>{t}</div>
            ))}
          </div>
        )}

        {LAYER_KEYS.filter(k => o.layers[k]).map(k => (
          <Row key={k} icon={LAYER_META[k].icon} label={LAYER_META[k].short}>{o.layers[k]}</Row>
        ))}
        {o.bottom && <Row icon="👖" label="褲">{o.bottom}</Row>}
        {o.shoes && <Row icon="👟" label="鞋">{o.shoes}</Row>}
        {o.extras?.length > 0 && <Row icon="🧦" label="其他">{o.extras.join('・')}</Row>}
        {(carryNames.length > 0 || o.carryNote) && (
          <Row icon="🎒" label="帶著" color="#6B6B6B">
            {o.carryNote || carryNames.join('、')}
          </Row>
        )}
        {o.avoid?.map(a => (
          <Row key={a.item} icon="⚠️" label="避免" color="#C0392B">
            {a.item} — {a.reason}
          </Row>
        ))}
        {o.shop && (
          <Row icon="🛍" label="採購">
            {SHOPPING.plan.join('、')}
            <div style={{ fontSize: 11, color: '#6B6B6B' }}>{SHOPPING.slot} · {SHOPPING.route}</div>
            <div style={{ fontSize: 11, color: '#A8A8A8' }}>🅿️ {SHOPPING.parking.name}（{SHOPPING.parking.address.split(',')[0]}）</div>
          </Row>
        )}
        {o.laundry && <Row icon="🧺" label="洗衣" color="#3D6E8A">{o.laundry}</Row>}
        {sun && (
          <Row icon="🧴" label="防曬">
            <span style={{ color: sun.color, fontWeight: 700 }}>UV {sun.zh}{outfit.snow ? '（雪地加一級）' : ''}</span>
            {sun.window && <span style={{ color: '#6B6B6B' }}> · 防曬時段 {sun.window}</span>}
            <div style={{ fontSize: 12, color: '#4A4A4A', marginTop: 2 }}>{sun.steps.join('・')}</div>
          </Row>
        )}
        {o.tips?.length > 0 && (
          <Row icon="📌" label="重點">{o.tips.join('・')}</Row>
        )}
        {o.note && (
          <div style={{ fontFamily: SERIF, fontSize: 12, color: '#6B6B6B', fontStyle: 'italic', lineHeight: 1.6,
            marginTop: 8 }}>
            {o.note}
          </div>
        )}

        {onOpenOverview && (
          <button onClick={onOpenOverview}
            style={{ marginTop: 10, background: 'none', border: 'none', padding: 0, cursor: 'pointer',
              fontFamily: SANS, fontSize: 12, color: '#C4952A', fontWeight: 600 }}>
            看 10 天總覽 →
          </button>
        )}
      </div>
    </div>
  )
}
