// Open-Meteo 天氣預報（16 天內），積雪/強風/大雨警告
import { useState, useEffect } from 'react'
import { wmoToDesc, getWeatherWarnings } from '../data/routes'

function isWithin16Days(dateStr) {
  const diff = (new Date(dateStr + 'T12:00:00+13:00') - new Date()) / 864e5
  return diff >= 0 && diff <= 16
}
function WeatherCard({ date, lat, lng }) {
  const [o, a] = useState('idle'),
    [u, f] = useState(null)
  useEffect(() => {
    if (!date || lat == null || lng == null) return
    if (!isWithin16Days(date)) {
      const w = Math.ceil((new Date(date + 'T12:00:00+13:00') - new Date()) / 864e5)
      a('outofrange')
      f({
        diff: w,
      })
      return
    }
    a('loading')
    const S = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&daily=weathercode,temperature_2m_max,temperature_2m_min,precipitation_sum,snowfall_sum,windspeed_10m_max&timezone=auto&forecast_days=16`
    fetch(S)
      .then(w => w.json())
      .then(w => {
        var z, A
        const E =
          ((A = (z = w.daily) == null ? undefined : z.time) == null ? undefined : A.indexOf(date)) ?? -1
        if (E < 0) {
          a('outofrange')
          f({
            diff: 0,
          })
          return
        }
        f({
          wcode: w.daily.weathercode[E],
          tmax: w.daily.temperature_2m_max[E],
          tmin: w.daily.temperature_2m_min[E],
          precip: w.daily.precipitation_sum[E] ?? 0,
          snow: w.daily.snowfall_sum[E] ?? 0,
          wind: w.daily.windspeed_10m_max[E] ?? 0,
        })
        a('ready')
      })
      .catch(() => a('error'))
  }, [date, lat, lng])
  const h = {
      borderRadius: 10,
      padding: '10px 14px',
      marginTop: 10,
      background: '#F3F0EA',
      fontFamily: 'Inter, sans-serif',
    },
    p = {
      fontSize: 9,
      letterSpacing: '0.18em',
      color: '#8A8A8A',
      textTransform: 'uppercase',
      marginBottom: 4,
    }
  if (o === 'outofrange')
    return (
      <div style={h}>
        <div style={p}>天氣預報</div>
        <div
          style={{
            fontSize: 11,
            color: '#A8A8A8',
          }}
        >
          {'🌤 出發前 '}
          {(u == null ? undefined : u.diff) > 0 ? `${u.diff} 天後` : ''}
          {' 可查看（Open-Meteo 最多預報 16 天）'}
        </div>
      </div>
    )
  if (o === 'loading')
    return (
      <div style={h}>
        <div style={p}>天氣預報</div>
        <div
          style={{
            fontSize: 11,
            color: '#A8A8A8',
          }}
        >
          讀取中…
        </div>
      </div>
    )
  if (o === 'error')
    return (
      <div style={h}>
        <div style={p}>天氣預報</div>
        <div
          style={{
            fontSize: 11,
            color: '#A8A8A8',
          }}
        >
          讀取失敗，請稍後再試
        </div>
      </div>
    )
  if (o !== 'ready' || !u) return null
  const y = wmoToDesc(u.wcode),
    T = getWeatherWarnings(u)
  return (
    <div style={h}>
      <div style={p}>天氣預報</div>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          marginBottom: 4,
        }}
      >
        <span
          style={{
            fontSize: 20,
          }}
        >
          {y.icon}
        </span>
        <div>
          <div
            style={{
              fontSize: 13,
              color: '#2A2A2A',
              fontWeight: 600,
            }}
          >
            {u.tmin}
            {'°C – '}
            {u.tmax}
            {'°C　'}
            {y.text}
          </div>
          <div
            style={{
              fontSize: 10,
              color: '#8A8A8A',
            }}
          >
            {'降雨 '}
            {u.precip}
            {'mm · 風速 '}
            {u.wind}km/h
          </div>
        </div>
      </div>
      {T.map((S, w) => (
        <div
          key={w}
          style={{
            fontSize: 11,
            color: '#C0392B',
            marginTop: 3,
          }}
        >
          {S}
        </div>
      ))}
    </div>
  )
}
export default WeatherCard
