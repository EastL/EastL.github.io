import { useChecklist } from '../hooks/useChecklist'

// App 下載連結：Android 用 Google Play，其他用 App Store
const IS_ANDROID = typeof navigator !== 'undefined' && /android/i.test(navigator.userAgent)

const STATUS_ICON = {
  done:    { icon: '✓', color: '#173D2A', bg: '#EEF7F1', label: '完成' },
  todo:    { icon: '○', color: '#A8A8A8', bg: '#F3F0EA', label: '待辦' },
  recheck: { icon: '!', color: '#C4952A', bg: '#FDF5E4', label: '再確認' },
}

function CheckItem({ item, onToggle }) {
  const s = STATUS_ICON[item.status] || STATUS_ICON.todo
  return (
    <button
      className="w-full text-left flex items-start gap-3 py-3"
      style={{ borderBottom: '1px solid #F3F0EA' }}
      onClick={() => onToggle(item.id)}
    >
      {/* Status badge */}
      <div style={{
        width: 24, height: 24, borderRadius: '50%', flexShrink: 0,
        background: s.bg, border: `1.5px solid ${s.color}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'Inter, sans-serif', fontSize: 11, fontWeight: 700,
        color: s.color, marginTop: 1,
      }}>
        {s.icon}
      </div>

      {/* Content */}
      <div className="flex-1">
        <div style={{
          fontFamily: 'Inter, sans-serif', fontSize: 14,
          color: item.status === 'done' ? '#8A8A8A' : '#2A2A2A',
          textDecoration: 'none',
          lineHeight: 1.4,
        }}>
          {item.titleZh}
        </div>
        {item.note && (
          <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
            color: '#A8A8A8', marginTop: 2, lineHeight: 1.5 }}>
            {item.note}
          </div>
        )}
        {item.link && (
          <a href={(IS_ANDROID && item.link.androidUrl) || item.link.url} target="_blank" rel="noopener noreferrer"
            style={{ display: 'inline-block', marginTop: 5, fontFamily: 'Inter, sans-serif', fontSize: 10,
              color: '#3D6E8A', textDecoration: 'none', border: '1px solid #C5DDE8',
              borderRadius: 4, padding: '3px 8px' }}
            onClick={e => e.stopPropagation()}>
            {item.link.androidUrl ? '📲' : item.link.url.includes('nzta') ? '🌐' : '📄'} {item.link.label} ↗
          </a>
        )}
      </div>
    </button>
  )
}

export default function ChecklistOverlay({ onClose }) {
  const { byCategory, toggleStatus, doneCount, totalCount } = useChecklist()
  const progress = totalCount > 0 ? (doneCount / totalCount) * 100 : 0

  return (
    <div
      className="fixed inset-0 z-[200] flex flex-col"
      style={{ background: '#FAF9F5' }}
    >
      {/* Header */}
      <div style={{ background: '#173D2A', paddingTop: '3.5rem', paddingBottom: '1.25rem' }}>
        <div className="flex items-center justify-between px-6">
          <div>
            <div style={{ fontSize: 10, letterSpacing: '0.22em', color: '#6AAF87',
              fontFamily: 'Inter, sans-serif', textTransform: 'uppercase', marginBottom: 4 }}>
              BEFORE TAKEOFF
            </div>
            <div style={{ fontFamily: 'Lora, Georgia, serif', fontSize: '1.6rem',
              color: 'white', fontWeight: 700 }}>
              出發前準備
            </div>
          </div>
          <button onClick={onClose}
            style={{ width: 36, height: 36, borderRadius: '50%',
              background: 'rgba(255,255,255,0.12)', color: 'white',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0 }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2.5">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>

        {/* Progress */}
        <div className="px-6 mt-4">
          <div style={{ height: 3, background: 'rgba(255,255,255,0.2)',
            borderRadius: 99, overflow: 'hidden', marginBottom: 6 }}>
            <div style={{ height: '100%', background: '#C4952A', borderRadius: 99,
              width: `${progress}%`, transition: 'width 0.6s ease' }} />
          </div>
          <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11,
            color: '#6AAF87', letterSpacing: '0.06em' }}>
            {doneCount} / {totalCount} READY
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="px-6 py-3 flex items-center gap-4"
        style={{ borderBottom: '1px solid #E6E1D6', background: '#F3F0EA' }}>
        {Object.entries(STATUS_ICON).map(([key, s]) => (
          <div key={key} className="flex items-center gap-1.5">
            <div style={{ width: 16, height: 16, borderRadius: '50%',
              background: s.bg, border: `1.5px solid ${s.color}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 8, fontWeight: 700, color: s.color, flexShrink: 0 }}>
              {s.icon}
            </div>
            <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 10, color: '#8A8A8A' }}>
              {s.label}
            </span>
          </div>
        ))}
        <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 10, color: '#A8A8A8', marginLeft: 4 }}>
          點擊切換狀態
        </span>
      </div>

      {/* Scrollable list */}
      <div className="flex-1 overflow-y-auto" style={{ paddingBottom: '2rem' }}>
        {byCategory.map(cat => (
          <div key={cat.id}>
            {/* Category header */}
            <div className="px-6 pt-5 pb-2 flex items-center gap-3">
              <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 9,
                letterSpacing: '0.22em', color: '#8A8A8A',
                textTransform: 'uppercase', fontWeight: 600 }}>
                {cat.labelZh} · {cat.labelEn}
              </span>
              <div style={{ flex: 1, height: 1, background: '#E6E1D6' }} />
              <span style={{ fontFamily: 'Inter, sans-serif', fontSize: 10, color: '#A8A8A8' }}>
                {cat.items.filter(i => i.status === 'done').length}/{cat.items.length}
              </span>
            </div>

            {/* Items */}
            <div className="px-6">
              {cat.items.map(item => (
                <CheckItem key={item.id} item={item} onToggle={toggleStatus} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
