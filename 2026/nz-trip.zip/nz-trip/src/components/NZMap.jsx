// NZ Map — updated with Wanaka, removed Te Anau

export const CITIES = [
  { id: 'CHR', name: 'Christchurch', zh: '基督城',   x: 151, y: 196, day: 2 },
  { id: 'TEK', name: 'Lake Tekapo',  zh: '蒂卡波湖', x: 118, y: 210, day: 3 },
  { id: 'MTK', name: 'Mt Cook',      zh: '庫克山',   x: 103, y: 222, day: 4 },
  { id: 'WAN', name: 'Wanaka',       zh: '瓦納卡',   x: 84,  y: 236, day: 5 },
  { id: 'QTN', name: 'Queenstown',   zh: '皇后鎮',   x: 72,  y: 248, day: 6 },
]

const LAND_ROUTE = [
  [151, 196], // CHR
  [118, 210], // TEK
  [103, 222], // MTK
  [84,  236], // WAN (Wanaka)
  [72,  248], // QTN
]

// No in-NZ flight segment — ZQN → BNE is international (off-map)

function getDotStatus(city, currentDay, tripStatus) {
  if (tripStatus === 'before') return 'upcoming'
  if (tripStatus === 'after')  return 'completed'
  if (city.day < currentDay)   return 'completed'
  if (city.day === currentDay) return 'today'
  return 'upcoming'
}

export default function NZMap({ currentDay, tripStatus }) {
  const doneSegments = (() => {
    if (!currentDay) return 0
    if (tripStatus === 'after') return LAND_ROUTE.length
    // Map day → segments completed (cumulative stops)
    const dayToSeg = { 1:0, 2:1, 3:2, 4:3, 5:4, 6:5, 7:5, 8:5, 9:5, 10:5 }
    return dayToSeg[currentDay] ?? 0
  })()

  const completedPts = LAND_ROUTE.slice(0, doneSegments + 1).map(([x,y]) => `${x},${y}`).join(' ')
  const upcomingPts  = LAND_ROUTE.slice(Math.max(0, doneSegments)).map(([x,y]) => `${x},${y}`).join(' ')

  return (
    <svg viewBox="0 0 200 305" className="w-full h-full" style={{ display: 'block' }}>

      {/* ── North Island ── */}
      <path
        d="M 120 20 C 135 24, 150 34, 160 46 C 166 56, 168 66, 164 76
           L 174 88 C 179 98, 181 110, 178 122 C 175 134, 170 145, 164 155
           C 158 163, 150 170, 143 175 C 137 179, 130 181, 124 178
           C 117 174, 112 168, 110 160 C 108 150, 110 139, 112 128
           C 114 118, 114 107, 112 97 C 110 87, 112 77, 116 67
           C 118 57, 118 42, 120 28 C 120 24, 120 20, 120 20 Z"
        fill="#EEF5EE" stroke="#2E7D50" strokeWidth="1.2" strokeLinejoin="round"
      />
      <path d="M 110 130 C 104 132, 100 138, 104 144 C 108 150, 112 148, 112 140"
        fill="#EEF5EE" stroke="#2E7D50" strokeWidth="1.2" />

      {/* ── South Island ── */}
      <path
        d="M 80 148 C 94 144, 112 142, 128 146 C 140 150, 150 158, 156 170
           C 160 180, 161 193, 160 206 C 159 219, 156 232, 152 244
           C 148 256, 142 266, 134 274 C 126 282, 116 287, 105 289
           C 94 291, 83 289, 72 283 C 61 276, 50 264, 42 250
           C 34 236, 30 220, 30 204 C 30 188, 34 172, 42 160
           C 50 148, 64 144, 80 148 Z"
        fill="#EEF5EE" stroke="#2E7D50" strokeWidth="1.2" strokeLinejoin="round"
      />
      <path d="M 34 236 C 28 242, 26 252, 32 258"
        fill="none" stroke="#2E7D50" strokeWidth="1" opacity="0.6" />

      {/* ── Stewart Island ── */}
      <ellipse cx="78" cy="300" rx="11" ry="7"
        fill="#EEF5EE" stroke="#2E7D50" strokeWidth="1" />

      {/* ── Cook Strait ── */}
      <text x="134" y="143" fontSize="5.5" fontFamily="Inter,sans-serif"
        fill="#9BBFD5" letterSpacing="0.5" textAnchor="middle" opacity="0.8">
        COOK STRAIT
      </text>

      {/* ── Completed route ── */}
      {doneSegments > 0 && completedPts && (
        <polyline points={completedPts} fill="none"
          stroke="#C4952A" strokeWidth="2.5"
          strokeLinecap="round" strokeLinejoin="round" />
      )}

      {/* ── Upcoming route ── */}
      {doneSegments < LAND_ROUTE.length - 1 && upcomingPts && (
        <polyline points={upcomingPts} fill="none"
          stroke="#3D6E8A" strokeWidth="1.5"
          strokeLinecap="round" strokeLinejoin="round"
          strokeDasharray="4 3" opacity="0.6" />
      )}

      {/* Departure: ZQN → BNE → TPE (international, not shown on NZ map) */}
      {/* Show a small departure indicator at Queenstown when trip is over */}

      {/* ── City nodes ── */}
      {CITIES.map(city => {
        const status = getDotStatus(city, currentDay, tripStatus)
        const isToday = status === 'today'
        const isDone  = status === 'completed'
        const labelLeft = city.x < 100

        return (
          <g key={city.id}>
            {isToday && <>
              <circle cx={city.x} cy={city.y} r="8" fill="#C4952A" opacity="0.15">
                <animate attributeName="r" values="6;11;6" dur="1.8s" repeatCount="indefinite"/>
                <animate attributeName="opacity" values="0.3;0;0.3" dur="1.8s" repeatCount="indefinite"/>
              </circle>
            </>}
            <circle cx={city.x} cy={city.y}
              r={isToday ? 5 : 4}
              fill={isToday ? '#C4952A' : isDone ? '#173D2A' : '#FAF9F5'}
              stroke={isToday ? '#F4EBC8' : isDone ? '#2E7D50' : '#9BBFD5'}
              strokeWidth="1.5"
            />
            <text
              x={labelLeft ? city.x - 7 : city.x + 7}
              y={city.y + 1}
              textAnchor={labelLeft ? 'end' : 'start'}
              dominantBaseline="middle"
              fontSize="6.5" fontFamily="Inter, sans-serif"
              fontWeight={isToday ? '700' : isDone ? '500' : '400'}
              fill={isToday ? '#C4952A' : isDone ? '#173D2A' : '#6B6B6B'}
            >
              {city.zh}
            </text>
          </g>
        )
      })}

      {/* ── Compass ── */}
      <g transform="translate(186, 288)" opacity="0.35">
        <circle cx="0" cy="0" r="6" fill="none" stroke="#8A8A8A" strokeWidth="0.8"/>
        <text x="0" y="-9" textAnchor="middle" fontSize="5" fill="#8A8A8A" fontFamily="Inter">N</text>
        <line x1="0" y1="-4" x2="0" y2="4" stroke="#8A8A8A" strokeWidth="0.8"/>
        <line x1="-4" y1="0" x2="4" y2="0" stroke="#8A8A8A" strokeWidth="0.8"/>
      </g>
    </svg>
  )
}
