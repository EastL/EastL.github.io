import { useEffect } from 'react'

function QuestCard({ quest }) {
  return (
    <div style={{ marginBottom: 32 }}>
      {/* Quest header */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 28, lineHeight: 1, marginBottom: 6 }}>{quest.emoji}</div>
        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 9,
          letterSpacing: '0.2em', color: '#C4952A',
          textTransform: 'uppercase', fontWeight: 600, marginBottom: 3 }}>
          {quest.type === 'dinner' ? 'DINNER QUEST'
            : quest.type === 'dessert' ? 'DESSERT QUEST'
            : quest.type === 'local-specialty' ? 'LOCAL SPECIALTY'
            : 'FOOD QUEST'}
        </div>
        <div style={{ fontFamily: 'Lora, Georgia, serif',
          fontSize: '1.2rem', color: '#173D2A', fontWeight: 700, lineHeight: 1.2 }}>
          {quest.food}
        </div>
        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 12,
          color: '#8A8A8A', marginTop: 6, lineHeight: 1.6 }}>
          {quest.description}
        </div>
      </div>

      {/* Restaurants */}
      {quest.restaurants.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {quest.restaurants.map((r, i) => (
            <div key={i} style={{
              background: '#F3F0EA', borderRadius: 12, padding: '12px 14px',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between',
                alignItems: 'flex-start', gap: 8, marginBottom: 4 }}>
                <div style={{ fontFamily: 'Inter, sans-serif',
                  fontSize: 13, color: '#2A2A2A', fontWeight: 600 }}>
                  {r.name}
                </div>
                {r.googleMapsUrl && (
                  <a href={r.googleMapsUrl} target="_blank" rel="noopener noreferrer"
                    style={{
                      fontFamily: 'Inter, sans-serif', fontSize: 9,
                      letterSpacing: '0.1em', color: '#3D6E8A', fontWeight: 700,
                      textDecoration: 'none', flexShrink: 0,
                      border: '1px solid #C5DDE8', borderRadius: 4,
                      padding: '3px 6px', whiteSpace: 'nowrap',
                    }}>
                    MAP ↗
                  </a>
                )}
              </div>
              <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 10,
                color: '#C4952A', letterSpacing: '0.08em',
                textTransform: 'uppercase', marginBottom: 4 }}>
                {r.mealType}
                {r.reservationRecommended && ' · 建議訂位'}
              </div>
              <div style={{ fontFamily: 'Inter, sans-serif',
                fontSize: 11, color: '#6B6B6B', lineHeight: 1.6 }}>
                {r.description}
              </div>
              {r.address && (
                <div style={{ fontFamily: 'Inter, sans-serif',
                  fontSize: 10, color: '#A8A8A8', marginTop: 5 }}>
                  {r.address}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Alternatives */}
      {quest.alternatives && (
        <div style={{ marginTop: 10, padding: '8px 12px',
          borderLeft: '2px solid #E6E1D6',
          fontFamily: 'Inter, sans-serif', fontSize: 11,
          color: '#8A8A8A', lineHeight: 1.6 }}>
          <span style={{ color: '#A8A8A8', fontWeight: 600 }}>備選：</span> {quest.alternatives}
        </div>
      )}
    </div>
  )
}

export default function FoodQuestModal({ date, data, onClose }) {
  // Prevent body scroll when modal open
  useEffect(() => {
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = '' }
  }, [])

  if (!data) return null

  const dateLabel = new Intl.DateTimeFormat('zh-TW', {
    month: 'numeric', day: 'numeric', weekday: 'short',
  }).format(new Date(date + 'T12:00:00'))

  return (
    <div
      style={{
        position: 'fixed', inset: 0, zIndex: 300,
        background: 'rgba(0,0,0,0.55)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '16px',
        paddingBottom: 'calc(72px + 16px)',
      }}
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
    >
      <div style={{
        background: '#FAF9F5',
        borderRadius: 20,
        width: '100%',
        maxWidth: 480,
        maxHeight: 'calc(100vh - 160px)',
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Fixed header */}
        <div style={{
          padding: '20px 24px 16px', flexShrink: 0,
          borderBottom: '1px solid #E6E1D6',
          display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
        }}>
          <div>
            <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 9,
              letterSpacing: '0.22em', color: '#8A8A8A',
              textTransform: 'uppercase', marginBottom: 3 }}>
              {data.city} · {dateLabel}
            </div>
            <div style={{ fontFamily: 'Lora, Georgia, serif',
              fontSize: '1.3rem', color: '#173D2A', fontWeight: 700 }}>
              Food Quest
            </div>
          </div>
          <button onClick={onClose}
            style={{ color: '#A8A8A8', lineHeight: 1, padding: 4, marginTop: 2 }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2.5">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>

        {/* Scrollable content */}
        <div style={{ overflowY: 'auto', flex: 1, padding: '24px 24px 32px' }}>
          {data.quests.map(quest => (
            <QuestCard key={quest.id} quest={quest} />
          ))}
        </div>
      </div>
    </div>
  )
}
