import { useUpdateCheck, reloadToBuild } from '../hooks/useUpdateCheck'

// 有新版本時浮在最上方（蓋過 DayModal），避開狀態列
export default function UpdateBanner() {
  const newBuild = useUpdateCheck()
  if (!newBuild) return null

  return (
    <button
      onClick={() => reloadToBuild(newBuild)}
      style={{
        position: 'fixed',
        top: 'calc(env(safe-area-inset-top) + 10px)',
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 2000,
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        background: '#C4952A',
        color: 'white',
        border: 'none',
        borderRadius: 999,
        padding: '9px 16px',
        boxShadow: '0 4px 16px rgba(0,0,0,0.18)',
        fontFamily: 'Inter, sans-serif',
        fontSize: 13,
        fontWeight: 600,
        cursor: 'pointer',
        whiteSpace: 'nowrap',
      }}
    >
      🔄 有新版本 · 點此更新
    </button>
  )
}
