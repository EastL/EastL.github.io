// ─── Expenses: Single Source of Truth ──────────────────────────────────────────
// All amounts in TWD unless otherwise noted.
// Shared = 2-person total, split equally.
// Personal = individual, NOT split.

import { ACCOMMODATIONS, RENTAL_CARS, ACTIVITIES } from './trip.js'

// ── Shared confirmed expenses (accommodation + car + activities) ────────────────
export const sharedConfirmedExpenses = [
  ...ACCOMMODATIONS.map(a => ({
    id:        `accomm-${a.id}`,
    date:      a.checkIn,
    item:      a.name,
    category:  'accommodation',
    TWD:       a.priceTWD,
    currency:  'TWD',
    people:    a.guests,
    splitType: 'equal',
    status:    a.status,
    note:      `${a.checkIn} – ${a.checkOut} · ${a.nights} 晚`,
  })),
  ...RENTAL_CARS.map(r => ({
    id:        `rental-${r.id}`,
    date:      r.pickupDate,
    item:      r.vehicle,
    category:  'rental',
    TWD:       r.priceTWD,
    currency:  'TWD',
    people:    r.people,
    splitType: 'equal',
    status:    r.status,
    note:      `${r.pickupDate} – ${r.dropoffDate} · ${r.pickupCity} → ${r.dropoffCity}`,
  })),
  ...ACTIVITIES.map(a => ({
    id:        `activity-${a.id}`,
    date:      a.date,
    item:      a.name,
    category:  'activity',
    TWD:       a.priceTWD,
    currency:  'TWD',
    people:    a.people,
    splitType: 'equal',
    status:    a.status,
    note:      a.note || null,
  })),
]

// ── Personal expenses (individual TWD, NOT shared) ─────────────────────────────
export const personalExpenses = [
  {
    id:        'flight-dongyue',
    date:      '2026-10-08',
    item:      '東岳 紐西蘭來回機票',
    category:  'flight',
    TWD:       69203,
    currency:  'TWD',
    people:    1,
    traveler:  '東岳',
    splitType: 'personal',
    status:    'confirmed',
    note:      'CI057 / QF169 / QF186 / CI054',
  },
  {
    id:        'esim-dongyue',
    date:      '2026-10-09',
    item:      '東岳 漫遊上網（紐西蘭）',
    category:  'other',
    TWD:       1490,          // NT$149/日 × 10 日 (10/09–10/18)
    NZD:       null,
    USD:       null,
    currency:  'TWD',
    people:    1,
    traveler:  '東岳',
    splitType: 'personal',
    status:    'confirmed',
    note:      '漫遊上網計日型_美加紐澳 8-30日型149 · NT$149/日 × 10 日',
  },
  {
    id:        'insurance-travel-dongyue',
    date:      '2026-10-08',
    item:      '東岳 旅平險（富邦）',
    category:  'other',
    TWD:       2229,
    NZD:       null, USD: null, currency: 'TWD',
    people:    1, traveler: '東岳', splitType: 'personal', status: 'confirmed',
    note:      '保單號 0026CT201M3637 · 透過台哥大 APP 投保 · 旅行平安險 + 海外急難醫療 + 綜合旅行保險',
  },
  {
    id:        'insurance-activity-dongyue',
    date:      '2026-10-08',
    item:      '東岳 精采人生2.0 特定活動專案',
    category:  'other',
    TWD:       864,
    NZD:       null, USD: null, currency: 'TWD',
    people:    1, traveler: '東岳', splitType: 'personal', status: 'confirmed',
    note:      '保單號 0326CT00001989 · 保險期間 Oct 12–16 · 涵蓋：高空跳傘、冰川直升機等特定活動',
  },
  {
    id:        'flight-brother',
    date:      '2026-10-08',
    item:      '東振 紐西蘭來回機票',
    category:  'flight',
    TWD:       68125,
    currency:  'TWD',
    people:    1,
    traveler:  '東振',
    splitType: 'personal',
    status:    'confirmed',
    note:      'CI057 / QF169 / QF186 / CI054',
  },
  // ── 東振：漫遊、旅平險、精采人生 與東岳相同（2026-10-06 確認）──
  {
    id:        'esim-brother',
    date:      '2026-10-09',
    item:      '東振 漫遊上網（紐西蘭）',
    category:  'other',
    TWD:       1490,          // NT$149/日 × 10 日 (10/09–10/18)
    NZD:       null,
    USD:       null,
    currency:  'TWD',
    people:    1,
    traveler:  '東振',
    splitType: 'personal',
    status:    'confirmed',
    note:      '漫遊上網計日型_美加紐澳 8-30日型149 · NT$149/日 × 10 日（同東岳）',
  },
  {
    id:        'insurance-travel-brother',
    date:      '2026-10-08',
    item:      '東振 旅平險',
    category:  'other',
    TWD:       2229,
    NZD:       null, USD: null, currency: 'TWD',
    people:    1, traveler: '東振', splitType: 'personal', status: 'confirmed',
    note:      '保費同東岳 · 保單號待補',
  },
  {
    id:        'insurance-activity-brother',
    date:      '2026-10-08',
    item:      '東振 精采人生2.0 特定活動專案',
    category:  'other',
    TWD:       864,
    NZD:       null, USD: null, currency: 'TWD',
    people:    1, traveler: '東振', splitType: 'personal', status: 'confirmed',
    note:      '保費同東岳 · 保險期間 Oct 12–16 · 涵蓋：高空跳傘、冰川直升機等特定活動 · 保單號待補',
  },
]

// ── TBD / Not included yet (amounts unknown — NOT in confirmed totals) ──────────
export const upcomingExpenses = [
  {
    id:    'rental-insurance',
    item:  '當地租車車險',
    category: 'rental',
    TWD:   null,
    people: 2,
    splitType: 'equal',
    status: 'todo',
    note:  '預計向當地租車公司購買，方案與金額尚未確認',
  },
  { id: 'fuel',    item: '油費',   category: 'transport', TWD: null, status: 'tbd' },
  { id: 'parking', item: '停車費', category: 'transport', TWD: null, status: 'tbd' },
  { id: 'food',    item: '餐飲',   category: 'food',      TWD: null, status: 'tbd' },
  { id: 'shopping',item: '購物',   category: 'other',     TWD: null, status: 'tbd' },
]

// ── Pre-computed totals ────────────────────────────────────────────────────────
export const ACCOMM_TOTAL_TWD    = ACCOMMODATIONS.reduce((s, a) => s + a.priceTWD, 0)  // 41,319
export const RENTAL_TOTAL_TWD    = RENTAL_CARS.reduce((s, r) => s + r.priceTWD, 0)    //  9,326
export const ACTIVITY_TOTAL_TWD  = ACTIVITIES.reduce((s, a) => s + a.priceTWD, 0)     // 78,796
export const SHARED_CONFIRMED_TWD = ACCOMM_TOTAL_TWD + RENTAL_TOTAL_TWD + ACTIVITY_TOTAL_TWD // 129,441
export const PER_PERSON_SHARED_TWD = SHARED_CONFIRMED_TWD / 2  // 64,720.50

export const FLIGHT_DONGYUE_TWD = 69203
export const FLIGHT_BROTHER_TWD = 68125
export const FLIGHTS_TOTAL_TWD  = FLIGHT_DONGYUE_TWD + FLIGHT_BROTHER_TWD  // 137,328

export const GRAND_CONFIRMED_TWD = SHARED_CONFIRMED_TWD + FLIGHTS_TOTAL_TWD  // 266,769

export const ESIM_DONGYUE_TWD       = 1490   // NT$149/日 × 10 日
export const INSURANCE_DONGYUE_TWD  = 2229 + 864  // 旅平險 + 特定活動
export const ESIM_BROTHER_TWD       = 1490   // 同東岳
export const INSURANCE_BROTHER_TWD  = 2229 + 864  // 同東岳
export const PERSONAL_COST_DONGYUE = FLIGHT_DONGYUE_TWD + PER_PERSON_SHARED_TWD + ESIM_DONGYUE_TWD + INSURANCE_DONGYUE_TWD
export const PERSONAL_COST_BROTHER  = FLIGHT_BROTHER_TWD + PER_PERSON_SHARED_TWD + ESIM_BROTHER_TWD + INSURANCE_BROTHER_TWD  // 137,428.50

// Legacy alias for useExpenses hook compatibility
export const initialExpenses = sharedConfirmedExpenses
