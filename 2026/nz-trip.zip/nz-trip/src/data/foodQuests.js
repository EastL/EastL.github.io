// ─── Food Quest — Central Data Source ─────────────────────────────────────────
// 唯一資料來源，Today 與 Itinerary 都讀這裡。
// 更新餐廳 / quest 只需改此檔案。
//
// Google Maps URL 格式：
// https://www.google.com/maps/search/?api=1&query=<encoded name + city>

const mapsUrl = (query) =>
  `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`

export const FOOD_QUESTS = {

  // ── Oct 09 · Melbourne Transit ─────────────────────────────────────────────────
  '2026-10-09': {
    city: 'Melbourne',
    quests: [
      {
        id: 'mel-flat-white',
        emoji: '☕',
        food: 'Melbourne Flat White',
        type: 'casual',
        description: 'Flat White 的發源地就是墨爾本。就算只有一小時，這杯咖啡不能錯過。方案 B 出城才有機會完成。',
        restaurants: [
          {
            name: 'Dukes Coffee Roasters',
            description: '墨爾本最受推崇的精品咖啡之一，Flinders Lane 旗艦店在美麗的老建築裡。Flat White 必點。',
            address: '247 Flinders Lane, Melbourne CBD',
            googleMapsUrl: mapsUrl('Dukes Coffee Roasters 247 Flinders Lane Melbourne'),
            mealType: '咖啡 · 隨時',
            reservationRecommended: false,
          },
          {
            name: 'Market Lane Coffee',
            description: '同樣在 Ross House（247 Flinders Lane），旁邊就是 Dukes，兩家都值得試。',
            address: '247 Flinders Lane, Melbourne CBD',
            googleMapsUrl: mapsUrl('Market Lane Coffee Flinders Lane Melbourne'),
            mealType: '咖啡 · 隨時',
            reservationRecommended: false,
          },
        ],
        alternatives: '方案 A 待機場：T2 內的 café 咖啡品質不差，至少喝一杯澳洲 flat white 再上飛機。',
      },
      {
        id: 'mel-meat-pie',
        emoji: '🥧',
        food: 'Aussie Meat Pie',
        type: 'casual',
        description: '澳洲版 meat pie 跟紐西蘭有點不同，趁在墨爾本先比較一下。機場和 CBD 到處都有。',
        restaurants: [
          {
            name: 'Flinders Lane 附近的咖啡廳',
            description: '大多數精品咖啡廳旁邊都有賣 pie 和 pastry，點咖啡時一起解決午餐。',
            address: 'Flinders Lane, Melbourne CBD',
            googleMapsUrl: mapsUrl('Flinders Lane Melbourne food'),
            mealType: '午餐 · 輕食',
            reservationRecommended: false,
          },
        ],
        alternatives: '方案 A：機場 T2 的 Freshii 或 Nando\'s 都可以，不講究但夠填飽肚子。',
      },
    ],
  },

  // ── Oct 10 · Christchurch ───────────────────────────────────────────────────
  '2026-10-10': {
    city: 'Christchurch',
    quests: [
      {
        id: 'chc-meat-pie',
        emoji: '🥧',
        food: 'New Zealand Meat Pie',
        type: 'casual',
        description: 'Kiwi 國民小吃，白天逛基督城市區時最適合順路完成。',
        restaurants: [
          {
            name: 'Riverside Market',
            description: '基督城室內市集，多家攤位有 meat pie，逛市場順便解決午餐。',
            address: '96 Oxford Tce, Christchurch 8011',
            googleMapsUrl: mapsUrl('Riverside Market Christchurch'),
            mealType: '午餐 · 輕食',
            reservationRecommended: false,
          },
          {
            name: 'Little High Eatery',
            description: '集合式美食廣場，多種選擇，meat pie 是其中之一。',
            address: '255 St Asaph St, Christchurch 8011',
            googleMapsUrl: mapsUrl('Little High Eatery Christchurch'),
            mealType: '午餐',
            reservationRecommended: false,
          },
        ],
        alternatives: '任何超市或加油站也能買到基本款，Four Square 通常都有。',
      },
      {
        id: 'chc-lamb',
        emoji: '🐑',
        food: 'Canterbury Lamb',
        type: 'dinner',
        description: '第一晚正式晚餐。Canterbury 平原是紐西蘭最知名的羊肉產地，在基督城吃最道地。',
        restaurants: [
          {
            name: 'Twenty Seven Steps',
            description: '基督城知名餐廳，招牌菜是 Canterbury lamb rack with potato gratin，氣氛好適合第一晚。',
            address: '16 New Regent St, Christchurch 8011',
            googleMapsUrl: mapsUrl('Twenty Seven Steps Christchurch'),
            mealType: '晚餐',
            reservationRecommended: true,
          },
          {
            name: 'Soul Quarter',
            description: 'Michelin Bib Gourmand 認證，charcoal-grilled Canterbury lamb rump，藏在 Stranges Lane 小巷裡。',
            address: '219 High St, Stranges Lane, Christchurch 8011',
            googleMapsUrl: mapsUrl('Soul Quarter Christchurch'),
            mealType: '晚餐',
            reservationRecommended: true,
          },
        ],
        alternatives: '訂不到位的話，Fiddlesticks Restaurant & Bar 也有 Canterbury 食材。',
      },
    ],
  },

  // ── Oct 11 · Lake Tekapo ────────────────────────────────────────────────────
  '2026-10-11': {
    city: 'Lake Tekapo',
    quests: [
      {
        id: 'tek-salmon',
        emoji: '🍣',
        food: 'New Zealand Salmon',
        type: 'local-specialty',
        description: '蒂卡波附近是 NZ 高地鮭魚主要養殖地，在這裡吃是整趟旅行最新鮮的一次。',
        restaurants: [
          {
            name: 'Kohan Restaurant',
            description: '湖邊日式餐廳，用當地 Mt Cook 鮭魚做壽司 / 刺身，景觀極佳。觀星前可以在這裡晚餐。',
            address: '6 Rapuwai Lane, Lake Tekapo 7999',
            googleMapsUrl: mapsUrl('Kohan Restaurant Lake Tekapo'),
            mealType: '午餐 · 晚餐',
            reservationRecommended: true,
          },
        ],
        alternatives: 'High Country Salmon Farm — 農場直銷，可買煙燻鮭魚帶走當零食。',
      },
      {
        id: 'tek-hokey-pokey',
        emoji: '🍦',
        food: 'Hokey Pokey Ice Cream',
        type: 'dessert',
        description: '紐西蘭國民冰淇淋口味，焦糖太妃糖脆片混入香草，隨處可買。',
        restaurants: [],
        alternatives: '任何 Four Square、New World 超市、加油站都找得到。Lake Tekapo 市區便利店也有。',
      },
    ],
  },

  // ── Oct 12 · Aoraki / Mt Cook ───────────────────────────────────────────────
  '2026-10-12': {
    city: 'Aoraki / Mt Cook',
    quests: [
      {
        id: 'mtk-high-altitude',
        emoji: '🏔️',
        food: 'High Country Dining',
        type: 'restaurant',
        description: '庫克山村子餐廳選擇有限，但有全紐西蘭最壯觀的用餐環境。直升機活動完後好好吃一頓。',
        restaurants: [
          {
            name: 'The Hermitage — Panorama Restaurant',
            description: '270 度庫克山全景用餐，使用 Canterbury 在地食材。是整趟旅行最特別的用餐環境。',
            address: 'Terrace Rd, Mount Cook Village 7999',
            googleMapsUrl: mapsUrl('Hermitage Hotel Panorama Restaurant Mount Cook'),
            mealType: '晚餐',
            reservationRecommended: true,
          },
          {
            name: 'Old Mountaineers Café & Bar',
            description: '庫克山村子裡的輕鬆選項，漢堡、派、咖啡，直升機活動完後可以直接來。',
            address: 'Bowen Dr, Mount Cook Village 7999',
            googleMapsUrl: mapsUrl('Old Mountaineers Cafe Mount Cook'),
            mealType: '午餐 · 輕食',
            reservationRecommended: false,
          },
        ],
        alternatives: 'The Hermitage 的酒吧區也可以只點飲料和小食，不用正餐也行。',
      },
    ],
  },

  // ── Oct 13 · Wanaka ─────────────────────────────────────────────────────────
  '2026-10-13': {
    city: 'Wanaka',
    quests: [
      {
        id: 'wan-fish-chips',
        emoji: '🐟',
        food: 'Fish & Chips',
        type: 'casual',
        description: '瓦納卡湖邊是吃 fish & chips 的最佳場景。買完走去湖邊那棵著名的孤樹野餐。',
        restaurants: [
          {
            name: 'Kai Whaka Pai',
            description: '瓦納卡最受好評的 fish & chips，炸魚新鮮酥脆，本地人和旅客都推。',
            address: '121 Ardmore St, Wanaka 9305',
            googleMapsUrl: mapsUrl('Kai Whaka Pai Wanaka'),
            mealType: '午餐 · 輕食',
            reservationRecommended: false,
          },
          {
            name: 'Wanaka Takeaways',
            description: '在地老字號，CP 值高，份量大。',
            address: '72 Ardmore St, Wanaka 9305',
            googleMapsUrl: mapsUrl('Wanaka Takeaways'),
            mealType: '午餐 · 輕食',
            reservationRecommended: false,
          },
        ],
        alternatives: '買完直接走到 Lake Wanaka，That Wanaka Tree 旁邊找個位置坐下來吃。',
      },
    ],
  },

  // ── Oct 14 · Queenstown ─────────────────────────────────────────────────────
  '2026-10-14': {
    city: 'Queenstown',
    quests: [
      {
        id: 'qtn-fergburger',
        emoji: '🍔',
        food: 'Fergburger',
        type: 'casual',
        description: '皇后鎮最著名的排隊漢堡，Mr. Big Stuff 是招牌款。不排一次不算來過皇后鎮。',
        restaurants: [
          {
            name: 'Fergburger',
            description: '招牌點 Mr. Big Stuff（雙層牛肉）或 The Bun（素）。隊伍長但移動快，值得等。',
            address: '42 Shotover St, Queenstown 9300',
            googleMapsUrl: mapsUrl('Fergburger Queenstown'),
            mealType: '午餐 · 隨時',
            reservationRecommended: false,
          },
        ],
        alternatives: '旁邊的 Fergbaker 有 pie 和甜點，可以一起買。早上去隊伍比較短。',
      },
    ],
  },

  // ── Oct 15 · Queenstown ─────────────────────────────────────────────────────
  '2026-10-15': {
    city: 'Queenstown',
    quests: [
      {
        id: 'qtn-mussels',
        emoji: '🦪',
        food: 'Green-lipped Mussels',
        type: 'dinner',
        description: '紐西蘭特有的綠唇貝，肉質肥厚。跳傘完成後最適合犒勞自己的晚餐 quest。',
        restaurants: [
          {
            name: 'Rata Restaurant',
            description: '皇后鎮知名餐廳，主廚 Josh Emett 出品，綠唇貝是常見前菜，適合跳傘後犒勞自己。',
            address: '43 Ballarat St, Queenstown 9300',
            googleMapsUrl: mapsUrl('Rata Restaurant Queenstown'),
            mealType: '晚餐',
            reservationRecommended: true,
          },
          {
            name: 'Botswana Butchery',
            description: '高一點的餐廳，可以點 mussels starter 配 Central Otago Pinot Noir，湖景。',
            address: '17 Marine Parade, Queenstown 9300',
            googleMapsUrl: mapsUrl('Botswana Butchery Queenstown'),
            mealType: '晚餐',
            reservationRecommended: true,
          },
        ],
        alternatives: 'Central Otago Pinot Noir 也可以去 Wine Vault Queenstown 挑一瓶帶回 Nomads。',
      },
    ],
  },

  // ── Oct 16 · Milford Sound ───────────────────────────────────────────────────
  '2026-10-16': {
    city: 'Milford Sound',
    quests: [
      {
        id: 'mil-cruise-lunch',
        emoji: '⛵',
        food: 'Fiordland Cruise Lunch',
        type: 'casual',
        description: '遊船包含午餐 buffet，邊吃邊看瀑布和海豹。這餐的重點是景觀，不是食物。',
        restaurants: [
          {
            name: 'Pure Milford 遊船餐廳',
            description: '行程已包含船上午餐，不需要額外預訂。熱食 buffet，選擇普通但很夠吃。',
            address: 'Milford Sound Wharf, Milford Sound 9679',
            googleMapsUrl: null,
            mealType: '午餐 · 已含在票價',
            reservationRecommended: false,
          },
        ],
        alternatives: '回程路上的 Te Anau 有一些餐廳，如果餓了可以停下來吃晚餐再回皇后鎮。',
      },
    ],
  },
}

// ── Helpers ───────────────────────────────────────────────────────────────────
export function getFoodQuestsForDate(date) {
  return FOOD_QUESTS[date] || null
}

export function getTotalQuestCount(date) {
  const data = getFoodQuestsForDate(date)
  return data ? data.quests.length : 0
}
