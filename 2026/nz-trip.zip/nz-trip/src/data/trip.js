// ─── Single Source of Truth for all confirmed bookings ─────────────────────────

// ── Flights ───────────────────────────────────────────────────────────────────
export const FLIGHTS = [
  {
    id: 'CI057', flight: 'CI057', airline: 'China Airlines',
    from: { code: 'TPE', name: 'Taipei',       nameZh: '台北' },
    to:   { code: 'MEL', name: 'Melbourne',    nameZh: '墨爾本' },
    departDate: '2026-10-08', departTime: '23:30',
    arriveDate: '2026-10-09', arriveTime: '11:40',
    travelers: ['東岳', '東振'],
  },
  {
    id: 'QF169', flight: 'QF169', airline: 'Qantas',
    from: { code: 'MEL', name: 'Melbourne',    nameZh: '墨爾本' },
    to:   { code: 'CHC', name: 'Christchurch', nameZh: '基督城' },
    departDate: '2026-10-09', departTime: '18:40',
    arriveDate: '2026-10-10', arriveTime: '00:10',
    travelers: ['東岳', '東振'],
  },
  {
    id: 'QF186', flight: 'QF186', airline: 'Qantas',
    from: { code: 'ZQN', name: 'Queenstown',   nameZh: '皇后鎮' },
    to:   { code: 'BNE', name: 'Brisbane',     nameZh: '布里斯本' },
    departDate: '2026-10-17', departTime: '19:45',
    arriveDate: '2026-10-17', arriveTime: '20:35',
    travelers: ['東岳', '東振'],
  },
  {
    id: 'CI054', flight: 'CI054', airline: 'China Airlines',
    from: { code: 'BNE', name: 'Brisbane',     nameZh: '布里斯本' },
    to:   { code: 'TPE', name: 'Taipei',       nameZh: '台北' },
    departDate: '2026-10-17', departTime: '22:50',
    arriveDate: '2026-10-18', arriveTime: '05:40',
    travelers: ['東岳', '東振'],
  },
]

// ── Accommodations ─────────────────────────────────────────────────────────────
// All times confirmed from Booking.com screenshots.
export const ACCOMMODATIONS = [
  {
    id: 'sudima-chc',
    name: 'Sudima Christchurch',
    city: 'Christchurch',
    address: '550 Memorial Avenue, 8005, Christchurch, New Zealand',
    phone: '+64 3 358 3139',
    checkIn:  '2026-10-09', checkInTime:  '14:00',
    checkOut: '2026-10-11', checkOutTime: '11:00',
    nights: 2, priceTWD: 10500, guests: 2, status: 'confirmed',
  },
  {
    id: 'skyblue-tekapo',
    name: 'Skyblue Tekapo',
    city: 'Lake Tekapo',
    address: '9 Andrew Don Drive, Lake Tekapo, 7999, New Zealand',
    phone: null,  // 自助入住，access code 在 email
    checkIn:  '2026-10-11', checkInTime:  '15:00', checkInWindow:  '15:00–21:00',
    checkOut: '2026-10-12', checkOutTime: '06:30', checkOutWindow: '06:30–10:00',
    nights: 1, priceTWD: 5467, guests: 2, status: 'confirmed',
  },
  {
    id: 'haka-mtcook',
    name: 'Haka House Hostel Aoraki Mt Cook',
    city: 'Aoraki / Mt Cook',
    address: '4 Kitchener Drive, 7999, Mt Cook Village, New Zealand',
    phone: '+64 03 7400428',
    checkIn:  '2026-10-12', checkInTime:  '14:00', checkInWindow:  '14:00–23:00',
    checkOut: '2026-10-13', checkOutTime: '10:00',
    nights: 1, priceTWD: 7631, guests: 2, status: 'confirmed',
  },
  {
    id: 'room-peninsula',
    name: 'A Room on the Peninsula',
    city: 'Wanaka',            // ← Wanaka, NOT Queenstown
    address: 'Diamond Lane 6, 9305, Wanaka, New Zealand',
    phone: '+64 21 137 2151',  // Airbnb 房東
    checkIn:  '2026-10-13', checkInTime:  '15:00', checkInWindow:  '15:00–22:00',
    checkOut: '2026-10-14', checkOutTime: '10:00',
    nights: 1, priceTWD: 7959, guests: 2, status: 'confirmed',
  },
  {
    id: 'nomads-queenstown',
    name: 'Nomads Queenstown Hostel',
    city: 'Queenstown',
    address: '5-11 Church Street, 9300, Queenstown, New Zealand',
    phone: '+64 034413922',
    checkIn:  '2026-10-14', checkInTime:  '15:00', checkInWindow:  '15:00–23:00',
    checkOut: '2026-10-17', checkOutTime: '11:00',
    nights: 3, priceTWD: 9762, guests: 2, status: 'confirmed',
  },
]

// ── Rental Car ─────────────────────────────────────────────────────────────────
export const RENTAL_CARS = [
  {
    id: 'mazda-cx30',
    vehicle: 'Mazda CX-30 (or similar)',
    provider: 'Budget',
    specs: '5 人座 · 自排 · 無里程上限',
    pickupDate: '2026-10-10', pickupTime: '10:00',
    pickupCity: 'Christchurch Airport',
    pickupAddress: 'Christchurch Airport, Terminal Building, Christchurch 8053',
    pickupPhone: '+64 3 357 0231',
    dropoffDate: '2026-10-17', dropoffTime: '17:00',
    dropoffCity: 'Queenstown Airport',
    dropoffAddress: 'Sir Henry Wringley Drive, Frankton, Queenstown 9300',
    dropoffPhone: '+64 3 442 3450',
    priceTWD: 9326, people: 2, status: 'confirmed',
    note: 'Car only — insurance, fuel and parking NOT included',
  },
]

// ── Activities ─────────────────────────────────────────────────────────────────
// startTime: confirmed from booking screenshots. null = not provided.
// planB: 天氣取消時的替代方案（10 月天氣不穩，觀星 / 冰川 / 跳傘 / 峽灣都可能取消）
export const ACTIVITIES = [
  {
    id: 'stargazing',
    name: 'Mt John Observatory Guided Stargazing Experience',
    nameZh: '約翰山天文台觀星導覽',
    operator: 'Dark Sky Project',
    location: 'Lake Tekapo',
    date: '2026-10-11',
    startTime: '21:45',
    meetingPoint: 'Dark Sky Project, 1 Motuariki Lane, Lake Tekapo 7999',
    mapsQuery: 'Dark Sky Project 1 Motuariki Lane Lake Tekapo',
    planB: '隔天 10/12 早上 10:00 上 Mt John 山頂（車輛 NZ$14，10:00–16:00 開放），在 Astro Café 看湖景再出發；13:00 冰川要提早出發，蒂卡波 → 庫克山約 1.5 小時',
    meetNote: '請提前 15 分鐘抵達',
    language: '國語 (普通話)',
    priceTWD: 9029, people: 2, status: 'confirmed',
  },
  {
    id: 'glacier',
    name: 'Aoraki/Mt Cook: 3-Hour Tasman Glacier Heli Flight',
    nameZh: '塔斯曼冰川直升機飛行體驗（3 小時）',
    operator: 'Totally Tourism - The Helicopter Line',
    location: 'Aoraki / Mt Cook',
    date: '2026-10-12',
    startTime: '13:00',
    mapsQuery: 'The Helicopter Line Mt Cook Village New Zealand',
    planB: '改走 Tasman Glacier View 步道（來回 30 分，300 多階）＋ Tasman Lake 步道（來回 50 分，可看冰河湖）；都從 Tasman Valley Road 的 Blue Lakes 停車場出發',
    language: '英文導遊',
    priceTWD: 37580, people: 2, status: 'confirmed',
  },
  {
    id: 'skydive',
    name: 'NZONE Queenstown Skydive',
    nameZh: '皇后鎮 NZONE 高空跳傘',
    operator: 'NZONE Skydive',
    location: 'Queenstown',
    date: '2026-10-15',
    startTime: '08:00',
    mapsQuery: 'NZONE Skydive Queenstown New Zealand',
    planB: '向 NZONE 詢問改到 10/17 上午（17:00 才還車、19:45 起飛；10/16 米爾福德整天不行）',
    language: '國語導遊',
    ticketType: '2 x 15,000 英尺雙人跳傘',
    priceTWD: 21174, people: 2, status: 'confirmed',
  },
  {
    id: 'milford',
    name: 'Milford Sound Coach + Cruise from Queenstown',
    nameZh: '皇后鎮出發米爾福德峽灣巴士+遊船',
    operator: 'Pure Milford',
    location: 'Milford Sound',
    date: '2026-10-16',
    startTime: '07:15',           // 集合時間 (confirmed from booking)
    mapsQuery: 'Pure Milford Queenstown New Zealand',
    planB: '業者會通知取消；改玩皇后鎮：TSS Earnslaw 蒸汽船、Skyline 纜車＋Luge',
    startNote: '07:15 集合 · 實際接客時間可能不同，請向 Nomads Queenstown 確認',
    language: '英文導遊',
    priceTWD: 11013, people: 2, status: 'confirmed',
  },
]

// ── Helpers ────────────────────────────────────────────────────────────────────
export function getAccommodationForDate(date) {
  return ACCOMMODATIONS.find(a => a.checkIn <= date && date < a.checkOut) || null
}

export function getActivitiesForDate(date) {
  return ACTIVITIES.filter(a => a.date === date)
}

// ── Emergency & Service Contacts ───────────────────────────────────────────────
export const EMERGENCY_CONTACTS = [
  { id: 'nz-111',    label: '紐西蘭緊急救援',           number: '111',              note: '警察 · 救護 · 消防', type: 'emergency' },
  { id: 'teco-nz',   label: '駐紐西蘭台北辦事處急難',   number: '+64 27 449 5300',  note: '南島管轄 · 非緊急勿撥', type: 'embassy' },
  { id: 'mofa',      label: '旅外急難救助全球免付費',   number: '00-800-0885-0885', note: '24 小時', type: 'embassy' },
  { id: 'budget',    label: 'Budget 租車 NZ 免付費',    number: '0800 283 438',     note: 'CHC取車 +64 3 357 0231 · ZQN還車 +64 3 442 3450', type: 'service' },
  { id: 'fubon-sos',    label: '富邦 SOS 急難救援（旅途急用）', number: '0800-009-888', note: '24小時免付費 · 保單號 0026CT201M3637', type: 'service' },
  { id: 'fubon-service', label: '富邦產險客服（回台理賠用）',   number: '02-6636-7890',  note: '一般理賠/保單查詢', type: 'service' },
]
