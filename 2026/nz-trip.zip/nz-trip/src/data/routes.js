// ─── Road Book Data ────────────────────────────────────────────────────────────
// Single source of truth for road segments.
// coords: [[lat, lng], ...] — start to end, for map fly-to + polyline
// gmapsUrl: Google Maps 路線（地名格式 dir/A/B），DayModal 按鈕用
// stops: 順路停靠點（2026-10-07 查證地址與營業時間；參考「請問導遊高」10 月行程）
// metservice: 當天目的地的 MetService 官方預報頁（2026-10-07 查證；蒂卡波沒有獨立頁，用 Canterbury High Country）
//             有這個欄位的日子，DayModal 會顯示「出發前檢查」

// Overview 自動播放路線（新竹 → … → 新竹），mode 決定 icon（✈️/🚗）
export const FULL_ROUTE = [
  { pos: [24.8, 120.97],    mode: 'home',   label: '新竹' },
  { pos: [25.08, 121.23],   mode: 'drive',  label: '桃園機場' },
  { pos: [-37.81, 144.96],  mode: 'flight', label: '墨爾本' },
  { pos: [-43.53, 172.64],  mode: 'flight', label: '基督城' },
  { pos: [-44.01, 170.48],  mode: 'drive',  label: '蒂卡波' },
  { pos: [-43.6, 170.14],   mode: 'drive',  label: '庫克山' },
  { pos: [-44.7, 169.13],   mode: 'drive',  label: '瓦納卡' },
  { pos: [-45.03, 168.66],  mode: 'drive',  label: '皇后鎮' },
  { pos: [-27.47, 153.03],  mode: 'flight', label: '布里斯本' },
  { pos: [25.08, 121.23],   mode: 'flight', label: '桃園機場' },
  { pos: [24.8, 120.97],    mode: 'home',   label: '新竹（返抵）' },
]

export const ROUTE_SEGMENTS = [
  {
    day: 1, date: '2026-10-09', type: 'flight',
    fromZh: '新竹 / 台北', toZh: '基督城',
    coords: [[24.8, 120.97], [25.08, 121.23], [-37.81, 144.96], [-43.53, 172.64]],
    driving: false,
    flights: [
      { code: 'CI057', fromZh: '台北桃園', toZh: '墨爾本', dep: '10/08 23:30', arr: '10/09 11:40', note: '墨爾本候機 ~7h' },
      { code: 'QF169', fromZh: '墨爾本',   toZh: '基督城', dep: '10/09 18:40', arr: '10/10 00:10' },
    ],
  },
  {
    day: 2, date: '2026-10-10',
    metservice: { label: 'Christchurch 基督城', url: 'https://www.metservice.com/towns-cities/regions/christchurch/locations/christchurch' },
    from: 'Christchurch', fromZh: '基督城',
    to: 'Christchurch',   toZh:   '基督城',
    driving: false,
    coords: [[-43.5321, 172.6362]],
    note: '取車日，市區自由探索',
  },
  {
    day: 3,
    stops: [
      { icon: '🥧', name: 'Fairlie Bakehouse', when: '午餐', what: '南島有名的手工鹹派，順路吃午餐',
        info: '74 Main Street, Fairlie · 每天 7:30–16:30', mapsQuery: 'Fairlie Bakehouse 74 Main Street Fairlie' },
      { icon: '⛪', name: 'Church of the Good Shepherd', when: '傍晚', what: '蒂卡波湖畔的石造教堂，觀星前去拍照',
        info: '園區 9:00 起開放（夏季到 20:00）· 室內禁止拍照 · 建議捐 NZ$5', mapsQuery: 'Church of the Good Shepherd Lake Tekapo' },
    ],
    metservice: { label: 'Canterbury High Country（蒂卡波一帶）', url: 'https://www.metservice.com/mountains-and-parks/national-parks/canterbury-high-country' },
    gmapsUrl: 'https://www.google.com/maps/dir/Christchurch+New+Zealand/Lake+Tekapo+New+Zealand',
    date: '2026-10-11',
    from: 'Christchurch', fromZh: '基督城',
    to: 'Lake Tekapo',    toZh:   '蒂卡波湖',
    driving: true,
    coords: [[-43.5321, 172.6362], [-44.0053, 170.4778]],
    km: 225, hours: 2.5,
    highway: 'SH1 → SH79 → SH8',
  },
  {
    day: 4,
    stops: [
      { icon: '🐟', name: 'Mt Cook Alpine Salmon ＋ Lake Pukaki', when: '途中', what: '高山鮭魚店，買生魚片在湖邊配庫克山吃',
        info: 'SH8 Pūkaki Information Centre · 每天營業', mapsQuery: 'Mt Cook Alpine Salmon Lake Pukaki' },
      { icon: '📸', name: "Peter's Lookout", when: '途中', what: 'SH80 上看 Pukaki 湖＋庫克山的經典拍照點',
        info: '13:00 冰川要準時，停靠抓好時間', mapsQuery: "Peter's Lookout Lake Pukaki" },
    ],
    metservice: { label: 'Mount Cook 庫克山', url: 'https://www.metservice.com/towns-cities/regions/canterbury-high-country/locations/mount-cook' },
    gmapsUrl: 'https://www.google.com/maps/dir/Lake+Tekapo+New+Zealand/Aoraki+Mount+Cook+Village+New+Zealand',
    date: '2026-10-12',
    from: 'Lake Tekapo',       fromZh: '蒂卡波湖',
    to: 'Aoraki / Mt Cook',   toZh:   '奧拉基/庫克山',
    driving: true,
    coords: [[-44.0053, 170.4778], [-43.7357, 170.0964]],
    km: 105, hours: 1.5,
    highway: 'SH8 → SH80',
    warning: 'SH80 後段為碎石路面，限速 50km/h，注意 10 月可能有積雪',
  },
  {
    day: 5,
    stops: [
      { icon: '🐑', name: 'The Wrinkly Rams', when: '午餐', what: 'Ōmarama 的牧場咖啡廳，鹹派＋羊毛製品',
        info: '10 Twizel-Omarama Road, Ōmarama · 7:00–16:00（夏季 6:30–16:30）', mapsQuery: 'The Wrinkly Rams Omarama' },
      { icon: '⛰️', name: 'Lindis Pass', when: '途中', what: 'SH8 最高點，像汽車廣告的山景公路，找路邊停車點拍照',
        info: 'SH8 · Ōmarama → Tarras 之間', mapsQuery: 'Lindis Pass Summit' },
      { icon: '🌳', name: 'That Wanaka Tree', when: '傍晚', what: '瓦納卡湖裡的孤獨的樹，傍晚光線最好',
        info: 'Roys Bay, Wanaka', mapsQuery: 'That Wanaka Tree' },
    ],
    metservice: { label: 'Wānaka 瓦納卡', url: 'https://www.metservice.com/towns-cities/regions/southern-lakes/locations/wanaka' },
    gmapsUrl: 'https://www.google.com/maps/dir/Aoraki+Mount+Cook+Village+New+Zealand/Wanaka+New+Zealand',
    date: '2026-10-13',
    from: 'Aoraki / Mt Cook', fromZh: '奧拉基/庫克山',
    to: 'Wanaka',              toZh:   '瓦納卡',
    driving: true,
    coords: [[-43.7357, 170.0964], [-44.7031, 169.1317]],
    km: 260, hours: 3.5,
    highway: 'SH80 → SH8 → SH6',
  },
  {
    day: 6,
    stops: [
      { icon: '🍺', name: 'Cardrona Hotel', when: '出發約 30 分', what: '1863 年淘金時期的驛站酒館，號稱紐西蘭最常被拍的老酒吧，全天供應酒吧餐點',
        info: 'Cardrona Valley Road 路邊 · 拍照免費', mapsQuery: 'Cardrona Hotel Cardrona New Zealand' },
      { icon: '⛰️', name: 'Crown Range Summit / Arrow Junction Lookout', when: 'Cardrona 後 15–25 分', what: '山頂觀景台停一下；下山的之字彎觀景點（Arrow Junction Lookout）可以俯瞰整個皇后鎮盆地',
        info: '路邊停車場 · 山頂風大很冷，外套帶下車', mapsQuery: 'Crown Range Summit Lookout' },
      { icon: '🏚️', name: 'Arrowtown', when: '下山後繞 6 分', what: '淘金小鎮：Buckingham Street 老街 60 多棟原始建築；河邊華人淘金村遺址免費參觀',
        info: 'Arrow Junction 轉入 · 逛 1 小時左右', mapsQuery: 'Arrowtown Chinese Settlement' },
      { icon: '🍦', name: 'Patagonia Chocolates', when: '晚上', what: '皇后鎮人氣冰淇淋＋巧克力，二樓看湖景',
        info: '2 Rees Street（Mall 轉角）· 每天 9:00–22:00', mapsQuery: 'Patagonia Chocolates 2 Rees Street Queenstown' },
    ],
    metservice: { label: 'Queenstown 皇后鎮', url: 'https://www.metservice.com/towns-cities/regions/southern-lakes/locations/queenstown' },
    // 2026-10-07 查證：67 km 是 Crown Range（約 68 km / 1h10m），SH6 經 Cromwell 是 113 km / 約 1.5h
    gmapsUrl: 'https://www.google.com/maps/dir/Wanaka+New+Zealand/Cardrona+Hotel+New+Zealand/Queenstown+New+Zealand',
    date: '2026-10-14',
    from: 'Wanaka',      fromZh: '瓦納卡',
    to: 'Queenstown',    toZh:   '皇后鎮',
    driving: true,
    coords: [[-44.7031, 169.1317], [-45.0312, 168.6626]],
    km: 68, hours: 1.2,
    highway: 'Crown Range Road（經 Cardrona）',
    warning: 'Crown Range 海拔約 1,100m、髮夾彎多；出發前看路況，下雪結冰就改走 SH6 經 Cromwell（113 km · 約 1.5h）',
  },
  {
    day: 7, date: '2026-10-15',
    from: 'Queenstown', fromZh: '皇后鎮',
    to: 'Queenstown',   toZh:   '皇后鎮',
    driving: false,
    coords: [[-45.0312, 168.6626]],
    note: 'NZONE 高空跳傘，基地在市區',
  },
  {
    day: 8,
    gmapsUrl: 'https://www.google.com/maps/dir/Queenstown+New+Zealand/Milford+Sound+New+Zealand',
    date: '2026-10-16',
    from: 'Queenstown',  fromZh: '皇后鎮',
    to: 'Milford Sound', toZh:   '米爾福德峽灣',
    driving: false,
    coords: [[-45.0312, 168.6626], [-44.6413, 167.8978]],
    km: 290, hours: 4,
    highway: 'SH6 → SH94',
    note: '巴士接送（07:15 集合），不需自駕',
  },
  {
    day: 9,
    stops: [
      { icon: '🦌', name: 'Deer Park Heights', when: '上午（還車前）', what: '自駕 5 公里的鹿園，可以餵動物、看瓦卡蒂普盆地',
        info: '432 Peninsula Road, Frankton（離機場 5 分鐘）· 白天開放 · NZ$75 / 車，需先上網預約拿閘門密碼 · 餵飼料要 NZ$2 硬幣',
        mapsQuery: 'Deer Park Heights 432 Peninsula Road Frankton' },
    ],
    metservice: { label: 'Queenstown 皇后鎮', url: 'https://www.metservice.com/towns-cities/regions/southern-lakes/locations/queenstown' },
    gmapsUrl: 'https://www.google.com/maps/dir/Queenstown+New+Zealand/Queenstown+Airport+New+Zealand',
    date: '2026-10-17',
    from: 'Queenstown',    fromZh: '皇后鎮',
    to: 'ZQN Airport',     toZh:   '皇后鎮機場',
    driving: true,
    coords: [[-45.0312, 168.6626], [-45.021, 168.7393]],
    km: 8, hours: 0.2,
    highway: '市區→機場',
    note: '17:00 還車，19:45 QF186 出發',
  },
  {
    day: 10, date: '2026-10-18', type: 'flight',
    fromZh: '皇后鎮', toZh: '新竹（返抵）',
    coords: [[-45.03, 168.66], [-27.47, 153.03], [25.08, 121.23], [24.8, 120.97]],
    driving: false,
    flights: [
      { code: 'QF186', fromZh: '皇后鎮',   toZh: '布里斯本', dep: '10/17 19:45', arr: '10/17 20:35', note: '布里斯本候機 ~2h' },
      { code: 'CI054', fromZh: '布里斯本', toZh: '台北桃園', dep: '10/17 22:50', arr: '10/18 05:40' },
    ],
  },
]

// 當天順路停靠點（ROUTE_SEGMENTS.stops），沒有就回傳 []
export function getStopsForDate(date) {
  return ROUTE_SEGMENTS.find(s => s.date === date)?.stops || []
}

export function getSegmentForDay(day) {
  return ROUTE_SEGMENTS.find(s => s.day === day) || null
}

// WMO weather code → icon + description
export function wmoToDesc(code) {
  if (code === 0)  return { icon: '☀️', text: '晴天' }
  if (code <= 3)   return { icon: '⛅', text: '多雲' }
  if (code <= 49)  return { icon: '🌫', text: '有霧' }
  if (code <= 69)  return { icon: '🌧', text: '降雨' }
  if (code <= 79)  return { icon: '❄️', text: '降雪' }
  if (code <= 84)  return { icon: '🌦', text: '陣雨' }
  if (code <= 95)  return { icon: '⛈', text: '雷雨' }
  return           { icon: '⛈', text: '強雷雨' }
}

// Weather-based warnings
export function getWeatherWarnings(w) {
  const warns = []
  if ((w.snow ?? 0) > 0)    warns.push(`❄️ 積雪 ${w.snow}cm，注意路面`)
  if ((w.wind ?? 0) > 50)   warns.push(`💨 強風 ${w.wind}km/h`)
  if ((w.precip ?? 0) > 20) warns.push(`🌧 大雨 ${w.precip}mm`)
  return warns
}
