// ─── 紫外線 / 防曬（規則與 nz-trip-test.html E 組 mock 一致）──────────────────────
// WHO 紫外線分級（四捨五入）；SunSmart NZ：UV 3 以上要防曬（Slip, Slop, Slap & Wrap）
// 雪地：新雪最多反射 80% UV、海拔每 1,000 m UV +10–12%（Cancer Council 雪地防曬指南）→ 冰川日加一級

export const UV_LEVELS = ['low', 'moderate', 'high', 'veryHigh', 'extreme']

export const UV_META = {
  low:      { zh: '低',   color: '#4A9B6F', steps: ['不用特別防曬'] },
  moderate: { zh: '中',   color: '#C4952A', steps: ['SPF30+ 出門前擦', '帽子', '墨鏡'] },
  high:     { zh: '高',   color: '#D9822B', steps: ['SPF30+ 出門前擦', '每 2 小時補擦', '帽子＋墨鏡', '中午盡量找遮蔭'] },
  veryHigh: { zh: '很高', color: '#C0392B', steps: ['SPF30+ 每 2 小時補擦', '帽子＋墨鏡', 'SPF 護唇膏', '遮住脖子和耳朵', '中午找遮蔭'] },
  extreme:  { zh: '極高', color: '#8E44AD', steps: ['SPF30+ 每 2 小時補擦', '帽子＋墨鏡', 'SPF 護唇膏', '穿長袖遮脖子耳朵', '減少中午曝曬'] },
}

export const SNOW_EXTRA = ['雪地反射：下巴、鼻子下方、耳朵也要擦', '墨鏡全程戴著']

export function uvLevel(uv) {
  const u = Math.round(uv)
  return u >= 11 ? 'extreme' : u >= 8 ? 'veryHigh' : u >= 6 ? 'high' : u >= 3 ? 'moderate' : 'low'
}

export function sunLevel(uv, snow = false) {
  const i = UV_LEVELS.indexOf(uvLevel(uv))
  return UV_LEVELS[Math.min(i + (snow ? 1 : 0), UV_LEVELS.length - 1)]
}

// hourly: [{ time: 'YYYY-MM-DDTHH:00', uv }]（當地時間）→ 'HH:00–HH:00' 或 null
export function sunWindow(hourly, date) {
  const hrs = hourly.filter(h => h.time.startsWith(date) && h.uv >= 3).map(h => Number(h.time.slice(11, 13)))
  if (!hrs.length) return null
  const pad = n => String(n).padStart(2, '0')
  return `${pad(Math.min(...hrs))}:00–${pad(Math.max(...hrs) + 1)}:00`
}

// 穿搭卡用：{ level, zh, color, steps, window }
export function sunAdvice(weather, snow = false) {
  if (weather?.uv == null) return null
  const level = sunLevel(weather.uv, snow)
  const meta = UV_META[level]
  return {
    level, zh: meta.zh, color: meta.color,
    steps: snow ? [...meta.steps, ...SNOW_EXTRA] : meta.steps,
    window: weather.uvHourly ? sunWindow(weather.uvHourly, weather.date) : null,
  }
}
