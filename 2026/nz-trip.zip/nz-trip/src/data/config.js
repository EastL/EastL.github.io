// ─── Trip Identity ─────────────────────────────────────────────────────────────
export const TRIP = {
  name:      '東東兄弟出走中',
  nameEn:    'New Zealand · 2026',
  subtitle:  'South Island Road Trip',
  statusLabels: {
    before: '東東兄弟準備出走',
    during: '東東兄弟出走中',
    after:  '東東兄弟出走完畢',
  },
  travelers:  ['東岳', '東振'],
  startDate:  '2026-10-09',   // NZ display date (website hero)
  endDate:    '2026-10-18',
  totalDays:  10,
  timezone:   'Pacific/Auckland',
}

// ─── Expense PIN ────────────────────────────────────────────────────────────────
export const EXPENSE_PIN = '2610'

// Google Apps Script URL — 設定好後貼上，空字串 = 僅使用本地
export const GSHEET_URL = 'https://script.google.com/macros/s/AKfycby77tqTUtsjUFWwnrySQy2alukzZGuL3P8fBIzlmY1lHK5U4YAmWTGhp8aSZKHCCIeK/exec'

// ─── Currencies ─────────────────────────────────────────────────────────────────
// NOTE: No automatic exchange rate. USD and TWD are kept SEPARATE.
// Never add USD amounts directly to TWD totals.
export const CURRENCIES = {
  TWD: { symbol: 'NT$', label: '新台幣' },
  USD: { symbol: 'US$', label: '美元'   },
  NZD: { symbol: 'NZ$', label: '紐西蘭元' },
}

// NZD→TWD approximate rate — ONLY for user-added on-trip NZD spending.
// NOT applied to pre-confirmed TWD accommodation/activity prices.
export const NZD_TO_TWD_RATE = 19.5

// ─── Expense Categories ────────────────────────────────────────────────────────
export const EXPENSE_CATEGORIES = [
  { id: 'accommodation', label: '住宿',    labelEn: 'Accommodation', color: '#173D2A' },
  { id: 'activity',      label: '活動',    labelEn: 'Activities',    color: '#C4952A' },
  { id: 'food',          label: '餐飲',    labelEn: 'Food',          color: '#9A7A2A' },
  { id: 'transport',     label: '交通',    labelEn: 'Transport',     color: '#5A6E62' },
  { id: 'shopping',      label: '購物',    labelEn: 'Shopping',      color: '#6B7C72' },
  { id: 'other',         label: '其他',    labelEn: 'Other',         color: '#B8B0A0' },
]
