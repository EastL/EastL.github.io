// 今晚極光：NOAA Kp 3 天預報 ＋ Open-Meteo 夜間雲量
// 資料：https://services.swpc.noaa.gov/products/noaa-planetary-k-index-forecast.json（每 3 小時一筆，UTC）
// 門檻（粗估，紐西蘭南島看南方地平線）：Kp ≥ 5（G1 地磁風暴）相機有機會拍到；Kp ≥ 7 肉眼可能看到
// 雲是最大變數：夜間平均雲量 ≥ 70% → 判定被雲擋住

export const KP_URL = 'https://services.swpc.noaa.gov/products/noaa-planetary-k-index-forecast.json'
export const TASSIE_AURORA_URL = 'https://apps.apple.com/app/id1586329995'
export const NOAA_AURORA_URL = 'https://www.swpc.noaa.gov/products/aurora-30-minute-forecast'

export const AURORA_META = {
  low:    { zh: '機會低',     color: '#8A8A8A' },
  chance: { zh: '有機會',     color: '#B7791F' },
  high:   { zh: '機會高',     color: '#6B46C1' },
  cloudy: { zh: '被雲擋住',   color: '#5A6B7A' },
}

// NOAA 舊格式：[[表頭...], [值...]]；新格式：[{ time_tag, kp, ... }]，兩種都吃
export function parseKp(json) {
  if (!Array.isArray(json) || !json.length) return []
  let rows = json
  if (Array.isArray(json[0])) {
    const head = json[0].map(h => String(h).toLowerCase())
    rows = json.slice(1).map(r => Object.fromEntries(head.map((h, i) => [h, r[i]])))
  }
  return rows.map(r => {
    const tag = String(r.time_tag ?? r.time ?? '')
    const iso = tag.replace(' ', 'T')
    const t = Date.parse(/Z|[+-]\d\d:?\d\d$/.test(iso) ? iso : iso + 'Z')
    const kp = Number(r.kp ?? r.Kp ?? r.kp_index)
    return { t, kp }
  }).filter(r => Number.isFinite(r.t) && Number.isFinite(r.kp))
}

// 紐西蘭當地時間 → UTC 毫秒（自動處理夏令時間；hour 可以 > 24 代表隔天）
const NZ_FMT = new Intl.DateTimeFormat('en-US', {
  timeZone: 'Pacific/Auckland', hourCycle: 'h23',
  year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric',
})
function nzWallMs(ts) {
  const p = Object.fromEntries(NZ_FMT.formatToParts(new Date(ts)).map(x => [x.type, x.value]))
  return Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute)
}
export function nzLocalToUtc(date, hour) {
  const [y, m, d] = date.split('-').map(Number)
  const want = Date.UTC(y, m - 1, d, hour)
  let ts = want - 13 * 3600e3
  ts += want - nzWallMs(ts)
  return ts
}

// 今晚 = 當天 20:00 ～ 隔天 03:00（NZ 時間）；Kp 每筆涵蓋 3 小時，只要有重疊就算
export function tonightKp(entries, date) {
  const start = nzLocalToUtc(date, 20)
  const end = nzLocalToUtc(date, 27)
  const hit = entries.filter(e => e.t + 3 * 3600e3 > start && e.t < end)
  return hit.length ? Math.max(...hit.map(e => e.kp)) : null
}

function nextDate(date) {
  const [y, m, d] = date.split('-').map(Number)
  return new Date(Date.UTC(y, m - 1, d + 1)).toISOString().slice(0, 10)
}

// Open-Meteo hourly（timezone=auto，時間是當地時間 'YYYY-MM-DDTHH:MM'）→ 今晚平均雲量 %
export function tonightCloud(hourly, date) {
  if (!hourly?.length) return null
  const nd = nextDate(date)
  const vals = hourly.filter(h => {
    const hh = Number(h.time.slice(11, 13))
    return (h.time.startsWith(date) && hh >= 20) || (h.time.startsWith(nd) && hh < 3)
  }).map(h => h.cloud).filter(v => v != null)
  return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : null
}

export function auroraLevel(kp, cloud) {
  if (kp == null) return null
  const base = kp >= 7 ? 'high' : kp >= 5 ? 'chance' : 'low'
  if (base !== 'low' && cloud != null && cloud >= 70) return 'cloudy'
  return base
}

// Kp 5 = G1 … Kp 9 = G5（NOAA 地磁風暴分級）
export function gScale(kp) {
  return kp >= 5 ? `G${Math.min(5, Math.floor(kp) - 4)}` : null
}
