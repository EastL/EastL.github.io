// ─── 每日穿搭 / 行李（唯一資料源）──────────────────────────────────────────────
// Today 穿搭卡、行程頁一行摘要、穿搭總覽都讀這份；改一次三處同步。
// 內容來自東岳的穿搭規劃（2026-10-06），規則見 nz-trip-test.html E 組。
//
// layers：今天「穿上」的洋蔥層（null = 不穿）
// carry ：今天「帶著備用」的層（放隨身 / 放車上），配合 carryNote 說明
// night ：一天兩段的日子，NZ 時間 from 之後改顯示這套（覆蓋同名欄位）

// ── 洋蔥 4 層 ──────────────────────────────────────────────────────────────────
export const LAYER_KEYS = ['base', 'mid', 'insulation', 'shell']

export const LAYER_META = {
  base:       { icon: '👕', en: 'Base Layer', short: 'Base',  zh: '排汗 / 保暖長袖、短袖' },
  mid:        { icon: '🧥', en: 'Mid Layer',  short: 'Mid',   zh: 'Fleece / 帽T' },
  insulation: { icon: '🪶', en: 'Insulation', short: '保暖', zh: '輕羽絨' },
  shell:      { icon: '🌧️', en: 'Shell',      short: 'Shell', zh: '防風防水外套' },
}

// ── 4 級簡化規則（天氣 icon 只用在這裡和每日主題）──────────────────────────────
export const LEVELS = {
  warm: { icon: '☀️', zh: '暖',   rule: '短袖' },
  cool: { icon: '🌥️', zh: '涼',   rule: '短袖 / 薄長袖 + Fleece' },
  cold: { icon: '🥶', zh: '冷',   rule: '保暖長袖 + Fleece + 輕羽絨' },
  wet:  { icon: '🌧️', zh: '風雨', rule: '需要的保暖層 + 防風防水外套' },
}

// ── Christchurch 採購 & 行李策略 ───────────────────────────────────────────────
// 2026-10-06 查證：Macpac 官網、The Crossing 官網、Dress-Smart 官網；Barkers 為旅遊指南資料（與 The Crossing 週末時間一致）
// 10/10 是星期六
export const SHOPPING = {
  date: '2026-10-10',
  city: 'Christchurch',
  plan: ['Macpac Fleece / Mid-layer ×1', 'Huffer 或 Barkers 上衣 ×1'],
  // 紐西蘭要買的件數（70/30 的 30%），總覽最上方與店家卡都讀這份
  buyList: [
    { item: 'Fleece / Mid-layer', qty: 1, where: 'Macpac', note: '最優先，買完直接穿' },
    { item: '上衣', qty: 1, where: 'Huffer 或 Barkers 二選一', note: 'T-shirt / Sweatshirt / Smart Casual，當紀念服裝' },
  ],
  route: 'Barkers（The Crossing）→ Macpac → Huffer',
  slot: '13:15–14:45，午餐後步行',
  parking: {
    name: 'The Crossing 停車場',
    address: '71 Lichfield Street, Christchurch Central City',
    mapsQuery: 'The Crossing carpark 71 Lichfield Street Christchurch',
    note: '週末全日 NZ$9 · 跟 Riverside Market 同一條 Lichfield St，午餐＋採買停一次就好',
  },
  stores: [
    {
      name: 'Barkers', place: 'The Crossing',
      address: '690 Colombo Street, Christchurch Central City',
      mapsQuery: 'Barkers The Crossing 690 Colombo Street Christchurch',
      buy: '男裝、T-shirt、Smart Casual、日常拍照穿搭',
      buyQty: '上衣 ×1（與 Huffer 二選一）',
      hoursSat: '10:00–17:00',
    },
    {
      name: 'Macpac', place: 'Colombo Street', priority: true,
      address: 'Unit 6/692 Colombo Street, Christchurch Central City',
      mapsQuery: 'Macpac Colombo Street 692 Colombo Street Christchurch',
      buy: 'Fleece、Mid-layer、戶外機能服',
      buyQty: 'Fleece / Mid-layer ×1',
      hoursSat: '10:00–17:00',
      note: '這趟最優先，就在 Barkers 旁邊',
    },
    {
      name: 'Huffer', place: 'High Street',
      address: '236 High Street, Christchurch Central City',
      mapsQuery: 'Huffer 236 High Street Christchurch',
      buy: 'T-shirt、Sweatshirt、Hoodie、紐西蘭 Streetwear',
      buyQty: '上衣 ×1（與 Barkers 二選一）',
      hoursSat: null,   // 官網未公開，查不到
      note: '買一件當紀念服裝，Wanaka / Queenstown 直接穿',
    },
  ],
  backup: {
    name: 'Dress-Smart Christchurch', place: 'Hornby（Outlet）',
    address: '409 Main South Road, Hornby',
    mapsQuery: 'Dress-Smart Christchurch 409 Main South Road Hornby',
    hoursSat: '10:00–18:00',
    brands: 'Huffer、Barkers、Icebreaker、Kathmandu、Mons Royale、Swanndri、Merrell、adidas、New Balance 等',
    note: '不在 CBD；只買 1 件 Fleece＋1 件上衣的話不用特地跑',
  },
  note: '買完旅程可以直接穿，也是旅行紀念品',
}

export const PACKING_STRATEGY = [
  '台灣帶 70%（出發前準備 → 衣物 17 項）＋ 紐西蘭買 30%（2 件，見上方清單）',
  '行李箱至少預留約 1/3 空間',
  '不要從台灣把 10 天所有衣服塞滿',
]

// ── 每日穿搭 ───────────────────────────────────────────────────────────────────
export const OUTFITS = [
  {
    date: '2026-10-09', day: 1, theme: 'FLIGHT DAY', icon: '✈️', level: 'cool',
    place: '台灣 → Melbourne → Christchurch',
    layers: { base: '短袖', mid: '帽T / 薄外套', insulation: null, shell: null },
    bottom: '舒服長褲', shoes: '球鞋',
    carry: ['insulation'], carryNote: '輕羽絨放隨身行李，不要托運，飛機冷時直接拿出來穿',
  },
  {
    date: '2026-10-10', day: 2, theme: 'CITY & SHOPPING', icon: '🛍️', level: 'cool',
    place: 'Christchurch',
    layers: { base: '短袖', mid: 'Fleece / 帽T', insulation: null, shell: null },
    bottom: '長褲', shoes: '球鞋',
    shop: true,
  },
  {
    date: '2026-10-11', day: 3, theme: 'STARGAZING NIGHT', icon: '🌌', level: 'cool',
    place: 'Christchurch → Lake Tekapo', session: '白天',
    layers: { base: '短袖 / 薄長袖', mid: 'Fleece', insulation: null, shell: '防風外套' },
    bottom: '長褲',
    carryNote: '晚上 21:45 觀星要全套保暖，18:00 後這張卡會自動切換',
    night: {
      from: '18:00', session: '21:45 Mt John 觀星', level: 'cold',
      layers: { base: '保暖長袖', mid: 'Fleece', insulation: '輕羽絨', shell: '防風外套' },
      bottom: '長褲', extras: ['厚襪', '毛帽', '薄手套'],
      carryNote: null,
      note: '這可能是整趟第一次需要完整保暖層的晚上',
    },
  },
  {
    date: '2026-10-12', day: 4, theme: 'GLACIER DAY', icon: '❄️', level: 'cold',
    snow: true,   // 冰川：雪地反射＋海拔 → 防曬加一級
    place: 'Tekapo → Mt Cook · Tasman Glacier',
    layers: { base: '排汗 / 保暖長袖', mid: 'Fleece', insulation: null, shell: '防風防水外套' },
    bottom: '機能長褲', extras: ['厚襪', '墨鏡'],
    carry: ['insulation'], carryNote: '輕羽絨帶著備用',
    avoid: [{ item: '牛仔褲', reason: '濕掉後保暖與舒適性都很差' }],
    laundry: '洗衣備案：內褲 / 襪子只帶 5 件、或冰川弄濕的話，今晚在 Haka House 洗（有洗衣設備，用烘衣機）',
    note: '實際冰川活動依業者提供的裝備與當天天氣調整',
  },
  {
    date: '2026-10-13', day: 5, theme: 'ROAD DAY', icon: '🚗', level: 'cool',
    place: 'Mt Cook → Wanaka',
    layers: { base: '短袖 / 薄長袖', mid: 'Fleece', insulation: null, shell: null },
    bottom: '長褲', shoes: '好走的鞋',
    carry: ['insulation', 'shell'], carryNote: '輕羽絨與防風外套放車上，氣溫降低時再加',
  },
  {
    date: '2026-10-14', day: 6, theme: 'TOWN DAY', icon: '📸', level: 'cool',
    place: 'Wanaka → Queenstown',
    layers: { base: '短袖', mid: 'Fleece / 基督城買的新衣', insulation: null, shell: null },
    bottom: '長褲', shoes: '球鞋',
    note: '可以偏日常 / 拍照穿搭，不需要全部都是戶外機能服',
    laundry: '今晚洗衣：Nomads 自助洗衣，用烘衣機（明早 08:00 跳傘）· 洗完撐到回台灣',
  },
  {
    date: '2026-10-15', day: 7, theme: 'SKYDIVE DAY', icon: '🪂', level: 'cool',
    place: 'Queenstown · NZONE 15,000 ft',
    layers: { base: '短袖 / 薄長袖', mid: null, insulation: null, shell: null },
    bottom: '好活動的長褲', shoes: '球鞋（要穩固）',
    tips: ['不需要穿得過度厚重', '褲子要方便活動', '鞋子要穩固'],
    note: '實際跳傘依 NZONE 提供的裝備與當天天氣調整；跳完可換回一般 Queenstown 穿搭',
  },
  {
    date: '2026-10-16', day: 8, theme: 'FIORD DAY', icon: '🌧️', level: 'wet',
    place: 'Milford Sound · Coach + Cruise',
    layers: { base: '短袖 / 薄長袖', mid: 'Fleece', insulation: null, shell: '防水防風外套' },
    bottom: '長褲', shoes: '好走、最好有防水能力的鞋',
    note: '「防水」比單純穿很厚更重要：天氣變化快，船上有風、水氣和瀑布',
  },
  {
    date: '2026-10-17', day: 9, theme: 'TRAVEL DAY', icon: '🧳', level: 'cool',
    place: 'Queenstown → Brisbane',
    layers: { base: '短袖', mid: 'Fleece / 帽T', insulation: null, shell: null },
    bottom: '舒服長褲', shoes: '球鞋',
    carry: ['insulation'], carryNote: '輕羽絨放隨身行李；到較溫暖的 Brisbane 後逐層脫掉',
  },
  {
    date: '2026-10-18', day: 10, theme: 'HOME DAY', icon: '🏠', level: 'warm',
    place: 'Brisbane → 台灣',
    layers: { base: '短袖', mid: null, insulation: null, shell: null },
    bottom: '舒服長褲', shoes: '球鞋',
    note: '以搭機舒適為主',
  },
]

// ── 規則（與 nz-trip-test.html E 組 mock 函式一致）─────────────────────────────

export function getOutfitForDate(date) {
  return OUTFITS.find(o => o.date === date) || null
}

// 洋蔥層數條：每層 'wear' 穿上 / 'carry' 帶著備用 / 'none'
export function layerBar(o) {
  return LAYER_KEYS.map(k => (o.layers[k] ? 'wear' : (o.carry || []).includes(k) ? 'carry' : 'none'))
}

// 一天兩段：hhmm（NZ 時間 'HH:MM'）到了 night.from 就換晚上那套
export function pickSession(o, hhmm) {
  return o.night && hhmm >= o.night.from ? { ...o, ...o.night } : o
}

// 天氣連動：w = { tmin, tmax, precip, snow, wind }（Open-Meteo 當日預報）
export const WEATHER_RULES = { coldMin: 5, rainMm: 5, windKmh: 40, warmMax: 20 }

export function weatherAdvice(o, w) {
  const R = WEATHER_RULES
  const tips = []
  if (w.tmin != null && w.tmin < R.coldMin && !o.layers.insulation)
    tips.push(`🥶 預報最低 ${Math.round(w.tmin)}°C，輕羽絨直接穿上`)
  if (((w.precip ?? 0) >= R.rainMm || (w.snow ?? 0) > 0) && !o.layers.shell)
    tips.push('🌧️ 預報有雨雪，穿上防風防水外套')
  else if ((w.wind ?? 0) > R.windKmh && !o.layers.shell)
    tips.push(`🌬️ 預報強風 ${Math.round(w.wind)}km/h，加上防風外套`)
  if (w.tmax != null && w.tmax >= R.warmMax) tips.push(`☀️ 白天最高 ${Math.round(w.tmax)}°C，熱了可以脫到短袖`)
  return tips
}

// 行程頁一行摘要：例「❄️ 3 層＋保暖備用 · ⚠️ 不要牛仔褲」
export function outfitSummary(o) {
  const bar = layerBar(o)
  const wear = bar.filter(s => s === 'wear').length
  const carry = bar.filter(s => s === 'carry').length
  let s = `${o.icon} ${wear} 層${carry ? `＋${carry} 層備用` : ''}`
  if (o.night) s += ' · 🌌 晚上加到全套'
  if (o.avoid?.length) s += ` · ⚠️ 不要${o.avoid.map(a => a.item).join('、')}`
  if (o.shop) s += ' · 🛍 買衣服日'
  if (o.laundry && !o.laundry.startsWith('洗衣備案')) s += ' · 🧺 洗衣日'
  return s
}
