// ─── Itinerary ─────────────────────────────────────────────────────────────────
// All times sourced from confirmed bookings. No invented times.
// status: 'confirmed' | 'planned'

import { getAccommodationForDate, getActivitiesForDate, RENTAL_CARS } from './trip.js'

const CAR = RENTAL_CARS[0]

function activityItems(date) {
  return getActivitiesForDate(date).map(a => ({
    time:       a.startTime || '',
    activity:   a.name,
    note:       a.startNote || (a.startTime ? '' : '確切時間待確認'),
    status:     a.status,
    activityId: a.id,
  }))
}

export const itinerary = [

  // ── Day 1 · Oct 09 · Melbourne Transit ──────────────────────────────────────
  {
    day: 1, date: '2026-10-09',
    location: { en: 'Melbourne (Transit)', zh: '墨爾本中轉' },
    region: 'Australia',
    title: 'Transit via Melbourne',
    titleZh: '墨爾本中轉',
    schedule: [
      { time: '11:40', activity: 'CI057 抵達墨爾本 (MEL)', note: '', status: 'confirmed' },
      { time: '12:30', activity: '入境 + 領行李 + QF169 托運', note: '行李須重掛，目標 13:30 前完成 · 入境卡勾選申報保健品 / 零食 / 鞋子', status: 'planned' },
      { time: '13:30', activity: '⏱ GO / NO-GO 判斷點', note: '完成 → 出發市區，未完成 → 留機場', status: 'planned' },
      { time: '14:xx', activity: '市區任務 或 機場候機', note: '詳見 Melbourne Transit Mission', status: 'planned' },
      { time: '15:30', activity: '最晚回機場（Hard Deadline）', note: '', status: 'planned' },
      { time: '18:40', activity: 'QF169 出發 → 基督城', note: '', status: 'confirmed' },
    ],
    accommodation: null,
    note: '分開購票，行李在 MEL 須自行重掛 QF169。',
    photos: [], quote: '',
  },

  // ── Day 2 · Oct 10 · Arrive Christchurch ────────────────────────────────────
  {
    day: 2, date: '2026-10-10',
    location: { en: 'Christchurch', zh: '基督城' },
    region: 'South Island',
    title: 'Arrive Christchurch',
    titleZh: '抵達基督城',
    schedule: [
      { time: '00:10', activity: 'QF169 抵達基督城 (CHC)', note: 'Christchurch International Airport · 入境卡勾選申報保健品 / 零食 / 鞋子（NZTD 已填的照實申報），飛機餐不要帶下機', status: 'confirmed' },
      { time: `${CAR.pickupTime}`, activity: `取車 · ${CAR.vehicle}`, note: `${CAR.pickupCity} · ${CAR.provider} · 📞 ${CAR.pickupPhone}`, status: 'confirmed' },
      { time: '10:00', activity: '🚗 Right-hand Drive Setup（20–30 分鐘）', note: '座椅、後視鏡、方向燈 vs 雨刷、導航、油箱蓋在哪一側＋標示的油種，不急著走', status: 'planned' },
      { time: '10:30', activity: '🛞 First Drive · 低車流道路適應', note: '靠左、左右轉、第一個圓環', status: 'planned' },
      { time: '12:00', activity: '停車 + Riverside Market 午餐', note: '第一次實際停車，不硬塞 · 建議停 The Crossing 停車場（71 Lichfield St，週末 NZ$9）', status: 'planned' },
      { time: '13:15', activity: '🛍 CBD 衣物採買（約 90 分）', note: 'Barkers（The Crossing）→ Macpac → Huffer · 停同一個車位步行', status: 'planned' },
      { time: '14:45', activity: '基督城市區散步', note: 'Hagley Park · 直接穿上新買的 Fleece', status: 'planned' },
      { time: '19:00', activity: '確認明日路線、油量、天氣', note: '基督城 → 蒂卡波 225km · 明天出發', status: 'planned' },
    ],
    accommodation: getAccommodationForDate('2026-10-10'),   // Sudima (booked from Oct 9)
    note: '住宿已於 10/9 辦理入住，凌晨抵達可直接進房。', photos: [], quote: '',
  },

  // ── Day 3 · Oct 11 · Lake Tekapo ────────────────────────────────────────────
  {
    day: 3, date: '2026-10-11',
    location: { en: 'Lake Tekapo', zh: '蒂卡波湖' },
    region: 'South Island',
    title: 'Christchurch → Lake Tekapo',
    titleZh: '前往蒂卡波湖',
    schedule: [
      { time: '',       activity: '退房 · Sudima Christchurch', note: '11:00 前', status: 'confirmed' },
      { time: '',       activity: '出發 Christchurch → Lake Tekapo', note: '', status: 'planned' },
      ...activityItems('2026-10-11'),   // 21:45 Stargazing
    ],
    accommodation: getAccommodationForDate('2026-10-11'),   // Skyblue Tekapo
    note: '', photos: [], quote: '',
  },

  // ── Day 4 · Oct 12 · Aoraki / Mt Cook ───────────────────────────────────────
  {
    day: 4, date: '2026-10-12',
    location: { en: 'Aoraki / Mt Cook', zh: '奧拉基 / 庫克山' },
    region: 'South Island',
    title: 'Lake Tekapo → Aoraki / Mt Cook',
    titleZh: '前往庫克山',
    schedule: [
      { time: '',       activity: '退房 · Skyblue Tekapo', note: '10:00 前', status: 'confirmed' },
      { time: '',       activity: '出發 Lake Tekapo → Aoraki / Mt Cook', note: '', status: 'planned' },
      ...activityItems('2026-10-12'),   // 13:00 Glacier heli
    ],
    accommodation: getAccommodationForDate('2026-10-12'),   // Haka House
    note: '', photos: [], quote: '',
  },

  // ── Day 5 · Oct 13 · Wanaka ─────────────────────────────────────────────────
  {
    day: 5, date: '2026-10-13',
    location: { en: 'Wanaka', zh: '瓦納卡' },
    region: 'South Island',
    title: 'Aoraki / Mt Cook → Wanaka',
    titleZh: '前往瓦納卡',
    schedule: [
      { time: '',       activity: '退房 · Haka House Hostel Aoraki Mt Cook', note: '10:00 前', status: 'confirmed' },
      { time: '',       activity: '出發 Aoraki / Mt Cook → Wanaka', note: '', status: 'planned' },
      { time: '15:00',  activity: 'Check in · A Room on the Peninsula', note: '15:00–22:00', status: 'confirmed' },
    ],
    accommodation: getAccommodationForDate('2026-10-13'),   // A Room on the Peninsula (Wanaka)
    note: '', photos: [], quote: '',
  },

  // ── Day 6 · Oct 14 · Queenstown ─────────────────────────────────────────────
  {
    day: 6, date: '2026-10-14',
    location: { en: 'Queenstown', zh: '皇后鎮' },
    region: 'South Island',
    title: 'Wanaka → Queenstown',
    titleZh: '前往皇后鎮',
    schedule: [
      { time: '',       activity: '退房 · A Room on the Peninsula', note: '10:00 前', status: 'confirmed' },
      { time: '',       activity: '出發 Wanaka → Queenstown', note: '', status: 'planned' },
      { time: '15:00',  activity: 'Check in · Nomads Queenstown Hostel', note: '15:00–23:00', status: 'confirmed' },
      { time: '19:00',  activity: '🧺 洗衣 · Nomads 自助洗衣', note: '內褲 / 襪子穿到今天剛好用完 · 用烘衣機，明早 08:00 跳傘要穿乾衣服', status: 'planned' },
    ],
    accommodation: getAccommodationForDate('2026-10-14'),   // Nomads Queenstown
    companions: ['雙雙'],
    note: '雙雙從皇后鎮會合，一起玩兩天。', photos: [], quote: '',
  },

  // ── Day 7 · Oct 15 · Queenstown · Skydive ───────────────────────────────────
  {
    day: 7, date: '2026-10-15',
    location: { en: 'Queenstown', zh: '皇后鎮' },
    region: 'South Island',
    title: 'Queenstown · Skydive Day',
    titleZh: '高空跳傘日',
    schedule: [
      ...activityItems('2026-10-15'),   // 08:00 NZONE Skydive
    ],
    accommodation: getAccommodationForDate('2026-10-15'),   // Nomads Queenstown
    companions: ['雙雙'],
    note: '雙雙同遊第二天。', photos: [], quote: '',
  },

  // ── Day 8 · Oct 16 · Milford Sound (Day Trip from Queenstown) ───────────────
  {
    day: 8, date: '2026-10-16',
    location: { en: 'Milford Sound', zh: '米爾福德峽灣' },
    region: 'Fiordland',
    title: 'Milford Sound Day Trip',
    titleZh: '米爾福德峽灣一日遊',
    schedule: [
      ...activityItems('2026-10-16'),   // 07:15 集合
    ],
    accommodation: getAccommodationForDate('2026-10-16'),   // Nomads Queenstown (base)
    note: '', photos: [], quote: '',
  },

  // ── Day 9 · Oct 17 · Departure ──────────────────────────────────────────────
  {
    day: 9, date: '2026-10-17',
    location: { en: 'Queenstown', zh: '皇后鎮' },
    region: 'South Island',
    title: 'Departure · Queenstown → Brisbane',
    titleZh: '啟程返台',
    schedule: [
      { time: '',               activity: '退房 · Nomads Queenstown Hostel', note: '11:00 前', status: 'confirmed' },
      { time: `${CAR.dropoffTime}`, activity: `還車 · ${CAR.vehicle}`, note: `${CAR.dropoffCity} · ${CAR.dropoffAddress} · 📞 ${CAR.dropoffPhone}`, status: 'confirmed' },
      { time: '19:45',          activity: 'QF186 出發 皇后鎮 → 布里斯本 (BNE)', note: 'ZQN → BNE', status: 'confirmed' },
      { time: '22:50',          activity: 'CI054 出發 布里斯本 → 台北 (TPE)',   note: 'BNE → TPE', status: 'confirmed' },
    ],
    accommodation: null,
    note: '', photos: [], quote: '',
  },

  // ── Day 10 · Oct 18 · Arrive Taipei ─────────────────────────────────────────
  {
    day: 10, date: '2026-10-18',
    location: { en: 'Taipei', zh: '台北' },
    region: 'Taiwan',
    title: 'Arrive Taipei',
    titleZh: '返抵台北',
    schedule: [
      { time: '05:40', activity: 'CI054 抵達台北桃園機場 (TPE)', note: '', status: 'confirmed' },
    ],
    accommodation: null,
    note: '', photos: [], quote: '',
  },
]
