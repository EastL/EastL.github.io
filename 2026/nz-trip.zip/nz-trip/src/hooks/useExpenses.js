import { useState, useCallback, useEffect } from 'react'
import {
  initialExpenses, personalExpenses, upcomingExpenses,
  ACCOMM_TOTAL_TWD, RENTAL_TOTAL_TWD, ACTIVITY_TOTAL_TWD,
  SHARED_CONFIRMED_TWD, PER_PERSON_SHARED_TWD,
  FLIGHTS_TOTAL_TWD, FLIGHT_DONGYUE_TWD, FLIGHT_BROTHER_TWD,
  GRAND_CONFIRMED_TWD,
  PERSONAL_COST_DONGYUE, PERSONAL_COST_BROTHER,
  ESIM_DONGYUE_TWD,
  INSURANCE_DONGYUE_TWD,
} from '../data/expenses.js'
import { EXPENSE_CATEGORIES, EXPENSE_PIN, NZD_TO_TWD_RATE, GSHEET_URL } from '../data/config.js'

const LS_KEY  = 'nz-trip-user-expenses'
const AUTH_KEY = 'nz-trip-auth'

// ── helpers ──────────────────────────────────────────────────────────────────
function lsLoad() {
  try { return JSON.parse(localStorage.getItem(LS_KEY) || '[]') } catch { return [] }
}
function lsSave(arr) {
  try { localStorage.setItem(LS_KEY, JSON.stringify(arr)) } catch {}
}

function normaliseRow(e) {
  return {
    ...e,
    TWD: e.TWD !== '' && e.TWD != null ? Number(e.TWD) : null,
    NZD: e.NZD !== '' && e.NZD != null ? Number(e.NZD) : null,
  }
}

async function sheetGet() {
  // Apps Script redirects (302) — follow redirect explicitly
  const r = await fetch(GSHEET_URL + '?t=' + Date.now(), {
    method: 'GET',
    redirect: 'follow',
  })
  if (!r.ok) throw new Error(`HTTP ${r.status}`)
  const text = await r.text()
  const data = JSON.parse(text)
  if (data.error) throw new Error(data.error)
  return (data.expenses || []).map(normaliseRow)
}

async function sheetPost(body) {
  // text/plain body avoids CORS preflight
  await fetch(GSHEET_URL, {
    method: 'POST',
    redirect: 'follow',
    body: JSON.stringify(body),
  })
}

// ── hook ─────────────────────────────────────────────────────────────────────
export function useExpenses() {
  const [userExpenses, setUserExpenses] = useState([])
  const [syncStatus, setSyncStatus]     = useState('idle') // idle | loading | synced | error

  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    try { return sessionStorage.getItem(AUTH_KEY) === 'true' } catch { return false }
  })

  // ── Load / refresh ────────────────────────────────────────────────────────
  const refresh = useCallback(() => {
    if (!GSHEET_URL) {
      setUserExpenses(lsLoad())
      setSyncStatus('local')
      return
    }
    setSyncStatus('loading')
    sheetGet()
      .then(rows => { setUserExpenses(rows); setSyncStatus('synced') })
      .catch(() => {
        setUserExpenses(lsLoad())
        setSyncStatus('error')
      })
  }, [])

  useEffect(() => { refresh() }, [])

  // ── Auth ───────────────────────────────────────────────────────────────────
  const authenticate = useCallback((pin) => {
    if (pin !== EXPENSE_PIN) return false
    try { sessionStorage.setItem(AUTH_KEY, 'true') } catch {}
    setIsAuthenticated(true)
    return true
  }, [])

  const logout = useCallback(() => {
    try { sessionStorage.removeItem(AUTH_KEY) } catch {}
    setIsAuthenticated(false)
  }, [])

  // ── Add ────────────────────────────────────────────────────────────────────
  const addExpense = useCallback((expense) => {
    const newExp = { ...expense, id: `user-${Date.now()}` }
    setUserExpenses(prev => {
      const next = [...prev, newExp]
      if (!GSHEET_URL) lsSave(next)
      return next
    })
    if (GSHEET_URL) {
      sheetPost({ action: 'add', ...newExp }).catch(() => {})
    }
  }, [])

  // ── Delete ─────────────────────────────────────────────────────────────────
  const deleteExpense = useCallback((id) => {
    setUserExpenses(prev => {
      const next = prev.filter(e => e.id !== id)
      if (!GSHEET_URL) lsSave(next)
      return next
    })
    if (GSHEET_URL) {
      sheetPost({ action: 'delete', id }).catch(() => {})
    }
  }, [])

  // 個人已確認花費（排除機票，機票已含在 GRAND_CONFIRMED_TWD，避免重複計算）
  const personalConfirmedTWD = personalExpenses
    .filter(e => e.status === 'confirmed' && e.category !== 'flight')
    .reduce((s, e) => s + (Number(e.TWD) || 0), 0)

  // ── Computed ───────────────────────────────────────────────────────────────
  const toTWD = useCallback((e) => {
    if (e.TWD) return Number(e.TWD)
    if (e.NZD) return Number(e.NZD) * NZD_TO_TWD_RATE
    return 0
  }, [])

  const getUserTotal = useCallback(() =>
    userExpenses.reduce((s, e) => s + toTWD(e), 0)
  , [userExpenses, toTWD])

  // ── Export ─────────────────────────────────────────────────────────────────
  const exportJSON = useCallback(() => {
    const blob = new Blob([JSON.stringify({
      confirmed: { shared: initialExpenses, personal: personalExpenses },
      upcoming: upcomingExpenses,
      userAdded: userExpenses,
    }, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'nz-trip-expenses.json'; a.click()
    URL.revokeObjectURL(url)
  }, [userExpenses])

  return {
    // sync
    syncStatus,
    // confirmed totals
    confirmedSharedTWD: SHARED_CONFIRMED_TWD,
    perPersonSharedTWD: PER_PERSON_SHARED_TWD,
    accommTotalTWD:     ACCOMM_TOTAL_TWD,
    rentalTotalTWD:     RENTAL_TOTAL_TWD,
    activityTotalTWD:   ACTIVITY_TOTAL_TWD,
    flightsTotalTWD:    FLIGHTS_TOTAL_TWD,
    flightDongyueTWD:   FLIGHT_DONGYUE_TWD,
    flightBrotherTWD:   FLIGHT_BROTHER_TWD,
    grandConfirmedTWD:  GRAND_CONFIRMED_TWD + personalConfirmedTWD,
    personalCostDongyue: PERSONAL_COST_DONGYUE,
    personalCostBrother: PERSONAL_COST_BROTHER,
    esimDongyueTWD:     ESIM_DONGYUE_TWD,
    // line items
    sharedLineItems:    initialExpenses,
    confirmedPersonal:  personalExpenses,
    upcomingExpenses,
    // user-added
    userExpenses, addExpense, deleteExpense,
    getUserTotal, toTWD,
    // auth
    isAuthenticated, authenticate, logout,
    exportJSON,
    refresh,
  }
}
