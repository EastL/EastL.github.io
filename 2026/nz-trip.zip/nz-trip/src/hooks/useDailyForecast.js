import { useEffect, useState } from 'react'
import { ROUTE_SEGMENTS } from '../data/routes'

// 穿搭卡用的當日預報（Open-Meteo，欄位與 WeatherCard 相同）
// 同一地點一次抓 16 天，記在 cache，總覽展開多天也只打一次 API

const cache = new Map() // key 'lat,lng' → Promise<daily>

function fetchDaily(lat, lng) {
  const key = `${lat},${lng}`
  if (!cache.has(key)) {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}` +
      '&daily=weathercode,temperature_2m_max,temperature_2m_min,precipitation_sum,snowfall_sum,windspeed_10m_max,uv_index_max' +
      '&hourly=uv_index,cloud_cover' +
      '&timezone=auto&forecast_days=16'
    cache.set(key, fetch(url).then(r => r.json()).then(j => ({ ...j.daily, hourly: j.hourly })).catch(e => { cache.delete(key); throw e }))
  }
  return cache.get(key)
}

// 當天的天氣地點：該日路段的終點（例 10/12 → 庫克山村莊、10/16 → 米爾福德峽灣）；飛行日不抓
export function getWeatherPoint(date) {
  const seg = ROUTE_SEGMENTS.find(s => s.date === date && s.type !== 'flight')
  return seg ? seg.coords[seg.coords.length - 1] : null
}

// 回傳 { tmin, tmax, precip, snow, wind, uv, uvHourly, cloudHourly, date } 或 null（飛行日、超出 16 天、離線）
export function useDailyForecast(date) {
  const [weather, setWeather] = useState(null)
  const point = getWeatherPoint(date)

  useEffect(() => {
    if (!point) return
    let alive = true
    fetchDaily(point[0], point[1])
      .then(d => {
        const i = d?.time?.indexOf(date) ?? -1
        if (!alive || i < 0) return
        setWeather({
          tmin: d.temperature_2m_min[i],
          tmax: d.temperature_2m_max[i],
          precip: d.precipitation_sum[i] ?? 0,
          snow: d.snowfall_sum[i] ?? 0,
          wind: d.windspeed_10m_max[i] ?? 0,
          uv: d.uv_index_max?.[i] ?? null,
          uvHourly: d.hourly?.time ? d.hourly.time.map((t, k) => ({ time: t, uv: d.hourly.uv_index?.[k] ?? 0 })) : null,
          cloudHourly: d.hourly?.cloud_cover ? d.hourly.time.map((t, k) => ({ time: t, cloud: d.hourly.cloud_cover[k] })) : null,
          date,
        })
      })
      .catch(() => {})
    return () => { alive = false }
  }, [date, point?.[0], point?.[1]])

  return weather
}
