import { useEffect, useState } from 'react'

// 主畫面 app（PWA）不會自己重新載入：iOS 會把整個頁面留在記憶體，下次打開只是「回到前景」，
// 加上 GitHub Pages 的 HTML 有 10 分鐘快取，所以推了新 commit 也看不到。
// 做法：打開時、以及每次回到前景時，用 no-store 抓一次最新 HTML，比對 build-id。
// 比較新 → 回傳新的 build-id，由 UpdateBanner 顯示提示，使用者點了才重新載入（避免打斷正在輸入的花費）。
const CURRENT = __BUILD_ID__
const MIN_INTERVAL = 30 * 1000

export function useUpdateCheck() {
  const [newBuild, setNewBuild] = useState(null)

  useEffect(() => {
    let lastCheck = 0

    async function check() {
      if (Date.now() - lastCheck < MIN_INTERVAL) return
      lastCheck = Date.now()
      try {
        const res = await fetch(location.pathname, { cache: 'no-store' })
        if (!res.ok) return
        const m = (await res.text()).match(/<meta name="build-id" content="(\d+)"/)
        // 只在「線上版本比較新」時提示（CDN 偶爾給到舊檔時不誤報）
        if (m && Number(m[1]) > Number(CURRENT)) setNewBuild(m[1])
      } catch {
        // 離線或本機檔案開啟：略過
      }
    }

    check()
    const onVisible = () => { if (document.visibilityState === 'visible') check() }
    document.addEventListener('visibilitychange', onVisible)
    return () => document.removeEventListener('visibilitychange', onVisible)
  }, [])

  return newBuild
}

// 帶上 ?v=新版本號 重新載入：網址不同，保證不會拿到快取的舊 HTML
export function reloadToBuild(buildId) {
  location.replace(`${location.pathname}?v=${buildId}`)
}
