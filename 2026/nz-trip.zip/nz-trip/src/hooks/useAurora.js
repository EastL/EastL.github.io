import { useEffect, useState } from 'react'
import { KP_URL, parseKp, tonightKp, tonightCloud, auroraLevel } from '../data/aurora'
import { useDailyForecast } from './useDailyForecast'

// Kp 預報全站共用一份，30 分鐘內不重抓
const TTL = 30 * 60e3
let kpCache = null // { ts, promise }

function fetchKp() {
  if (!kpCache || Date.now() - kpCache.ts > TTL) {
    const promise = fetch(KP_URL, { cache: 'no-store' })
      .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json() })
      .then(parseKp)
      .catch(e => { kpCache = null; throw e })
    kpCache = { ts: Date.now(), promise }
  }
  return kpCache.promise
}

// 回傳 null（載入中）、{ error: true }、或 { kp, cloud, level }
export function useAurora(date) {
  const weather = useDailyForecast(date)
  const [kp, setKp] = useState(undefined)

  useEffect(() => {
    let alive = true
    const load = () => fetchKp()
      .then(list => { if (alive) setKp(tonightKp(list, date)) })
      .catch(() => { if (alive) setKp('error') })
    load()
    const id = setInterval(load, TTL)
    return () => { alive = false; clearInterval(id) }
  }, [date])

  if (kp === undefined) return null
  if (kp === 'error') return { error: true }
  const cloud = tonightCloud(weather?.cloudHourly, date)
  return { kp, cloud, level: auroraLevel(kp, cloud) }
}
