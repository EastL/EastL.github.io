import { useState, useCallback } from 'react'
import { CHECKLIST_INITIAL, CHECKLIST_CATEGORIES } from '../data/checklist'

const STORAGE_KEY = 'nz-trip-checklist'

// 已確認完成、不受 localStorage 影響的項目
const HARD_DONE = ['nzeta', 'aus-visa', 'intl-license', 'tw-license', 'travel-ins-dongyue', 'travel-ins-activity']

function loadChecklist() {
  try {
    const overrides = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}')
    return CHECKLIST_INITIAL.map(item => ({
      ...item,
      status: HARD_DONE.includes(item.id)
        ? 'done'
        : (overrides[item.id] ?? item.status),
    }))
  } catch {
    return CHECKLIST_INITIAL
  }
}

const STATUS_CYCLE = { todo: 'done', done: 'recheck', recheck: 'todo' }

export function useChecklist() {
  const [items, setItems] = useState(loadChecklist)

  const updateStatus = useCallback((id, status) => {
    setItems(prev => {
      const next = prev.map(item => item.id === id ? { ...item, status } : item)
      // Persist only overrides vs initial
      const overrides = {}
      next.forEach(item => {
        const init = CHECKLIST_INITIAL.find(i => i.id === item.id)
        if (init && init.status !== item.status) overrides[item.id] = item.status
      })
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(overrides)) } catch {}
      return next
    })
  }, [])

  const toggleStatus = useCallback((id) => {
    setItems(prev => {
      const current = prev.find(i => i.id === id)
      if (!current) return prev
      const next = prev.map(item =>
        item.id === id ? { ...item, status: STATUS_CYCLE[item.status] || 'todo' } : item
      )
      const overrides = {}
      next.forEach(item => {
        const init = CHECKLIST_INITIAL.find(i => i.id === item.id)
        if (init && init.status !== item.status) overrides[item.id] = item.status
      })
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(overrides)) } catch {}
      return next
    })
  }, [])

  const doneCount  = items.filter(i => i.status === 'done').length
  const totalCount = items.length
  const todoItems  = items.filter(i => i.status !== 'done').slice(0, 3)

  const byCategory = CHECKLIST_CATEGORIES.map(cat => ({
    ...cat,
    items: items.filter(i => i.cat === cat.id),
  }))

  return { items, byCategory, updateStatus, toggleStatus, doneCount, totalCount, todoItems }
}
