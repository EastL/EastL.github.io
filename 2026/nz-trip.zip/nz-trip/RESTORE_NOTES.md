# 原始碼還原說明

這份原始碼是從 GitHub Pages 上 10/5 部署的單檔 HTML（2026/nz_trip_eastl.html）反編譯還原的，
因為當時 repo 裡沒有原始碼、手上的 zip 又是舊版。

- 還原方式：取出 inline 的 JS bundle → Babel 反編譯回 JSX（dejsx）→ 變數重新命名
- 驗證：重新 build 後的 bundle 與部署版做正規化 diff，邏輯一致
- 之後每次修改都會重新打包這個 zip，原始碼不再落後網站

## Build
```
npm install
npx vite build
python3 inline.py dist nz_trip_eastl.html   # 把 CSS / JS 內嵌成單一 HTML
```
產出的單檔 HTML 直接放到 GitHub Pages（2026/nz_trip_eastl.html）即可，不需要 backend 或 database。

進度紀錄見 OUTFIT_PROGRESS.md。
