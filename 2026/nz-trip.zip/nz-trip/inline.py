import re,sys,pathlib
d=pathlib.Path(sys.argv[1]); html=(d/'index.html').read_text()
def css(m): return '<style>'+(d/m.group(1).lstrip('/')).read_text()+'</style>'
def js(m): return '<script type="module">'+(d/m.group(1).lstrip('/')).read_text().replace('</script','<\\/script')+'</script>'
html=re.sub(r'<link rel="stylesheet"[^>]*href="([^"]+)"[^>]*>',css,html)
html=re.sub(r'<script type="module"[^>]*src="([^"]+)"[^>]*></script>',js,html)
pathlib.Path(sys.argv[2]).write_text(html)
