import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// 每次 build 產生一個版本號（build 時間 ms），同時寫進 JS 常數與 HTML <meta>，
// 主畫面 app 回到前景時抓最新 HTML 比對 → 有新版就顯示更新提示（見 hooks/useUpdateCheck.js）
const BUILD_ID = String(Date.now())

export default defineConfig({
  plugins: [
    react(),
    {
      name: 'build-id-meta',
      transformIndexHtml: html =>
        html.replace('<meta charset="UTF-8" />', `<meta charset="UTF-8" />\n    <meta name="build-id" content="${BUILD_ID}" />`),
    },
  ],
  define: { __BUILD_ID__: JSON.stringify(BUILD_ID) },
  base: './',
})
