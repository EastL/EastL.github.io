/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // ── 60% Warm White / Ivory (main backgrounds) ──────────────────────
        ivory: {
          50:  '#FDFCFA',
          100: '#FAF9F5',   // main page bg
          200: '#F3F0EA',   // card bg, section bg
          300: '#E6E1D6',   // borders, dividers
          400: '#CEC7B8',   // stronger border
        },

        // ── 20% Deep Forest Green (brand, headers, key blocks) ──────────────
        forest: {
          900: '#0D2419',
          800: '#173D2A',   // primary brand / header bg
          700: '#1E5235',
          600: '#25683F',
          500: '#2E7D50',
          400: '#4A9B6F',
          300: '#6AAF87',
          100: '#D4EAD9',
          50:  '#EEF7F1',
        },

        // ── 10% Lake / Slate Blue (NZ lakes & sky) ──────────────────────────
        lake: {
          900: '#122F3E',
          800: '#1E4E6A',
          700: '#265F7E',
          600: '#3D6E8A',   // primary lake
          500: '#4A7FA5',
          400: '#6E9FBF',
          300: '#9BBFD5',
          200: '#C5DDE8',
          100: '#D8EAF2',
          50:  '#EEF5FA',
        },

        // ── 5% Gold / Mustard (Today, progress, accent) ─────────────────────
        gold: {
          800: '#6B4A0E',
          700: '#8A6215',
          600: '#A5771A',
          500: '#C4952A',   // primary gold
          400: '#D4AE5A',
          300: '#E2C882',
          200: '#EDD9A8',
          100: '#F4EBC8',
          50:  '#FAF4DC',
        },

        // ── Charcoal (text, replaces all ink-xxx) ───────────────────────────
        charcoal: {
          900: '#1A1A1A',
          800: '#2A2A2A',   // primary text
          700: '#3A3A3A',
          600: '#4A4A4A',
          500: '#5A5A5A',
          400: '#6B6B6B',   // secondary text
          300: '#8A8A8A',   // muted
          200: '#A8A8A8',
          100: '#D0CCC4',   // subtle border
          50:  '#E8E5DE',
        },
      },
      fontFamily: {
        serif: ['Lora', 'Georgia', 'serif'],
        sans:  ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
