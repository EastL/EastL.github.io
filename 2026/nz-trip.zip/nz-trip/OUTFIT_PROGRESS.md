# 每日穿搭功能進度

- [x] 1. 測試：nz-trip-test.html E 組（3 規則 ✓ / 5 HTML ✗，2026-10-06 本機確認）
- [x] 2. 資料：src/data/outfits.js（10 天、洋蔥 4 層、4 級規則、採購、70/30、layerBar / pickSession / weatherAdvice / outfitSummary）
      Checklist 新增「衣物」17 項；「防水保暖衣物」移除；rain-jacket、sunglasses 沿用 id 移到衣物（勾選狀態保留）
- [x] 3. Today 今日穿搭卡（層數條、18:00 觀星切換、明天預告 icon）
- [x] 4. 行程頁一行摘要＋穿搭總覽彈出頁
- [x] 5. 天氣連動（Open-Meteo 當日預報 → weatherAdvice）
- [x] 6. build、截圖驗證、交付

附帶修正：測試 D 組庫克山座標從山頂 (-43.5965,170.1418) 改為村莊 (-43.7357,170.0964)，與網站一致
      Today：DuringTrip 穿搭卡放在 TODAY'S JOURNEY 上方；TMRW 格加明天主題；BeforeTrip 出發前一天起顯示出發日穿搭
      components/OutfitOverview.jsx（手機：可展開清單；≥768px：10 天 × 各層表格）；行程頁每天一行 WEAR 摘要 → 開總覽並定位；Today 出發前有總覽入口
      hooks/useDailyForecast.js（同地點 16 天只抓一次）；地點＝當日路段終點，飛行日不抓；觀星日白天不做低溫提醒（交給晚上那套）
      驗證：測試 A 18/18、E 8/8、D 24/25（Trip Total 那項是既有限制：總額在執行時計算，HTML 原始碼裡本來就沒有 271,352；實際燒錢頁顯示 NT$ 271,352 正確）
      9 個時間點（出發前 / 出發日 / 飛行 / 墨爾本 / Day2 / 4 / 8 / 10 / 返台後）切換 4 個分頁＋開總覽：0 錯誤
      Checklist 18 / 61 READY（衣物 0/17）
- [x] 10/10 CBD 採買（2026-10-06）：itinerary Day2 13:15 採買、Hagley 14:45；outfits.js SHOPPING.stores/parking/backup；總覽店家卡＋MAP；E 組 +2 測試
- [x] 出發前檢查（2026-10-07）：DayModal 2×2（NZTA 路況 / MetService / 加油站 / CamperMate 網頁版），routes.js metservice 欄位；Checklist 三個 App 下載連結（iOS/Android 自動切換，Waka Kotahi 連官網）；A 組 +2 測試
- [x] 購買件數＋洗衣（2026-10-07）：SHOPPING.buyList（2 件）、店家卡「要買」標籤；10/14 19:00 洗衣（Nomads）、10/12 洗衣備案（Haka House）；Checklist 洗衣片 / 髒衣袋；E 組 +2 測試
- [x] UV / 防曬（2026-10-07）：data/sun.js（WHO 分級、雪地 +1、防曬時段）、預報加 uv_index_max＋hourly uv_index、穿搭卡 🧴 列、10/12 snow:true；Checklist 鴨舌帽 / 遮陽帽、SPF 護唇膏；E 組 +4 測試
- [x] 電話可按（2026-10-07）：components/PhoneText.jsx（+國碼 / 0800 → tel:，+64 後多的 0 去掉），套用在 Today / 行程頁行程備註與緊急聯絡備註；E 組 +2 測試

## PDF（請問導遊高 南北島 10 月行程）補充 — 2026-10-07
- [x] 1. 天氣取消 Plan B：trip.js ACTIVITIES.planB（觀星 / 冰川 / 跳傘 / 米爾福德），components/PlanB.jsx，顯示於 Today 行程、行程頁活動卡、DayModal 活動卡；A 組 +1 測試
- [x] 2. 入境申報：Checklist biosecurity 項目、基本藥品備註、NZTD 備註、Day1 墨爾本 / Day2 基督城入境提醒；A 組 +1 測試
- [x] 3. 加油：Checklist cc-pin、DayModal 出發前檢查下方加油提醒、Day2 右駕設定加「油箱蓋＋油種」；A 組 +1 測試
- [x] 4. 順路停靠：routes.js stops（Day3–6、9）＋ getStopsForDate、components/RouteStops.jsx（Today / 行程頁 / DayModal）；A 組 +1 測試
- [x] 5. 右駕卡：圓環 3 種打燈＋Give Way、STOP 完全停、停車標誌區塊（NZ Road Code）；A 組 +1 測試
- [x] 5b. 右駕卡：巴士專用道（24h／50 m 左轉／NZ$150）＋中央緩衝區 Flush Median（NZ Road Code＋AA）；A 組 +1 測試
- [x] 5c. 右駕卡：單線橋（紅圓讓 / 藍方優先）＋斑馬線（橘色圓盤、安全島規則、不超車）；A 組 +1 測試
- [x] 6. Checklist 物品（2026-10-07）：環保購物袋、拖鞋、護手霜 / 乳液、行李秤（選帶）、密封袋（選帶），cash-nzd 加「每人約 NZ$100」備註；A 組 +1 測試
- [x] 7. App（2026-10-07）：Checklist 通訊加 Waze（選裝，iOS / Android）、極光預報 Tassie Aurora（iOS，含 Tekapo / Queenstown，NOAA 網頁備援）；A 組 +1 測試
- [x] 7b. 今晚極光（2026-10-07）：data/aurora.js（NOAA Kp 3 天預報解析、NZ 20:00–03:00 換算、Open-Meteo 夜間雲量、Kp≥5 有機會 / ≥7 高 / 雲≥70% 被雲擋住）、hooks/useAurora.js（30 分鐘快取）、components/AuroraCard.jsx（Today，機會低只一行）；useDailyForecast 加 hourly cloud_cover；測試新增 F 組 6 項（含 NOAA CORS 實測）
- [x] 8. 瓦納卡 → 皇后鎮（2026-10-07）：原「SH6 · 67km」其實是 Crown Range 距離 → 改 Crown Range Road（經 Cardrona）68 km / 1.2h，warning 寫下雪改 SH6 經 Cromwell 113 km / 1.5h，gmapsUrl 經 Cardrona Hotel；A 組 +1 測試
- [x] 8b. 10/14 順路停靠：Cardrona Hotel（1863）、Crown Range Summit / Arrow Junction Lookout、Arrowtown（老街＋華人淘金村），排在 Patagonia 前；A 組 +1 測試
